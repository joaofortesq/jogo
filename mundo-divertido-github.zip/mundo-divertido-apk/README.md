# Mundo Divertido

1. Crie um repositório no GitHub e envie estes arquivos (mantendo a pasta `.github`).
2. Abra a aba **Actions** > **Build APK**. Ele roda sozinho a cada push; também dá para clicar em **Run workflow**.
3. Quando terminar (uns 5 minutos), abra a execução e baixe **mundo-divertido-apk** em *Artifacts*.
4. Descompacte e instale o `app-debug.apk` no celular (permita "instalar apps desconhecidos").

O app fica em `www/index.html`. Para mudar algo, edite esse arquivo e faça um novo push.
