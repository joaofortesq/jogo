import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:mundo_divertido/data/content_repository.dart';
import 'package:mundo_divertido/models/learning_item.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late ContentRepository repo;
  setUpAll(() async => repo = await ContentRepository.load());

  test('carrega 6 categorias com a quantidade esperada de itens', () {
    expect(repo.categories.map((c) => c.id),
        ['farm', 'safari', 'fruits', 'colors', 'letters', 'numbers']);
    const expected = {
      'farm': 12,
      'safari': 13,
      'fruits': 10,
      'colors': 10,
      'letters': 26,
      'numbers': 11,
    };
    for (final c in repo.categories) {
      expect(c.items.length, expected[c.id], reason: c.id);
    }
  });

  test('gato e cachorro na fazenda; sapo, papagaio e coruja no safári', () {
    final farm = repo.byId('farm').items.map((i) => i.id);
    final safari = repo.byId('safari').items.map((i) => i.id);
    expect(farm, containsAll(['cat', 'dog']));
    expect(safari, containsAll(['frog', 'parrot', 'owl']));
  });

  test('animais têm corpo inteiro em camadas que existem', () {
    for (final id in ['farm', 'safari']) {
      for (final i in repo.byId(id).items) {
        final rig = i.rig;
        expect(rig, isNotNull, reason: i.id);
        expect(rig!.eyes, isNotEmpty, reason: i.id);
        final roles = rig.layers.map((l) => l.role).toSet();
        for (final r in ['legL', 'legR', 'body', 'armL', 'armR', 'head']) {
          expect(roles.contains(r), isTrue, reason: '${i.id} sem $r');
        }
        for (final l in rig.layers) {
          expect(File(l.asset).existsSync(), isTrue, reason: l.asset);
        }
      }
    }
    expect(repo.byId('fruits').items.any((i) => i.rig != null), isFalse);
  });

  test('cada objeto de cor tem id único para o arquivo de áudio', () {
    final ids = [
      for (final i in repo.byId('colors').items)
        for (final e in i.examples) e.id,
    ];
    expect(ids.toSet().length, ids.length);
  });

  test('ids são únicos e nomes pt/en existem', () {
    for (final c in repo.categories) {
      final ids = c.items.map((i) => i.id).toSet();
      expect(ids.length, c.items.length, reason: c.id);
      for (final i in c.items) {
        expect(i.pt.trim(), isNotEmpty);
        expect(i.en.trim(), isNotEmpty);
      }
    }
  });

  test('animais têm som; frutas e cores não', () {
    for (final id in ['farm', 'safari']) {
      expect(repo.byId(id).items.every((i) => i.hasAnimalSound), isTrue);
    }
    expect(repo.byId('fruits').items.any((i) => i.hasAnimalSound), isFalse);
    expect(repo.byId('colors').items.any((i) => i.hasAnimalSound), isFalse);
  });

  test('caminhos de áudio seguem a convenção', () {
    final cow = repo.byId('farm').items.first;
    expect(cow.id, 'cow');
    expect(cow.ptAudioPath, 'assets/audio/pt_br/cow.mp3');
    expect(cow.enAudioPath, 'assets/audio/en_us/cow.mp3');
    expect(cow.soundAudioPath, 'assets/audio/animal_sounds/cow.mp3');
  });

  test('todo animal tem onomatopeia falada com tom e velocidade válidos', () {
    for (final id in ['farm', 'safari']) {
      for (final i in repo.byId(id).items) {
        final s = i.sound;
        expect(s, isNotNull, reason: i.id);
        expect(s!.text.trim(), isNotEmpty, reason: i.id);
        expect(s.pitch, inInclusiveRange(0.5, 2.0), reason: i.id);
        expect(s.rate, inInclusiveRange(0.1, 1.0), reason: i.id);
      }
    }
    expect(repo.byId('fruits').items.any((i) => i.sound != null), isFalse);
  });

  test('cores têm exemplos e a categoria é do tipo colors', () {
    final colors = repo.byId('colors');
    expect(colors.kind, CategoryKind.colors);
    expect(colors.items.every((i) => i.examples.isNotEmpty), isTrue);
  });

  test('colorFromHex converte corretamente', () {
    expect(colorFromHex('#FF0000').value, 0xFFFF0000);
  });

  test('animais e frutas têm arte SVG existente com dois olhos', () {
    for (final id in ['farm', 'safari', 'fruits']) {
      for (final i in repo.byId(id).items) {
        expect(i.art, isNotNull, reason: i.id);
        expect(File(i.art!.asset).existsSync(), isTrue, reason: i.art!.asset);
        expect(i.art!.eyes.length, 2, reason: i.id);
      }
    }
  });

  test('cenários existem e cores não têm cenário', () {
    for (final id in ['farm', 'safari', 'fruits']) {
      expect(File(repo.byId(id).scene!).existsSync(), isTrue, reason: id);
    }
    expect(repo.byId('colors').scene, isNull);
  });

  test('letras: A a Z, com nome falado, símbolo e palavras de exemplo', () {
    final letters = repo.byId('letters');
    expect(letters.kind, CategoryKind.letters);
    expect(letters.items.map((i) => i.pt).join(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ');
    for (final i in letters.items) {
      expect(i.speakPt, isNotNull, reason: i.id);
      expect(i.speakEn, isNotNull, reason: i.id);
      expect(i.glyph, '${i.pt}${i.pt.toLowerCase()}', reason: i.id);
      expect(i.examples, isNotEmpty, reason: i.id);
      for (final e in i.examples) {
        expect(e.pt.toUpperCase().startsWith(i.pt), isTrue, reason: '${e.pt} / ${i.pt}');
        expect(e.icon.trim(), isNotEmpty, reason: e.id);
      }
    }
    // ids dos exemplos são únicos (viram nomes de arquivo de áudio)
    final ids = [for (final i in letters.items) for (final e in i.examples) e.id];
    expect(ids.toSet().length, ids.length);
  });

  test('letras têm voz própria: B é falado "Bê" e "Bee"', () {
    final b = repo.byId('letters').items[1];
    expect(b.id, 'letter_b');
    expect(b.spokenPt, 'Bê');
    expect(b.spokenEn, 'Bee');
    expect(b.ptAudioPath, 'assets/audio/pt_br/letter_b.mp3');
  });

  test('números: 0 a 10 com valor, nome nos dois idiomas e objeto para contar', () {
    final numbers = repo.byId('numbers');
    expect(numbers.kind, CategoryKind.numbers);
    expect(numbers.items.map((i) => i.value), [for (var n = 0; n <= 10; n++) n]);
    expect(numbers.items[5].pt, 'Cinco');
    expect(numbers.items[5].en, 'Five');
    expect(numbers.items[5].glyph, '5');
    for (final i in numbers.items.where((i) => i.value! >= 1)) {
      expect(i.emoji, isNotNull, reason: i.id);
    }
    expect(numbers.items.every((i) => i.id == 'num_${i.value}'), isTrue);
  });

  test('letras e números não têm som de animal, arte nem cenário', () {
    for (final id in ['letters', 'numbers']) {
      final c = repo.byId(id);
      expect(c.scene, isNull, reason: id);
      expect(c.items.any((i) => i.hasAnimalSound || i.art != null || i.rig != null), isFalse);
    }
  });
}
