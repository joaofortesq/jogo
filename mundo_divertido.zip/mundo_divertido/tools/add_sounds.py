#!/usr/bin/env python3
"""Grava em farm.json e safari.json a onomatopeia falada de cada animal.

O app usa a voz do sistema para "cantar" o texto (com tom e velocidade),
então não precisa de nenhum arquivo de áudio. Para trocar um som, edite a
tabela abaixo e rode: python3 tools/add_sounds.py (na raiz do projeto).
Se existir assets/audio/animal_sounds/<id>.mp3, o app usa o arquivo no lugar.
"""
import json

# id: (texto, tom 0.5-2.0, velocidade 0.1-1.0)
SOUNDS = {
    'cow': ('Muuuuuu!', .55, .28), 'horse': ('Ihiiiiin!', 1.5, .45),
    'pig': ('Oinc, oinc, oinc!', .8, .5), 'hen': ('Có có có có có!', 1.6, .75),
    'rooster': ('Cocorocóóó!', 1.3, .5), 'duck': ('Quá, quá, quá!', 1.4, .6),
    'sheep': ('Méééééé!', 1.6, .35), 'goat': ('Béééééé!', 1.3, .35),
    'donkey': ('Ri-ó, ri-ó, ri-ó!', .7, .45), 'rabbit': ('Nhac, nhac, nhac!', 1.7, .7),
    'lion': ('Grrrr, roaaar!', .5, .3), 'elephant': ('Prrrrruuuu!', .5, .3),
    'giraffe': ('Hmmm, hmmm!', .6, .35), 'zebra': ('Iá, iá, iá!', 1.2, .5),
    'monkey': ('Uh uh uh, ah ah ah!', 1.5, .8), 'hippopotamus': ('Hrunf, hrunf!', .5, .35),
    'rhinoceros': ('Fuuunf, fuuunf!', .55, .35), 'crocodile': ('Grrr, nhoc nhoc!', .5, .4),
    'cheetah': ('Miaaaau! Rrrrr!', 1.2, .45), 'ostrich': ('Bum, bum, bum!', .6, .5),
}

for cat in ('farm', 'safari'):
    path = f'assets/data/{cat}.json'
    data = json.load(open(path, encoding='utf-8'))
    for it in data['items']:
        text, pitch, rate = SOUNDS[it['id']]
        it['sound'] = {'text': text, 'pitch': pitch, 'rate': rate}
    json.dump(data, open(path, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
print('ok')
