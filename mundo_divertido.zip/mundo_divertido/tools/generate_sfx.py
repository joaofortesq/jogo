#!/usr/bin/env python3
"""Gera os efeitos sonoros suaves do app (WAV mono, 22,05 kHz) em assets/audio/sfx/.

Sem dependências: usa só a biblioteca padrão. Todos os sons são curtos, de volume
baixo e sem notas agudas ou graves demais (nada de buzina ou som de "erro").
  tap.wav        toque leve
  correct.wav    acerto (três notas subindo)
  try_again.wav  tentativa (duas notas suaves e redondas, descendo pouco)
  win.wav        conclusão (pequena fanfarra alegre)
Uso (na raiz do projeto): python3 tools/generate_sfx.py
"""
import math
import pathlib
import struct
import wave

RATE = 22050
OUT = pathlib.Path(__file__).resolve().parent.parent / 'assets' / 'audio' / 'sfx'


def note(freq, dur, vol=0.35, attack=0.008, decay=6.0):
    n = int(RATE * dur)
    out = []
    for i in range(n):
        t = i / RATE
        env = min(1.0, t / attack) * math.exp(-decay * t)
        s = math.sin(2 * math.pi * freq * t) + 0.25 * math.sin(2 * math.pi * freq * 2 * t)
        out.append(vol * env * s / 1.25)
    return out


def seq(parts, gap=0.0):
    out = []
    for p in parts:
        out += p + [0.0] * int(RATE * gap)
    return out


def mix(a, b):
    n = max(len(a), len(b))
    a = a + [0.0] * (n - len(a))
    b = b + [0.0] * (n - len(b))
    return [x + y for x, y in zip(a, b)]


def save(name, samples):
    OUT.mkdir(parents=True, exist_ok=True)
    peak = max(1e-6, max(abs(s) for s in samples))
    scale = min(1.0, 0.8 / peak)
    with wave.open(str(OUT / name), 'wb') as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(b''.join(struct.pack('<h', int(max(-1, min(1, s * scale)) * 32767))
                               for s in samples))
    print('ok', name, f'{len(samples) / RATE:.2f}s')


C5, D5, E5, G5, A5, C6 = 523.25, 587.33, 659.25, 783.99, 880.0, 1046.5

save('tap.wav', note(660, 0.09, vol=0.3, decay=28))
save('correct.wav', seq([note(C5, 0.14, decay=9), note(E5, 0.14, decay=9), note(G5, 0.34, decay=5)]))
save('try_again.wav', seq([note(440, 0.16, vol=0.25, decay=10), note(392, 0.26, vol=0.22, decay=7)], gap=0.02))
fan = seq([note(C5, 0.12, decay=8), note(E5, 0.12, decay=8), note(G5, 0.12, decay=8), note(C6, 0.5, decay=3.5)])
save('win.wav', mix(fan, [0.0] * int(RATE * 0.36) + note(G5 / 2, 0.45, vol=0.18, decay=4)))
