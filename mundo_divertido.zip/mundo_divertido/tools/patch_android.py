#!/usr/bin/env python3
"""Depois de `flutter create`, deixa o Android pronto para a voz do sistema.

Android 11+ só mostra o motor de texto-para-fala ao app se o manifesto
declarar <queries>. Este script faz isso (é seguro rodar mais de uma vez).
Uso (na raiz do projeto): python3 tools/patch_android.py
"""
import pathlib, sys

p = pathlib.Path('android/app/src/main/AndroidManifest.xml')
if not p.exists():
    sys.exit('android/ não existe. Rode antes: flutter create --platforms=android --org br.com.mundodivertido .')
s = p.read_text(encoding='utf-8')
if 'android.intent.action.TTS_SERVICE' in s:
    print('já está configurado')
else:
    block = ('    <queries>\n        <intent>\n            <action android:name="android.intent.action.TTS_SERVICE"/>\n'
             '        </intent>\n    </queries>\n')
    s = s.replace('<application', block + '    <application', 1)
    p.write_text(s, encoding='utf-8')
    print('manifesto atualizado')
