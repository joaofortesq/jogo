#!/usr/bin/env python3
"""Gera os bichos de lado, com o formato real de cada animal, em camadas SVG.

Todos olham para a direita. Camadas (assets/images/rig/<id>_<papel>.svg):
  tail, legBF, legFF (pernas de trás), body, legBN, legFN (pernas da frente),
  wing / wing2 (aves), head (pescoço + cabeça), ear (orelha que balança).
O JSON da categoria ganha a chave "rig" (camadas, pontos de giro, olhos).

Uso (raiz do projeto):  python3 tools/generate_rigs.py
"""
import json, math, os, sys, glob

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import generate_art as G
from generate_art import O, K, el, ci, pa, line

SW = 3
GROUND = 178


def shade(hexc, f=.8):
    h = hexc.lstrip('#')
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return '#%02X%02X%02X' % (int(r * f), int(g * f), int(b * f))


def grp(parts, tx=0, ty=0, rot=0, s=1):
    t = f'translate({tx:.1f} {ty:.1f})' + (f' rotate({rot})' if rot else '') + (f' scale({s})' if s != 1 else '')
    return f'<g transform="{t}">' + ''.join(parts) + '</g>'


def limb(hx, hy, fx, fy, wt, wb, fill):
    dx, dy = fx - hx, fy - hy
    L = math.hypot(dx, dy) or 1
    nx, ny = -dy / L, dx / L
    d = (f'M{hx+nx*wt/2:.1f} {hy+ny*wt/2:.1f} L{fx+nx*wb/2:.1f} {fy+ny*wb/2:.1f} '
         f'L{fx-nx*wb/2:.1f} {fy-ny*wb/2:.1f} L{hx-nx*wt/2:.1f} {hy-ny*wt/2:.1f}Z')
    return pa(d, fill, sw=SW)


def foot(kind, fx, fy, w, c):
    if kind == 'hoof':
        return el(fx + 1, fy - 1, w / 2 + 1.5, 5, c, sw=SW)
    if kind == 'paw':
        return el(fx + 3, fy - 1, w / 2 + 4, 5.5, c, sw=SW)
    if kind == 'stub':
        return el(fx + 1, fy - 1, w / 2 + 2, 5, c, sw=SW) + ''.join(el(fx - 5 + 5 * i, fy + 1, 2.4, 2, '#FFF8E8', st=False) for i in range(3))
    if kind == 'webbed':
        return pa(f'M{fx-4} {fy-2} Q{fx+10} {fy-9} {fx+22} {fy+1} Q{fx+10} {fy+4} {fx-4} {fy+2}Z', c, sw=SW)
    if kind == 'claw':
        d = f'M{fx-3} {fy} L{fx+12} {fy} M{fx} {fy} L{fx+10} {fy-5} M{fx} {fy} L{fx-8} {fy-3}'
        return line(d, 5, O) + line(d, 2.4, c)
    return ''


# ---------------------------------------------------------------- cabeças (olhando p/ direita)
# Coordenadas locais: origem no centro da cabeça. Cada função devolve
# (partes, olho(x,y), partes_da_orelha, pivô_da_orelha)

def head_cow(c):
    p = [el(0, 0, 17, 15, c['skin'], rot=20), el(14, 9, 11, 9.5, '#F7A8BC', rot=20), ci(18, 8, 1.8, O, False), ci(13, 12, 1.8, O, False)]
    if c.get('patch'):
        p.insert(1, el(-4, -6, 8, 6, K, st=False))
    p.insert(0, pa('M-4 -12 Q-8 -26 2 -24 Q4 -18 2 -12Z', '#E9C88F', sw=2.5))
    ear = [el(-9, -5, 11, 5.5, '#F7A8BC', rot=-35)]
    return p, (3, -4), ear, (-6, -4)


def head_horse(c):
    col, dk = c['skin'], c.get('muzzle', shade(c['skin'], .75))
    p = [el(9, 5, 25, 11.5, col, rot=32), el(27, 15, 9, 8, dk, rot=32), ci(32, 15, 1.8, O, False), ci(28, 20, 1.8, O, False)]
    ear = [pa('M-5 -9 L-2 -27 L6 -9Z', col, sw=2.5)]
    return p, (3, -3), ear, (0, -9)


def head_donkey(c):
    col = c['skin']
    p = [el(9, 5, 24, 11.5, col, rot=30), el(26, 14, 9, 8, '#ECE8E2', rot=30), ci(31, 14, 1.8, O, False)]
    ear = [pa('M-6 -8 Q-8 -36 2 -34 Q8 -22 6 -8Z', col, sw=2.5), pa('M-3 -10 Q-4 -30 2 -29 Q4 -20 3 -10Z', '#F7C6D4', st=False)]
    return p, (3, -3), ear, (0, -8)


def head_pig(c):
    p = [el(0, 0, 17, 15, c['skin']), el(16, 3, 7.5, 8.5, '#F27A9B'), ci(18, 1, 1.8, O, False), ci(18, 6, 1.8, O, False)]
    ear = [pa('M-6 -9 L2 -22 L9 -8Z', '#F27A9B', sw=2.5)]
    return p, (4, -4), ear, (0, -9)


def head_sheep(c):
    wool = [ci(-6, -10, 8, '#FFFFFF', sw=2.5), ci(3, -13, 8, '#FFFFFF', sw=2.5), ci(-12, -2, 7, '#FFFFFF', sw=2.5)]
    p = wool + [el(5, 3, 12, 13, '#F3D9C4', rot=15), el(12, 10, 6, 5, '#E7B9A0', st=False), ci(15, 9, 1.4, O, False)]
    ear = [el(-8, 2, 9, 4.5, '#3C3550', rot=60)]
    return p, (7, -1), ear, (-6, -1)


def head_goat(c):
    col = c['skin']
    p = [pa('M-4 -10 Q-18 -22 -10 -34 Q-6 -24 2 -12Z', '#E9D8B8', sw=2.5),
         el(2, 2, 13, 12, col, rot=18), el(14, 9, 7.5, 6.5, '#F0E2CC', rot=15), ci(17, 8, 1.4, O, False),
         pa('M12 14 L16 26 L9 16Z', '#F0E2CC', sw=2.5)]
    ear = [el(-9, 0, 10, 4.5, col, rot=-15)]
    return p, (5, -3), ear, (-6, -1)


def head_cat(c):
    col = c['skin']
    p = [el(0, 0, 15, 13, col), el(12, 5, 6.5, 5, c.get('muzzle', '#FBE3C6')), pa('M15 2 L19 2 L17 5Z', '#F27A9B', sw=1.5),
         line('M12 6 L26 3 M12 8 L26 10', 1.6, O)]
    for i in range(2):
        p.append(line(f'M{-2+i*5} -12 L{-1+i*5} -6', 2.4, c.get('stripe', shade(col, .75))))
    ear = [pa('M-8 -9 L-6 -26 L5 -11Z', col, sw=2.5), pa('M-6 -11 L-5 -22 L2 -12Z', '#F8C6D4', st=False)]
    return p, (5, -3), ear, (-2, -10)


def head_dog(c):
    col = c['skin']
    p = [el(0, 0, 14, 13, col), el(15, 5, 11, 7, c.get('muzzle', '#F6E4CE'), rot=8), ci(25, 3, 3.2, K, False),
         pa('M17 10 Q21 20 25 11Z', '#F27A9B', sw=2), line('M13 9 L22 9', 1.8, O)]
    ear = [el(-3, 2, 6.5, 12, c.get('ear', shade(col, .6)), rot=15)]
    return p, (5, -3), ear, (-3, -6)


def head_lion(c):
    mane = [ci(-1 + 18 * math.cos(math.radians(a)), 2 + 18 * math.sin(math.radians(a)), 9, '#E8872E', sw=2.5) for a in range(0, 360, 40)]
    p = mane + [ci(-1, 2, 19, '#E8872E', sw=2.5), el(3, 3, 13, 12, c['skin']), el(13, 8, 7.5, 6, '#FCE2A8'), pa('M15 4 L20 4 L17.5 8Z', K, sw=1.5)]
    ear = [ci(-6, -14, 5, '#F7B648', sw=2.5)]
    return p, (6, -2), ear, (-6, -12)


def head_rabbit(c):
    col = c['skin']
    p = [el(0, 0, 13, 12, col), el(11, 5, 7, 6, '#FFFFFF'), pa('M15 3 L19 3 L17 6Z', '#F27A9B', sw=1.5), line('M14 7 L16 10', 1.6, O)]
    ear = [el(-3, -22, 5.5, 18, col, rot=12), el(-3, -21, 2.6, 13, '#F8C6D4', rot=12, st=False)]
    return p, (4, -3), ear, (-2, -6)


def head_elephant(c):
    col = c['skin']
    p = [el(0, 0, 22, 20, col), pa('M14 4 Q36 8 34 28 Q33 40 26 38 Q30 26 22 20Z', col, sw=SW),
         pa('M10 12 Q14 24 22 24 Q16 18 14 12Z', '#FFF8E8', sw=2)]
    ear = [el(-14, 4, 14, 19, c.get('ear', '#C9B8E2'), rot=-6), el(-13, 5, 8, 13, '#E6DCF3', st=False, rot=-6)]
    return p, (7, -6), ear, (-8, -8)


def head_giraffe(c):
    col = c['skin']
    p = [line('M-3 -8 L-6 -22', 3, O), ci(-6, -23, 3.2, '#8B5A2B', sw=2), line('M4 -9 L4 -24', 3, O), ci(4, -25, 3.2, '#8B5A2B', sw=2),
         el(2, 0, 14, 10, col, rot=22), el(14, 7, 8, 6.5, '#FBE9A8', rot=22), ci(18, 7, 1.4, O, False), el(-3, -3, 3.5, 2.5, c['spot'], st=False)]
    ear = [el(-9, -2, 8, 3.5, col, rot=-25)]
    return p, (5, -3), ear, (-6, -2)


def head_hippo(c):
    col = c['skin']
    p = [el(7, 3, 25, 15, col), ci(26, -5, 4, shade(col, .85), sw=2), ci(18, -8, 3.5, shade(col, .85), sw=2),
         ci(0, -13, 6, col, sw=2.5), line('M-8 8 Q8 15 30 9', 2.2, O), el(30, 3, 4, 3, shade(col, .8), st=False)]
    ear = [el(-14, -10, 5, 7, shade(col, .85), rot=-30)]
    return p, (0, -13), ear, (-12, -8)


def head_rhino(c):
    col = c['skin']
    p = [pa('M18 -4 L26 -26 L31 -2Z', '#E8E1D0', sw=2.5), el(5, 4, 22, 14, col, rot=15), el(22, 10, 7, 7, shade(col, .85), rot=15),
         ci(26, 12, 1.6, O, False), line('M-6 12 Q10 18 24 16', 2, O)]
    ear = [el(-12, -10, 5, 9, shade(col, .85), rot=-20)]
    return p, (4, -3), ear, (-10, -6)


def head_zebra(c):
    p, eye, ear, ep = head_horse({'skin': '#F4F4F4', 'muzzle': '#9A98A6'})
    p += [line('M-4 -8 L2 2 M4 -9 L10 3 M12 -7 L18 4 M-10 -2 L-6 6', 3, K)]
    ear = [pa('M-5 -9 L-2 -27 L6 -9Z', '#F4F4F4', sw=2.5), line('M0 -12 L1 -22', 2.4, K)]
    return p, eye, ear, ep


def head_monkey(c):
    col = c['skin']
    p = [el(0, 0, 14, 13, col), el(8, 4, 9, 8.5, '#F2C9A0'), ci(14, 6, 1.6, O, False), line('M7 10 Q12 13 16 9', 2, O)]
    ear = [ci(-9, 0, 6, '#F2C9A0', sw=2.5)]
    return p, (6, -2), ear, (-8, 0)


def head_croc(c):
    col = c['skin']
    p = [pa('M4 -9 L46 -6 Q56 1 46 9 L4 11Z', col, sw=SW), el(0, 1, 14, 12, col),
         pa('M12 9 L15 14 L18 9 L22 14 L26 9 L30 14 L34 9 L38 14 L42 9', '#FFFFFF', sw=1.8),
         ci(46, -3, 1.6, O, False), ci(2, -11, 6, col, sw=2.5)]
    return p, (3, -11), None, None


# aves
def head_hen(c):
    col = c['skin']
    p = [ci(-2, -12, 4.5, c.get('comb', '#E53E3E'), sw=2), ci(3, -14, 5, c.get('comb', '#E53E3E'), sw=2), ci(8, -11, 4, c.get('comb', '#E53E3E'), sw=2),
         el(0, 0, 11, 10, col), pa('M9 -2 L20 2 L9 6Z', '#FFA928', sw=2.2), el(8, 10, 3.2, 5, c.get('comb', '#E53E3E'), sw=2)]
    return p, (3, -2), None, None


def head_rooster(c):
    p = [ci(-4, -13, 5, '#D7263D', sw=2), ci(2, -17, 6, '#D7263D', sw=2), ci(9, -13, 5, '#D7263D', sw=2),
         el(0, 0, 11, 10, c['skin']), pa('M9 -2 L21 2 L9 6Z', '#FFC93C', sw=2.2), el(8, 11, 3.5, 6, '#D7263D', sw=2)]
    return p, (3, -2), None, None


def head_duck(c):
    p = [el(0, 0, 11.5, 10.5, c['skin']), el(14, 4, 10, 4.2, '#FF9F1C', rot=4, sw=2.5), line('M6 4 L22 5', 1.4, O)]
    return p, (4, -2), None, None


def head_ostrich(c):
    p = [el(0, 0, 9, 8, '#EBC9A6'), pa('M7 -1 L16 1 L7 4Z', '#F2A33A', sw=2), line('M-2 -8 L-4 -13 M1 -8 L1 -14 M4 -8 L5 -13', 1.8, '#C9A07A')]
    return p, (2, -2), None, None


def head_parrot(c):
    p = [pa('M-6 -9 Q-8 -22 4 -21 Q4 -14 2 -9Z', '#E53E3E', sw=2.2), el(0, 0, 12.5, 11.5, '#3FBF6C'), el(4, -1, 7.5, 7, '#FFF6D8', st=False),
         pa('M7 -6 Q24 -8 22 8 Q20 3 11 4Z', '#FFA928', sw=2.4), pa('M11 4 Q17 12 22 8', '#E8891E', st=False)]
    return p, (3, -2), None, None


QUAD_HEADS = dict(cow=head_cow, horse=head_horse, donkey=head_donkey, pig=head_pig, sheep=head_sheep, goat=head_goat,
                  cat=head_cat, dog=head_dog, lion=head_lion, cheetah=head_cat, rabbit=head_rabbit, elephant=head_elephant,
                  giraffe=head_giraffe, hippopotamus=head_hippo, rhinoceros=head_rhino, zebra=head_zebra, monkey=head_monkey,
                  crocodile=head_croc)


# ---------------------------------------------------------------- cauda
def tail_parts(kind, bx, by, c, c2=None):
    c2 = c2 or c
    if kind == 'tuft':
        d = f'M{bx} {by} Q{bx-20} {by+6} {bx-16} {by+34}'
        return [line(d, 5 + 2 * SW, O), line(d, 5, c), el(bx - 16, by + 40, 6.5, 10, c2, rot=8, sw=SW)]
    if kind == 'mane':  # cauda de cavalo: cabelo escorrendo
        return [pa(f'M{bx} {by-4} Q{bx-26} {by-2} {bx-22} {by+40} Q{bx-12} {by+26} {bx-4} {by+6}Z', c2, sw=SW)]
    if kind == 'long':
        d = f'M{bx} {by} Q{bx-34} {by+2} {bx-30} {by-34}'
        return [line(d, 7 + 2 * SW, O), line(d, 7, c), line(f'M{bx-30} {by-34} L{bx-30} {by-27}', 7, c2)]
    if kind == 'upcurl':
        d = f'M{bx} {by} Q{bx-22} {by-6} {bx-20} {by-26}'
        return [line(d, 7 + 2 * SW, O), line(d, 7, c)]
    if kind == 'pom':
        return [ci(bx - 6, by, 8, c, sw=SW)]
    if kind == 'curl':
        d = f'M{bx} {by} Q{bx-14} {by-4} {bx-10} {by-14} Q{bx-6} {by-20} {bx-2} {by-14}'
        return [line(d, 4 + 2 * SW, O), line(d, 4, c)]
    if kind == 'short':
        return [el(bx - 4, by + 3, 6, 9, c, rot=40, sw=SW)]
    if kind == 'croc':
        pts = f'M{bx} {by-10} Q{bx-30} {by-8} {bx-44} {by+20} Q{bx-26} {by+14} {bx} {by+12}Z'
        sp = ''.join(pa(f'M{bx-8-8*i} {by-8+i*3} L{bx-12-8*i} {by-16+i*4} L{bx-16-8*i} {by-7+i*4}Z', '#4E9A4E', sw=2) for i in range(4))
        return [pa(pts, c, sw=SW), sp]
    if kind == 'monkey':
        d = f'M{bx} {by} Q{bx-30} {by+4} {bx-34} {by-24} Q{bx-36} {by-44} {bx-20} {by-42}'
        return [line(d, 6 + 2 * SW, O), line(d, 6, c)]
    return []


# ---------------------------------------------------------------- deco do corpo
def body_deco(kind, bx, by, rx, ry, col):
    out = []
    def yspan(x, k=.85):
        u = (x - bx) / rx
        return ry * math.sqrt(max(0, 1 - u * u)) * k
    if kind == 'cow':
        out += [el(bx - 14, by - 6, 13, 9, K, st=False), el(bx + 14, by + 8, 11, 8, K, st=False), el(bx + 24, by - 12, 8, 6, K, st=False)]
    elif kind == 'stripes':
        for x in range(int(bx - rx * .7), int(bx + rx * .75), 12):
            h = yspan(x)
            out.append(line(f'M{x} {by-h:.0f} Q{x+4} {by} {x} {by+h:.0f}', 5, K))
    elif kind == 'spots':
        for dx, dy in [(-30, -8), (-14, 6), (2, -12), (16, 4), (30, -8), (-4, 12), (24, 14), (-24, 12)]:
            out.append(ci(bx + dx, by + dy, 4.2, col, False))
    elif kind == 'patches':  # girafa
        for dx, dy, r in [(-28, -6, 8), (-8, 8, 9), (12, -8, 8), (30, 6, 7), (-18, 12, 5), (24, -14, 5)]:
            out.append(el(bx + dx, by + dy, r, r * .85, col, rot=20, st=False))
    elif kind == 'tabby':
        for x in range(int(bx - rx * .6), int(bx + rx * .65), 12):
            h = yspan(x, .8)
            out.append(line(f'M{x} {by-h:.0f} L{x+2} {by-h*.35:.0f}', 4, col))
    elif kind == 'croc':
        for x in range(int(bx - rx * .6), int(bx + rx * .6), 14):
            h = yspan(x, 1.0)
            out.append(pa(f'M{x-4} {by-h:.0f} L{x} {by-h-7:.0f} L{x+4} {by-h:.0f}Z', col, sw=2.2))
    elif kind == 'feathers':
        for dx, dy in [(-4, 8), (10, 8), (-18, 8), (4, 18), (-10, 18)]:
            out.append(line(f'M{bx+dx-5} {by+dy} Q{bx+dx} {by+dy+7} {bx+dx+5} {by+dy}', 2.4, col))
    return out


# ---------------------------------------------------------------- quadrúpedes
Q = {
    'cow': dict(body=(88, 110, 46, 28), color='#FFFFFF', belly='#FFF4F4', deco='cow', leg=(16, 13, 'hoof'), foot_c=K,
                tail='tuft', tail_c='#FFFFFF', tail_c2=K, head=(146, 86), wn=26, skin='#FFFFFF', patch=True),
    'horse': dict(body=(88, 108, 48, 26), color='#B97A4B', belly='#D7A27A', leg=(13, 9, 'hoof'), foot_c=K,
                  tail='mane', tail_c='#B97A4B', tail_c2='#6B3F25', head=(150, 74), wn=25, skin='#B97A4B', mane='#6B3F25'),
    'donkey': dict(body=(88, 110, 44, 25), color='#9BA2AC', belly='#ECE8E2', leg=(12, 8, 'hoof'), foot_c='#4A4F5A',
                   tail='tuft', tail_c='#9BA2AC', tail_c2='#5E636E', head=(148, 80), wn=24, skin='#9BA2AC', mane='#5E636E'),
    'pig': dict(body=(88, 116, 46, 28), color='#F9A8BD', belly='#FBC7D4', leg=(15, 12, 'hoof'), foot_c='#F27A9B',
                tail='curl', tail_c='#F27A9B', head=(140, 108), wn=32, skin='#F9A8BD', hipk=.35),
    'sheep': dict(hs=1.15, body=(88, 112, 42, 28), color='#FFFFFF', wool=True, leg=(9, 8, 'hoof'), leg_c='#3C3550', foot_c='#3C3550',
                  tail='pom', tail_c='#FFFFFF', head=(138, 100), wn=26, skin='#F3D9C4', hipk=.55),
    'goat': dict(body=(88, 112, 40, 24), color='#D8C4A5', belly='#F0E2CC', leg=(10, 7, 'hoof'), foot_c='#5A4632',
                 tail='short', tail_c='#D8C4A5', head=(140, 86), wn=20, skin='#D8C4A5'),
    'cat': dict(body=(86, 118, 42, 20), color='#F2A65A', belly='#FBE3C6', deco='tabby', deco_c='#C97B2E', leg=(10, 8, 'paw'),
                foot_c='#FBE3C6', tail='long', tail_c='#F2A65A', tail_c2='#C97B2E', head=(130, 102), wn=20, skin='#F2A65A', hipk=.4),
    'dog': dict(body=(86, 114, 44, 22), color='#D0A57A', belly='#F6E4CE', leg=(11, 9, 'paw'), foot_c='#F6E4CE',
                tail='upcurl', tail_c='#D0A57A', head=(136, 96), wn=22, skin='#D0A57A'),
    'lion': dict(hs=1.1, body=(88, 112, 46, 26), color='#F7B648', belly='#FCE2A8', leg=(14, 11, 'paw'), foot_c='#F7B648',
                 tail='tuft', tail_c='#F7B648', tail_c2='#E8872E', head=(138, 94), wn=28, skin='#F7B648'),
    'cheetah': dict(body=(86, 114, 44, 19), color='#EAB65A', belly='#FBE7BE', deco='spots', deco_c='#6B4423', leg=(10, 7, 'paw'),
                    foot_c='#EAB65A', tail='long', tail_c='#EAB65A', tail_c2='#6B4423', head=(136, 98), wn=19, skin='#EAB65A', stripe='#6B4423'),
    'rabbit': dict(body=(84, 126, 34, 24), color='#F6D5E6', belly='#FFFFFF', leg=(22, 12, 'paw'), foot_c='#F6D5E6',
                   tail='pom', tail_c='#FFFFFF', head=(120, 100), wn=22, skin='#F6D5E6', hipk=.2),
    'elephant': dict(hs=1.0, body=(86, 106, 50, 36), color='#A993CB', belly='#C9B8E2', leg=(24, 21, 'stub'), foot_c='#A993CB',
                     tail='short', tail_c='#8A74B0', head=(144, 90), wn=36, skin='#A993CB', ear='#C9B8E2', hipk=.5),
    'giraffe': dict(hs=1.35, body=(78, 100, 40, 22), color='#F8D448', belly='#FBE9A8', deco='patches', deco_c='#C77A2B', leg=(9, 7, 'hoof'),
                    foot_c='#8B5A2B', tail='tuft', tail_c='#F8D448', tail_c2='#8B5A2B', head=(134, 30), wn=17, skin='#F8D448',
                    spot='#C77A2B', shoulder=(100, 88), neck_w=(24, 14), neck_spots='#C77A2B'),
    'zebra': dict(body=(88, 108, 46, 25), color='#F4F4F4', belly='#FFFFFF', deco='stripes', leg=(12, 8, 'hoof'), foot_c=K,
                  tail='mane', tail_c='#F4F4F4', tail_c2=K, head=(150, 74), wn=24, skin='#F4F4F4', mane=K),
    'monkey': dict(body=(88, 112, 36, 22), color='#B76A49', belly='#F2C9A0', leg=(9, 6, 'paw'), foot_c='#F2C9A0',
                   tail='monkey', tail_c='#B76A49', head=(126, 92), wn=22, skin='#B76A49'),
    'hippopotamus': dict(hs=1.05, body=(88, 118, 54, 32), color='#8EA6D8', belly='#A9BDE6', leg=(24, 21, 'stub'), foot_c='#8EA6D8',
                         tail='short', tail_c='#8EA6D8', head=(144, 108), wn=40, skin='#8EA6D8', hipk=.45),
    'rhinoceros': dict(hs=1.05, body=(88, 114, 50, 30), color='#9CA4AF', belly='#B7BFC9', leg=(22, 19, 'stub'), foot_c='#9CA4AF',
                       tail='tuft', tail_c='#9CA4AF', tail_c2='#7C838D', head=(146, 104), wn=34, skin='#9CA4AF', hipk=.45),
    'crocodile': dict(body=(92, 140, 56, 17), hs=1.0, color='#6CBF6A', belly='#A8DB8F', deco='croc', deco_c='#4E9A4E', leg=(13, 11, 'paw'),
                      foot_c='#6CBF6A', tail='croc', tail_c='#6CBF6A', head=(136, 132), wn=20, skin='#6CBF6A', hipk=.3, foot_y=176),
}


def build_quad(id_, a):
    bx, by, rx, ry = a['body']
    col = a['color']
    hipy = by + ry * a.get('hipk', .42)
    fy = a.get('foot_y', GROUND - 2)
    wt, wb, fk = a['leg']
    if wt < 20:
        wt, wb = wt * 1.2, wb * 1.2
    lc = a.get('leg_c', col)
    fc = a.get('foot_c', lc)
    hb, hf = bx - rx * .58, bx + rx * .58
    layers = []

    # cauda
    t = a.get('tail')
    if t:
        tbx, tby = bx - rx + 4, by - ry * .25
        if t == 'croc':
            tbx, tby = bx - rx + 6, by
        layers.append(('tail', tail_parts(t, tbx, tby, a['tail_c'], a.get('tail_c2')), (tbx, tby)))

    def leg(role, hx, off, far):
        c1 = shade(lc, .78) if far else lc
        c2 = shade(fc, .78) if far else fc
        fx = hx + off
        if id_ == 'rabbit' and role in ('legBN', 'legBF'):
            parts = [el(hx - 2, hipy + 8, 17, 16, c1, sw=SW), el(fx + 6, fy - 3, 20, 6, c1, sw=SW)]
            return (role, parts, (hx, hipy))
        parts = [limb(hx, hipy, fx, fy - 2, wt, wb, c1), foot(fk, fx, fy, wb, c2)]
        return (role, parts, (hx, hipy))

    layers.append(leg('legBF', hb, 8, True))
    layers.append(leg('legFF', hf, 8, True))
    layers.append(leg('legBN', hb, 0, False))
    layers.append(leg('legFN', hf, 0, False))

    # corpo
    if a.get('wool'):
        pts = [(bx - 24, by - 8, 18), (bx - 4, by - 14, 19), (bx + 18, by - 10, 18), (bx + 30, by + 2, 15), (bx - 32, by + 8, 14),
               (bx - 14, by + 10, 18), (bx + 8, by + 12, 18), (bx + 24, by + 12, 14)]
        body = [ci(x, y, r, '#FFFFFF', sw=SW) for x, y, r in pts] + [ci(x, y, r - 2, '#FFFFFF', False) for x, y, r in pts]
    else:
        body = [el(bx, by, rx, ry, col, sw=SW)]
        if a.get('belly'):
            body.append(el(bx, by + ry * .35, rx * .72, ry * .5, a['belly'], st=False))
        body += body_deco(a.get('deco'), bx, by, rx, ry, a.get('deco_c', K))
    layers.append(('body', body, (bx, by + ry)))

    # cabeça + pescoço
    hx, hy = a['head']
    sx, sy = a.get('shoulder', (bx + rx * .55, by - ry * .35))
    skin = a['skin']
    hp, eye, ear, ep = QUAD_HEADS[id_]({'skin': skin, 'spot': a.get('spot'), 'patch': a.get('patch'), 'ear': a.get('ear'), 'stripe': a.get('stripe')})
    neck_w = a.get('neck_w', (a['wn'], a['wn'] * .8))
    parts = []
    if a.get('mane'):
        parts.append(line(f'M{sx-2:.0f} {sy-neck_w[0]/2:.0f} L{hx-8:.0f} {hy-6:.0f}', 8, a['mane']))
    parts.append(limb(sx, sy, hx - 2, hy + 2, neck_w[0], neck_w[1], skin))
    if a.get('neck_spots'):
        for k in (0.3, 0.55, 0.8):
            parts.append(el(sx + (hx - sx) * k, sy + (hy - sy) * k, 4, 3.4, a['neck_spots'], st=False))
    parts.append(ci(sx, sy, neck_w[0] / 2 + 1, skin, st=False))
    hs = a.get('hs', 1.25)
    parts.append(grp(hp, hx, hy, 0, hs))
    layers.append(('head', parts, (sx, sy)))
    if ear:
        role = 'earBack' if id_ in ('elephant', 'hippopotamus', 'rhinoceros') else 'ear'
        if role == 'earBack':
            layers.insert(len(layers) - 1, (role, [grp(ear, hx, hy, 0, hs)], (hx + ep[0] * hs, hy + ep[1] * hs)))
        else:
            layers.append((role, [grp(ear, hx, hy, 0, hs)], (hx + ep[0] * hs, hy + ep[1] * hs)))
    return layers, [(hx + eye[0] * hs, hy + eye[1] * hs)], a.get('eye_r', 4.6)


# ---------------------------------------------------------------- aves e sapo
def bird_legs(hipx_list, hipy, fy, c, w=5):
    out = []
    for role, hx in zip(('legBN', 'legFN'), hipx_list):
        out.append((role, [limb(hx, hipy, hx + 2, fy - 2, w, w - 1, c), foot('claw', hx + 2, fy, w, c)], (hx, hipy)))
    return out


def head_layer(neck, hx, hy, hp, skin, sx, sy, w1, w2):
    parts = [limb(sx, sy, hx - 2, hy + 4, w1, w2, skin), ci(sx, sy, w1 / 2 + 1, skin, st=False), grp(hp, hx, hy)]
    return ('head', parts, (sx, sy))


def build_hen(id_):
    rooster = id_ == 'rooster'
    col = '#E9573F' if rooster else '#FFF3D6'
    belly = '#F58A5E' if rooster else '#FFFFFF'
    wing_c = '#E8913D' if rooster else '#EACB93'
    layers = []
    cols = ['#2E9E8F', '#E8913D', '#E9573F', '#E8913D', '#2E9E8F'] if rooster else ['#EACB93', '#F7E2B8', '#EACB93']
    n = len(cols)
    tail = []
    for i, cc in enumerate(cols):
        a = -62 + i * (60 / max(1, n - 1)) * (1.0 if n > 1 else 0)
        r = math.radians(a)
        tail.append(el(52 + 16 * math.sin(r) - 10, 98 - 18 * math.cos(r), 9 if not rooster else 10, 26 if not rooster else 32, cc, rot=a, sw=SW))
    layers.append(('tail', tail, (62, 112)))
    layers += bird_legs([82, 98], 134, GROUND - 2, '#FFC93C' if rooster else '#FFA928')
    layers.append(('body', [el(88, 116, 36, 28, col, rot=-8, sw=SW), el(94, 126, 22, 15, belly, rot=-8, st=False)], (88, 144)))
    layers.append(('wing', [el(86, 116, 21, 13, wing_c, rot=-14, sw=SW), line('M72 120 Q86 124 100 114', 2, shade(wing_c, .8))], (102, 108)))
    hp, eye, _, _ = (head_rooster if rooster else head_hen)({'skin': col if rooster else '#FFF3D6'})
    hx, hy = (126, 80) if rooster else (122, 86)
    layers.append(head_layer(None, hx, hy, hp, col if rooster else '#FFF3D6', 104, 110, 18, 14))
    return layers, [(hx + eye[0], hy + eye[1])], 3.6


def build_duck(id_):
    layers = []
    layers.append(('tail', [pa('M54 120 Q40 104 36 100 Q46 116 56 132Z', '#F5C21B', sw=SW)], (56, 124)))
    for role, hx in (('legBN', 86), ('legFN', 100)):
        layers.append((role, [limb(hx, 142, hx + 2, GROUND - 4, 6, 5, '#FF9F1C'), foot('webbed', hx + 2, GROUND - 2, 6, '#FF9F1C')], (hx, 142)))
    layers.append(('body', [el(90, 124, 40, 25, '#FFD84A', rot=-4, sw=SW), el(94, 134, 26, 13, '#FFE98A', st=False)], (90, 149)))
    layers.append(('wing', [el(86, 122, 22, 13, '#F5C21B', rot=-12, sw=SW), line('M70 124 Q86 128 102 118', 2, '#D9A30F')], (104, 114)))
    hp, eye, _, _ = head_duck({'skin': '#FFD84A'})
    hx, hy = 124, 88
    layers.append(head_layer(None, hx, hy, hp, '#FFD84A', 108, 112, 20, 15))
    return layers, [(hx + eye[0], hy + eye[1])], 3.6


def build_ostrich(id_):
    layers = []
    tail = [el(48, 100 + i * 8 - 8, 12, 17, '#FFFFFF', rot=-30 + i * 25, sw=SW) for i in range(3)]
    layers.append(('tail', tail, (58, 112)))
    layers += bird_legs([76, 92], 134, GROUND - 2, '#EBC9A6', 7)
    layers.append(('body', [el(80, 112, 36, 30, '#3A3550', rot=-6, sw=SW), el(86, 124, 22, 14, '#4B4566', st=False)], (80, 142)))
    layers.append(('wing', [el(80, 108, 24, 15, '#FFFFFF', rot=-14, sw=SW), line('M62 112 Q80 118 98 106', 2, '#CFCFCF')], (100, 100)))
    hx, hy = 138, 24
    hp, eye, _, _ = head_ostrich({})
    neck = [line('M104 96 Q134 86 126 58 Q122 40 134 28', 14 + 2 * SW, O), line('M104 96 Q134 86 126 58 Q122 40 134 28', 14, '#EBC9A6'),
            ci(104, 96, 8, '#EBC9A6', st=False), grp(hp, hx, hy)]
    layers.append(('head', neck, (104, 96)))
    return layers, [(hx + eye[0], hy + eye[1])], 3.6


def build_parrot(id_):
    layers = []
    tl = [el(70, 160, 7, 24, '#E53E3E', rot=22, sw=SW), el(78, 162, 7, 24, '#2E86DE', rot=14, sw=SW), el(86, 160, 6, 22, '#FFC93C', rot=6, sw=SW)]
    layers.append(('tail', tl, (92, 136)))
    layers += bird_legs([92, 104], 142, GROUND - 2, '#FFA928', 5)
    layers.append(('body', [el(96, 108, 23, 38, '#3FBF6C', rot=10, sw=SW), el(102, 114, 14, 26, '#B6EFA0', rot=10, st=False)], (96, 146)))
    layers.append(('wing', [el(90, 114, 13, 28, '#2E86DE', rot=12, sw=SW), line('M86 100 Q92 118 90 134', 2, '#1F5FA8')], (94, 92)))
    hp, eye, _, _ = head_parrot({})
    hx, hy = 108, 62
    layers.append(head_layer(None, hx, hy, hp, '#3FBF6C', 100, 90, 22, 18))
    return layers, [(hx + eye[0], hy + eye[1])], 4.0


def build_owl(id_):
    layers = []
    layers += bird_legs([88, 112], 150, GROUND - 2, '#FFB62E', 6)
    body = [el(100, 128, 34, 38, '#A98462', sw=SW), el(100, 138, 22, 26, '#FFF3DC', st=False)]
    body += body_deco('feathers', 100, 128, 34, 38, '#C9A98A')
    layers.append(('body', body, (100, 166)))
    layers.append(('wing', [pa('M70 104 Q50 120 58 152 Q72 150 80 128Z', '#7A5A3E', sw=SW)], (72, 106)))
    layers.append(('wing2', [pa('M130 104 Q150 120 142 152 Q128 150 120 128Z', '#7A5A3E', sw=SW)], (128, 106)))
    parts, eyes, er = G.owl()
    keep = [p for i, p in enumerate(parts) if i not in (0, 1)]
    hs = .6
    tx, ty = 100 - 100 * hs, 62 - 100 * hs
    layers.append(('head', [grp(keep, tx, ty, 0, hs)], (100, 96)))
    return layers, [(round(tx + hs * x, 1), round(ty + hs * y, 1)) for x, y in eyes], round(er * hs, 2)


def build_frog(id_):
    g, lg = '#6CC24A', '#BDE88F'
    layers = []

    def hind(role, far):
        c = shade(g, .8) if far else g
        off = 8 if far else 0
        return (role, [el(66 + off, 138, 20, 16, c, rot=-20, sw=SW),
                       pa(f'M{74+off} 146 L{92+off} 166 L{56+off} 172 L{58+off} 164 L{80+off} 158Z', c, sw=SW),
                       foot('webbed', 56 + off, 174, 8, c)], (66 + off, 138))
    layers.append(hind('legBF', True))
    layers.append(('legFF', [limb(130, 140, 140, GROUND - 3, 9, 8, shade(g, .8)), foot('webbed', 140, GROUND - 1, 8, shade(g, .8))], (130, 140)))
    layers.append(hind('legBN', False))
    layers.append(('legFN', [limb(122, 140, 128, GROUND - 3, 10, 8, g), foot('webbed', 128, GROUND - 1, 8, g)], (122, 140)))
    layers.append(('body', [el(92, 132, 44, 28, g, sw=SW), el(98, 146, 30, 14, lg, st=False),
                            ci(70, 120, 4, '#4FA03A', False), ci(88, 112, 4.5, '#4FA03A', False), ci(106, 118, 3.6, '#4FA03A', False)], (92, 160)))
    hp = [ci(130, 90, 11, g, sw=SW), el(130, 112, 26, 19, g, sw=SW), line('M112 118 Q136 128 154 114', 3, O), ci(150, 108, 1.6, O, False),
          el(126, 106, 12, 8, '#4FA03A', st=False, op=.0001)]
    layers.append(('head', hp, (112, 124)))
    return layers, [(130, 90)], 5.5


BUILDERS = {'hen': build_hen, 'rooster': build_hen, 'duck': build_duck, 'ostrich': build_ostrich, 'parrot': build_parrot,
            'owl': build_owl, 'frog': build_frog}


def build(id_):
    if id_ in BUILDERS:
        return BUILDERS[id_](id_)
    return build_quad(id_, Q[id_])


def main():
    out_dir = 'assets/images/rig'
    os.makedirs(out_dir, exist_ok=True)
    for f in glob.glob(out_dir + '/*.svg'):
        os.remove(f)
    n = 0
    for cat in ('farm', 'safari'):
        path = f'assets/data/{cat}.json'
        data = json.load(open(path, encoding='utf-8'))
        for it in data['items']:
            layers, eyes, er = build(it['id'])
            spec = []
            for role, parts, pivot in layers:
                asset = f'{out_dir}/{it["id"]}_{role}.svg'
                open(asset, 'w', encoding='utf-8').write(G.svg(parts if isinstance(parts, list) else [parts]))
                spec.append({'role': role, 'asset': asset, 'pivot': [round(pivot[0], 1), round(pivot[1], 1)]})
            it['rig'] = {'layers': spec, 'eyes': [[round(x, 1), round(y, 1)] for x, y in eyes], 'eyeRadius': er, 'facing': 'right'}
            n += 1
        json.dump(data, open(path, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    print('rigs ok:', n)


if __name__ == '__main__':
    main()
