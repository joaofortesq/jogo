#!/usr/bin/env python3
"""Gera os bichos de FRENTE, com corpo de animal de verdade, em camadas SVG.

Mamíferos: cabeça grande, peito, duas patas da frente retas, ancas e patinhas
de trás aparecendo dos lados, rabo e orelhas separadas. Aves, sapo, coruja e
crocodilo usam o desenho de rig_front_base.py.

Camadas (assets/images/rig/<id>_<papel>.svg): shadow, tail, hindL, hindR, body,
legL, legR, armL, armR (asas), earL, earR, head.
O JSON da categoria ganha a chave "rig" (camadas, pontos de giro, olhos, boca).

Uso (raiz do projeto):  python3 tools/generate_rigs.py
"""
import json, math, os, sys, glob

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import generate_art as G
import rig_front_base as F
from generate_art import O, K, el, ci, pa, line

SW = 3
HNAME = {'hippopotamus': 'hippo', 'rhinoceros': 'rhino'}

# elementos de generate_art.py que NÃO fazem parte da cabeça (sombra, peitoral, pescoço, corpo...)
DROP = {
    'cow': [0, 1, 2], 'horse': [0, 1], 'pig': [0, 1], 'sheep': [0, 1], 'goat': [0, 1], 'donkey': [0, 1],
    'rabbit': [0, 1], 'cat': [0, 1], 'dog': [0, 1], 'lion': [0], 'elephant': [0], 'giraffe': [4, 5, 6, 7, 8],
    'zebra': [0, 1], 'monkey': [0, 1], 'hippopotamus': [0, 1], 'rhinoceros': [0, 1], 'cheetah': [0, 1],
}
# orelhas (índices) à esquerda e à direita, e seus pontos de giro (coordenadas da arte original)
EARS = {
    'cow': ([5], [6], (64, 84), (136, 84)), 'horse': ([4], [5], (76, 52), (124, 52)),
    'pig': ([2], [3], (70, 58), (130, 58)), 'sheep': ([9], [10], (56, 100), (144, 100)),
    'goat': ([4], [5], (60, 92), (140, 92)), 'donkey': ([2, 3], [4, 5], (72, 64), (128, 64)),
    'rabbit': ([2, 3], [4, 5], (80, 78), (120, 78)), 'cat': ([2, 4], [3, 5], (78, 68), (122, 68)),
    'dog': ([2], [3], (66, 62), (134, 62)), 'elephant': ([1, 2], [3, 4], (62, 86), (138, 86)),
    'giraffe': ([9], [10], (62, 58), (138, 58)), 'zebra': ([2], [3], (78, 50), (122, 50)),
    'monkey': ([2, 3], [4, 5], (60, 100), (140, 100)), 'hippopotamus': ([2], [3], (62, 60), (138, 60)),
    'rhinoceros': ([2], [3], (60, 58), (140, 58)), 'cheetah': ([2, 3], [4, 5], (62, 64), (138, 64)),
}
# boca (centro x, y, largura) na arte original
MOUTH = {
    'cow': (100, 138, 20), 'horse': (100, 154, 16), 'pig': (100, 148, 18), 'sheep': (100, 135, 14), 'goat': (100, 140, 14),
    'donkey': (100, 150, 16), 'rabbit': (100, 127, 16), 'cat': (100, 127, 18), 'dog': (100, 128, 20), 'lion': (100, 130, 20),
    'giraffe': (100, 94, 14), 'zebra': (100, 150, 16), 'monkey': (100, 129, 20), 'hippopotamus': (100, 144, 28),
    'rhinoceros': (100, 144, 16), 'cheetah': (100, 128, 18),
}


def shade(hexc, f=.8):
    h = hexc.lstrip('#')
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return '#%02X%02X%02X' % (min(255, int(r * f)), min(255, int(g * f)), min(255, int(b * f)))


def grp(parts, tx=0, ty=0, rot=0, s=1):
    t = f'translate({tx:.2f} {ty:.2f})' + (f' rotate({rot})' if rot else '') + (f' scale({s})' if s != 1 else '')
    return f'<g transform="{t}">' + ''.join(parts) + '</g>'


def limb(x1, y1, x2, y2, w, fill):
    d = f'M{x1} {y1} L{x2} {y2}'
    return line(d, w + 2 * SW, O) + line(d, w, fill)


# ------------------------------------------------------------------ configuração dos mamíferos
M = {
    'cow': dict(color='#FFFFFF', belly='#FFF4F4', rx=32, ry=34, cy=134, leg=(18, 'hoof', K), deco='cow',
                tail=('tuft', '#FFFFFF', K), hs=.72, hy=66),
    'horse': dict(color='#B97A4B', belly='#D7A27A', rx=28, ry=36, cy=134, leg=(15, 'hoof', K),
                  tail=('mane', '#B97A4B', '#6B3F25'), hs=.70, hy=64),
    'pig': dict(color='#F9A8BD', belly='#FBC7D4', rx=37, ry=32, cy=139, leg=(19, 'hoof', '#F27A9B'),
                tail=('curl', '#F27A9B', None), hs=.74, hy=70),
    'sheep': dict(color='#FFFFFF', wool=True, rx=34, ry=32, cy=136, leg=(13, 'hoof', '#3C3550'), leg_c='#3C3550',
                  tail=('pom', '#FFFFFF', None), hs=.70, hy=66),
    'goat': dict(color='#D8C4A5', belly='#F0E2CC', rx=27, ry=33, cy=136, leg=(13, 'hoof', '#5A4632'),
                 tail=('short', '#D8C4A5', None), hs=.72, hy=64),
    'donkey': dict(color='#9BA2AC', belly='#ECE8E2', rx=29, ry=34, cy=135, leg=(14, 'hoof', '#4A4F5A'),
                   tail=('tuft', '#9BA2AC', '#5E636E'), hs=.70, hy=64),
    'rabbit': dict(color='#F6D5E6', belly='#FFFFFF', rx=27, ry=30, cy=140, leg=(13, 'paw', '#F6D5E6'), bigfeet=True,
                   tail=('pom', '#FFFFFF', None), hs=.76, hy=70),
    'cat': dict(color='#F2A65A', belly='#FBE3C6', rx=27, ry=31, cy=139, leg=(13, 'paw', '#FBE3C6'), deco='tabby', deco_c='#C97B2E',
                tail=('long', '#F2A65A', '#C97B2E'), hs=.74, hy=68),
    'dog': dict(color='#D0A57A', belly='#F6E4CE', rx=29, ry=32, cy=138, leg=(14, 'paw', '#F6E4CE'),
                tail=('upcurl', '#D0A57A', None), hs=.72, hy=68),
    'lion': dict(color='#F7B648', belly='#FCE2A8', rx=34, ry=34, cy=137, leg=(17, 'paw', '#F7B648'),
                 tail=('tuft', '#F7B648', '#E8872E'), hs=.66, hy=66),
    'cheetah': dict(color='#EAB65A', belly='#FBE7BE', rx=26, ry=31, cy=139, leg=(12, 'paw', '#EAB65A'), deco='spots', deco_c='#6B4423',
                    tail=('long', '#EAB65A', '#6B4423'), hs=.74, hy=68),
    'elephant': dict(color='#A993CB', belly='#C9B8E2', rx=40, ry=38, cy=134, leg=(26, 'stub', '#A993CB'),
                     tail=('short', '#8A74B0', None), hs=.62, hy=64),
    'giraffe': dict(color='#F8D448', belly='#FBE9A8', rx=26, ry=28, cy=148, leg=(11, 'hoof', '#8B5A2B'), deco='patches', deco_c='#C77A2B',
                    tail=('tuft', '#F8D448', '#8B5A2B'), hs=.62, hy=40, hcy=64, neck=(18, 66, 126)),
    'zebra': dict(color='#F4F4F4', belly='#FFFFFF', rx=28, ry=36, cy=135, leg=(14, 'hoof', K), deco='stripes', deco_c=K,
                  tail=('tuft', '#F4F4F4', K), hs=.70, hy=64),
    'monkey': dict(color='#B76A49', belly='#F2C9A0', rx=28, ry=30, cy=139, leg=(11, 'paw', '#F2C9A0'),
                   tail=('monkey', '#B76A49', None), hs=.74, hy=68),
    'hippopotamus': dict(color='#8EA6D8', belly='#A9BDE6', rx=44, ry=34, cy=141, leg=(24, 'stub', '#8EA6D8'),
                         tail=('short', '#8EA6D8', None), hs=.66, hy=74),
    'rhinoceros': dict(color='#9CA4AF', belly='#B7BFC9', rx=40, ry=34, cy=139, leg=(22, 'stub', '#9CA4AF'),
                       tail=('tuft', '#9CA4AF', '#7C838D'), hs=.68, hy=70),
}


def foot(kind, x, y, w, c, side=1):
    if kind == 'hoof':
        return el(x, y - 2, w / 2 + 2, 6, c, sw=SW)
    if kind == 'paw':
        return el(x, y - 2, w / 2 + 4, 6.5, c, sw=SW) + line(f'M{x-3} {y-1} L{x-3} {y+2} M{x+3} {y-1} L{x+3} {y+2}', 1.6, O)
    if kind == 'stub':
        return el(x, y - 2, w / 2 + 2, 6, c, sw=SW) + ''.join(el(x - 7 + 7 * i, y + 1, 3, 2.4, '#FFF8E8', st=False) for i in range(3))
    return ''


def tail_parts(kind, c, c2, bx, by):
    c2 = c2 or c
    if kind == 'tuft':
        d = f'M{bx} {by} Q{bx+20} {by+6} {bx+16} {by+32}'
        return [line(d, 5 + 2 * SW, O), line(d, 5, c), el(bx + 16, by + 38, 6.5, 10, c2, rot=-8, sw=SW)]
    if kind == 'mane':
        return [pa(f'M{bx} {by-6} Q{bx+28} {by-2} {bx+22} {by+42} Q{bx+10} {by+28} {bx+2} {by+8}Z', c2, sw=SW)]
    if kind == 'long':
        d = f'M{bx} {by} Q{bx+30} {by-2} {bx+26} {by-36}'
        return [line(d, 7 + 2 * SW, O), line(d, 7, c), line(f'M{bx+26} {by-36} L{bx+26} {by-29}', 7, c2)]
    if kind == 'upcurl':
        d = f'M{bx} {by} Q{bx+22} {by-4} {bx+18} {by-28}'
        return [line(d, 7 + 2 * SW, O), line(d, 7, c)]
    if kind == 'pom':
        return [ci(bx + 6, by + 6, 8, c, sw=SW)]
    if kind == 'curl':
        d = f'M{bx} {by} Q{bx+14} {by-4} {bx+10} {by-14} Q{bx+6} {by-20} {bx+1} {by-14}'
        return [line(d, 4 + 2 * SW, O), line(d, 4, c)]
    if kind == 'short':
        return [el(bx + 4, by + 3, 6, 9, c, rot=-40, sw=SW)]
    if kind == 'monkey':
        d = f'M{bx} {by} Q{bx+30} {by+4} {bx+34} {by-24} Q{bx+36} {by-44} {bx+20} {by-42}'
        return [line(d, 6 + 2 * SW, O), line(d, 6, c)]
    return []


def front_deco(kind, cx, cy, rx, ry, col):
    out = []
    if kind == 'cow':
        out += [el(cx - 12, cy - 8, 11, 9, K, st=False), el(cx + 14, cy + 10, 9, 7, K, st=False)]
    elif kind == 'stripes':
        for k, dy in enumerate(range(-24, 26, 9)):
            w = rx * math.sqrt(max(0.05, 1 - (dy / ry) ** 2)) * .92
            out.append(line(f'M{cx-w:.0f} {cy+dy} Q{cx} {cy+dy+7} {cx+w:.0f} {cy+dy}', 4.5, K))
    elif kind == 'spots':
        for dx, dy in [(-14, -14), (10, -18), (-6, -2), (16, 0), (-18, 12), (6, 16), (22, -10)]:
            out.append(ci(cx + dx, cy + dy, 3.8, col, False))
    elif kind == 'patches':
        for dx, dy, r in [(-12, -10, 7), (12, -4, 7), (-8, 14, 6), (14, 16, 5)]:
            out.append(el(cx + dx, cy + dy, r, r * .85, col, rot=20, st=False))
    elif kind == 'tabby':
        for dy in (-14, -4, 6):
            out.append(line(f'M{cx-rx} {cy+dy} L{cx-rx+9} {cy+dy+1} M{cx+rx} {cy+dy} L{cx+rx-9} {cy+dy+1}', 3.6, col))
    return out


def head_parts(id_, a):
    fn = getattr(G, HNAME.get(id_, id_))
    parts, eyes, er = fn()
    drop = set(DROP.get(id_, []))
    ears = EARS.get(id_)
    eL, eR = ([], [])
    if ears:
        eL = [parts[i] for i in ears[0]]
        eR = [parts[i] for i in ears[1]]
        drop |= set(ears[0]) | set(ears[1])
    keep = [p for i, p in enumerate(parts) if i not in drop]
    # brilho suave na testa (deixa a cabeça mais bonita)
    keep.append(el(82, 60, 22, 9, '#FFFFFF', rot=-22, st=False, op=.16))
    return keep, eL, eR, eyes, er


def build_mammal(id_):
    a = M[id_]
    col, rx, ry, cy = a['color'], a['rx'], a['ry'], a['cy']
    lw, lk, fc = a['leg']
    layers = [('shadow', [el(100, 177, 54, 7, '#000000', st=False, op=.14)], (100, 177))]
    # rabo
    t, tc, tc2 = a['tail']
    tbx, tby = 100 + rx + 8, cy - 2
    layers.append(('tail', tail_parts(t, tc, tc2, tbx, tby), (tbx, tby)))
    # ancas e patinhas de trás
    hind_c = shade(col, .9) if col != '#FFFFFF' else '#F0F0F0'
    fl = a.get('leg_c', col)
    for role, s in (('hindL', -1), ('hindR', 1)):
        hx = 100 + s * (rx + 9)
        parts = [el(hx, cy + 10, 16, 23, hind_c, sw=SW)]
        if a.get('bigfeet'):
            parts.append(el(hx + s * 4, 175, 16, 7, fc if fc != col else hind_c, sw=SW))
        else:
            parts.append(foot(lk, hx + s * 3, 175, lw - 3, fc if lk != 'paw' else hind_c))
        layers.append((role, parts, (hx, cy)))
    # corpo (peito)
    if a.get('wool'):
        pts = [(100, cy - 12, 25), (76, cy - 2, 20), (124, cy - 2, 20), (82, cy + 18, 20), (118, cy + 18, 20), (100, cy + 20, 22), (92, cy - 24, 14), (110, cy - 22, 15)]
        body = [ci(x, y, r, '#FFFFFF', sw=SW) for x, y, r in pts] + [ci(x, y, r - 2, '#FFFFFF', False) for x, y, r in pts]
    else:
        body = [el(100, cy, rx, ry, col, sw=SW)]
        if a.get('belly'):
            body.append(el(100, cy + ry * .28, rx * .6, ry * .6, a['belly'], st=False))
        body += front_deco(a.get('deco'), 100, cy, rx, ry, a.get('deco_c', K))
        body.append(el(100 - rx * .35, cy - ry * .45, rx * .32, ry * .16, '#FFFFFF', rot=-25, st=False, op=.25))
    layers.append(('body', body, (100, cy + ry)))
    # patas da frente (retas, como as do bicho)
    for role, s in (('legL', -1), ('legR', 1)):
        x = 100 + s * rx * .46
        top = cy + 4
        parts = [limb(x, top, x, 172, lw, fl), foot(lk, x, 175, lw, fc if lk != 'paw' else fl if fl != col else col)]
        parts.append(el(x - lw * .18, 150, lw * .16, 10, '#FFFFFF', st=False, op=.2))
        layers.append((role, parts, (x, top)))
    # cabeça (+pescoço da girafa)
    hs, hy = a['hs'], a['hy']
    hcy = a.get('hcy', 100)
    tx, ty = 100 - 100 * hs, hy - hcy * hs
    keep, eL, eR, eyes, er = head_parts(id_, a)
    parts = []
    if a.get('neck'):
        w, top, bot = a['neck']
        parts.append(pa(f'M{100-w/2} {top} L{100+w/2} {top} L{100+w/2+10} {bot} L{100-w/2-10} {bot}Z', col, sw=SW))
        for dy, dx in ((82, -3), (98, 4), (112, -2)):
            parts.append(el(100 + dx, dy, 5, 4, a['deco_c'], st=False))
    parts.append(grp(keep, tx, ty, 0, hs))
    pivot = (100, round(hy + 46 * hs, 1)) if not a.get('neck') else (100, a['neck'][2] - 4)
    if EARS.get(id_):
        ears = EARS[id_]
        for role, ep, ed in (('earL', ears[2], eL), ('earR', ears[3], eR)):
            layers.append((role, [grp(ed, tx, ty, 0, hs)], (round(tx + hs * ep[0], 1), round(ty + hs * ep[1], 1))))
    layers.append(('head', parts, pivot))
    eyes2 = [(round(tx + hs * x, 1), round(ty + hs * y, 1)) for x, y in eyes]
    mouth = None
    if id_ in MOUTH:
        mx, my, mw = MOUTH[id_]
        mouth = {'x': round(tx + hs * mx, 1), 'y': round(ty + hs * my, 1), 'w': round(mw * hs, 1)}
    return layers, eyes2, round(er * hs, 2), mouth


def build(id_):
    if id_ in M:
        return build_mammal(id_)
    layers, eyes, er = F.build(id_)
    layers = [('shadow', [el(100, 177, 54, 7, '#000000', st=False, op=.14)], (100, 177))] + layers
    return layers, eyes, er, None


def main():
    out_dir = 'assets/images/rig'
    os.makedirs(out_dir, exist_ok=True)
    for f in glob.glob(out_dir + '/*.svg'):
        os.remove(f)
    n = 0
    for cat in ('farm', 'safari'):
        path = f'assets/data/{cat}.json'
        data = json.load(open(path, encoding='utf-8'))
        for it in data['items']:
            layers, eyes, er, mouth = build(it['id'])
            spec = []
            for role, parts, pivot in layers:
                asset = f'{out_dir}/{it["id"]}_{role}.svg'
                open(asset, 'w', encoding='utf-8').write(G.svg(parts))
                spec.append({'role': role, 'asset': asset, 'pivot': [round(pivot[0], 1), round(pivot[1], 1)]})
            rig = {'layers': spec, 'eyes': [[round(x, 1), round(y, 1)] for x, y in eyes], 'eyeRadius': er, 'facing': 'front',
                   'armMode': 'flap' if (it['id'] in F.CFG and F.CFG[it['id']].flap) else 'swing'}
            if mouth:
                rig['mouth'] = mouth
            it['rig'] = rig
            n += 1
        json.dump(data, open(path, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    print('rigs ok:', n)


if __name__ == '__main__':
    main()
