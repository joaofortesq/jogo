#!/usr/bin/env python3
"""Gera a pronúncia (português e inglês) de cada palavra em arquivos mp3.

Lê assets/data/*.json e cria:
  assets/audio/pt_br/<id>.mp3
  assets/audio/en_us/<id>.mp3
Os nomes são exatamente os que o app procura; se o arquivo existir, ele
toca no lugar da voz do sistema.

Motores (tenta nesta ordem, por arquivo):
  1. edge-tts  (vozes neurais; pip install edge-tts)
  2. gTTS      (voz do Google Tradutor; pip install gTTS)

Uso (na raiz do projeto):
  python3 tools/generate_voices.py            # só cria o que falta
  python3 tools/generate_voices.py --force    # refaz tudo
Se tiver ffmpeg, corta o silêncio das pontas e nivela o volume.
"""
import asyncio
import json
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
DATA = ROOT / 'assets' / 'data'
FORCE = '--force' in sys.argv

LANGS = {
    # pasta: (vozes edge-tts em ordem de preferência, gTTS lang, gTTS tld, campo do JSON)
    'pt_br': (['pt-BR-FranciscaNeural', 'pt-BR-ThalitaNeural'], 'pt', 'com.br', 'pt'),
    'en_us': (['en-US-AnaNeural', 'en-US-JennyNeural'], 'en', 'com', 'en'),
}
RATE = '-12%'  # um pouco mais devagar, bom para criança


def load_words():
    words = {}
    for f in sorted(DATA.glob('*.json')):
        for it in json.load(open(f, encoding='utf-8'))['items']:
            words[it['id']] = it
    return words


async def edge_save(text, voices, path):
    import edge_tts
    last = None
    for voice in voices:
        for _ in range(3):
            try:
                await edge_tts.Communicate(text, voice, rate=RATE).save(str(path))
                if path.exists() and path.stat().st_size > 500:
                    return True
            except Exception as e:  # rede, 403, voz inexistente...
                last = e
                await asyncio.sleep(1.5)
    print('   edge-tts falhou:', last)
    return False


def gtts_save(text, lang, tld, path):
    try:
        from gtts import gTTS
        gTTS(text=text, lang=lang, tld=tld).save(str(path))
        return path.exists() and path.stat().st_size > 500
    except Exception as e:
        print('   gTTS falhou:', e)
        return False


def polish(path):
    """Corta silêncio inicial e nivela o volume (opcional)."""
    if not shutil.which('ffmpeg'):
        return
    tmp = path.with_suffix('.tmp.mp3')
    r = subprocess.run(
        ['ffmpeg', '-y', '-v', 'error', '-i', str(path), '-af',
         'silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.05,'
         'loudnorm=I=-16:TP=-1.5:LRA=11', '-ac', '1', '-ar', '44100', '-b:a', '96k', str(tmp)])
    if r.returncode == 0 and tmp.exists() and tmp.stat().st_size > 500:
        tmp.replace(path)
    elif tmp.exists():
        tmp.unlink()


async def main():
    words = load_words()
    made = skipped = failed = 0
    for folder, (voices, g_lang, g_tld, field) in LANGS.items():
        out_dir = ROOT / 'assets' / 'audio' / folder
        out_dir.mkdir(parents=True, exist_ok=True)
        for wid, it in words.items():
            dest = out_dir / f'{wid}.mp3'
            if dest.exists() and not FORCE:
                skipped += 1
                continue
            text = it[field]
            tmp = out_dir / f'{wid}.raw.mp3'
            ok = False
            try:
                ok = await edge_save(text, voices, tmp)
            except ImportError:
                print('edge-tts não instalado (pip install edge-tts)')
            if not ok:
                ok = gtts_save(text, g_lang, g_tld, tmp)
            if ok:
                polish(tmp)
                tmp.replace(dest)
                made += 1
                print(f'ok   {folder}/{wid}.mp3  ({text})')
            else:
                if tmp.exists():
                    tmp.unlink()
                failed += 1
                print(f'FALHOU {folder}/{wid}.mp3  ({text})')
    print(f'\nCriados: {made} | já existiam: {skipped} | falharam: {failed}')
    if failed:
        print('O que falhou continua usando a voz do sistema no app.')


if __name__ == '__main__':
    asyncio.run(main())
