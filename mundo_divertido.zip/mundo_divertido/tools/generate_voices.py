#!/usr/bin/env python3
"""Gera a pronúncia (português e inglês) de cada palavra em arquivos mp3.

Lê assets/data/*.json e cria, para animais, frutas, cores, letras, números e os
objetos de exemplo (cores e letras, prefixo obj_):
  assets/audio/pt_br/<id>.mp3     assets/audio/en_us/<id>.mp3
Os nomes são os que o app procura; se o arquivo existe, ele toca no lugar da
voz do sistema. Se faltar, o app fala com a voz do aparelho (nada quebra).

Motores (tenta nesta ordem, palavra por palavra):
  1. Google Cloud Text-to-Speech (Neural2) — só se GOOGLE_TTS_KEY existir.
     Sem a chave isso é NORMAL: o motor é simplesmente pulado, sem alarde.
  2. edge-tts (vozes neurais da Microsoft)        pip install edge-tts
  3. gTTS (voz do Google Tradutor)                pip install gTTS

Letras: o texto enviado à voz vem de "speakPt"/"speakEn" em letters.json (o que
aparece na tela é "namePt"/"nameEn"). Outras palavras: ajuste o som em
tools/pronuncia.json ({"hippopotamus": "ipopótamo"}, inglês: "hippopotamus:en").

Sem áudio duplicado: o mesmo texto no mesmo idioma é sintetizado uma única vez
(os demais ids recebem uma cópia do arquivo). Arquivos que já existem são
mantidos (use --force para refazer tudo).

Saída: um resumo no console e, com --report CAMINHO, um JSON com contagens,
motores usados, vozes e falhas. Dentro do GitHub Actions também escreve
anotações ::warning:: para o que falhar.

Códigos de saída: 0 = terminou (mesmo com falhas parciais, pois o app tem
fallback); 1 = erro do script, ou falhas quando --require é usado.

Variáveis opcionais: PT_VOICE, EN_VOICE (edge-tts), GOOGLE_PT_VOICE,
GOOGLE_EN_VOICE.

Uso (na raiz do projeto):
  python3 tools/generate_voices.py                  # só cria o que falta
  python3 tools/generate_voices.py --force          # refaz tudo
  python3 tools/generate_voices.py --require        # falha se algo não for gerado
  python3 tools/generate_voices.py --report voices_report.json
Se tiver ffmpeg, corta o silêncio do começo e nivela o volume.
"""
import asyncio
import base64
import json
import os
import pathlib
import shutil
import subprocess
import sys
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parent.parent
DATA = ROOT / 'assets' / 'data'
FORCE = '--force' in sys.argv
REQUIRE = '--require' in sys.argv
IN_ACTIONS = os.environ.get('GITHUB_ACTIONS') == 'true'
GKEY = os.environ.get('GOOGLE_TTS_KEY', '').strip()  # nunca é impressa


def _arg(name):
    if name in sys.argv:
        i = sys.argv.index(name)
        if i + 1 < len(sys.argv):
            return sys.argv[i + 1]
    return None


REPORT = _arg('--report')

LANGS = {
    # pasta: dict(lang, edge=[vozes], google=(voz, código), gtts=(lang, tld), rate, campo)
    'pt_br': dict(
        lang='pt-BR', field='pt',
        edge=[os.environ.get('PT_VOICE', 'pt-BR-FranciscaNeural'), 'pt-BR-ThalitaNeural'],
        google=(os.environ.get('GOOGLE_PT_VOICE', 'pt-BR-Neural2-A'), 'pt-BR'),
        gtts=('pt', 'com.br'), rate='-18%'),
    'en_us': dict(
        lang='en-US', field='en',
        edge=[os.environ.get('EN_VOICE', 'en-US-AnaNeural'), 'en-US-JennyNeural'],
        google=(os.environ.get('GOOGLE_EN_VOICE', 'en-US-Neural2-H'), 'en-US'),
        gtts=('en', 'com'), rate='-12%'),
}


def warn(msg):
    print(('::warning::' if IN_ACTIONS else 'AVISO: ') + msg)


def check_voices():
    """Garante que cada voz pertence ao idioma da sua pasta (pt-BR / en-US)."""
    for folder, cfg in LANGS.items():
        prefix = cfg['lang']
        names = list(cfg['edge']) + [cfg['google'][0]]
        for n in names:
            if not n.startswith(prefix):
                raise SystemExit(f'voz "{n}" não é {prefix} (pasta {folder}). Corrija PT_VOICE/EN_VOICE.')


def load_words():
    """id -> {'pt': texto falado, 'en': texto falado}"""
    words = {}
    for f in sorted(DATA.glob('*.json')):
        for it in json.load(open(f, encoding='utf-8'))['items']:
            # Letras: speakPt/speakEn é como a voz fala (B -> "Bê" / "Bee").
            words[it['id']] = {'pt': it.get('speakPt', it['pt']),
                               'en': it.get('speakEn', it['en'])}
            for ex in it.get('examples', []):
                words['obj_' + ex['id']] = {'pt': ex['pt'], 'en': ex['en']}
    # frases do app (hora de dormir)
    words['msg_boanoite'] = {'pt': 'Boa noite! Está na hora de dormir. Até amanhã!',
                             'en': "Good night! It's time to sleep. See you tomorrow!"}
    return words


def load_overrides():
    p = ROOT / 'tools' / 'pronuncia.json'
    if not p.exists():
        return {}
    try:
        return {k: v for k, v in json.load(open(p, encoding='utf-8')).items() if not k.startswith('_')}
    except Exception as e:
        warn(f'pronuncia.json inválido, ignorado: {e}')
        return {}


def speakable(text):
    # O ponto final faz a voz fechar a palavra com entonação natural.
    t = text.strip()
    return t if t.endswith(('.', '!', '?')) else t + '.'


def google_save(text, voice, code, path):
    if not GKEY:
        return False  # sem chave: situação normal, motor pulado em silêncio
    body = json.dumps({
        'input': {'text': text},
        'voice': {'languageCode': code, 'name': voice},
        'audioConfig': {'audioEncoding': 'MP3', 'speakingRate': 0.82, 'pitch': 1.0},
    }).encode()
    req = urllib.request.Request(
        f'https://texttospeech.googleapis.com/v1/text:synthesize?key={GKEY}',
        data=body, headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            audio = base64.b64decode(json.load(r)['audioContent'])
        path.write_bytes(audio)
        return path.stat().st_size > 500
    except Exception as e:
        # Não imprime a URL (ela contém a chave).
        print('   Google TTS falhou:', type(e).__name__, getattr(e, 'code', ''))
        return False


async def edge_save(text, voices, rate, path):
    try:
        import edge_tts
    except ImportError:
        print('   edge-tts não instalado (pip install edge-tts)')
        return False
    last = None
    for voice in voices:
        for _ in range(3):
            try:
                await edge_tts.Communicate(text, voice, rate=rate).save(str(path))
                if path.exists() and path.stat().st_size > 500:
                    return True
            except Exception as e:  # rede, 403, voz inexistente...
                last = e
                await asyncio.sleep(1.5)
    print('   edge-tts falhou:', last)
    return False


def gtts_save(text, lang, tld, path):
    try:
        from gtts import gTTS
        gTTS(text=text, lang=lang, tld=tld).save(str(path))
        return path.exists() and path.stat().st_size > 500
    except Exception as e:
        print('   gTTS falhou:', type(e).__name__)
        return False


def polish(path):
    """Corta silêncio inicial e nivela o volume (opcional)."""
    if not shutil.which('ffmpeg'):
        return
    tmp = path.with_suffix('.tmp.mp3')
    r = subprocess.run(
        ['ffmpeg', '-y', '-v', 'error', '-i', str(path), '-af',
         'silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.05,'
         'loudnorm=I=-16:TP=-1.5:LRA=11', '-ac', '1', '-ar', '44100', '-b:a', '96k', str(tmp)])
    if r.returncode == 0 and tmp.exists() and tmp.stat().st_size > 500:
        tmp.replace(path)
    elif tmp.exists():
        tmp.unlink()


async def synth(text, cfg, tmp):
    """Tenta os motores em ordem; devolve o nome do que funcionou (ou None)."""
    g_voice, g_code = cfg['google']
    if google_save(text, g_voice, g_code, tmp):
        return 'google'
    if await edge_save(text, cfg['edge'], cfg['rate'], tmp):
        return 'edge'
    if gtts_save(text, cfg['gtts'][0], cfg['gtts'][1], tmp):
        return 'gtts'
    return None


async def main():
    check_voices()
    words = load_words()
    over = load_overrides()
    if not GKEY:
        print('GOOGLE_TTS_KEY ausente: normal, usando edge-tts/gTTS.')
    report = {'google_key': bool(GKEY), 'folders': {}, 'failed': [], 'orphans': []}
    total_failed = 0
    for folder, cfg in LANGS.items():
        out_dir = ROOT / 'assets' / 'audio' / folder
        out_dir.mkdir(parents=True, exist_ok=True)
        stats = {'wanted': len(words), 'existing': 0, 'made': 0, 'copied': 0, 'failed': 0,
                 'engines': {'google': 0, 'edge': 0, 'gtts': 0}, 'voice_edge': cfg['edge'][0],
                 'voice_google': cfg['google'][0] if GKEY else None}
        done_text = {}  # texto final -> arquivo já gerado nesta execução
        for key, w in words.items():
            dest = out_dir / f'{key}.mp3'
            if dest.exists() and dest.stat().st_size > 500 and not FORCE:
                stats['existing'] += 1
                continue
            raw = over.get(key if folder == 'pt_br' else f'{key}:en', w[cfg['field']])
            text = speakable(raw)
            if text in done_text and done_text[text].exists():
                shutil.copyfile(done_text[text], dest)  # mesmo texto: não sintetiza de novo
                stats['copied'] += 1
                print(f'copia {folder}/{key}.mp3  ({raw})')
                continue
            tmp = out_dir / f'{key}.raw.mp3'
            used = await synth(text, cfg, tmp)
            if used:
                polish(tmp)
                tmp.replace(dest)
                done_text[text] = dest
                stats['made'] += 1
                stats['engines'][used] += 1
                print(f'ok   {folder}/{key}.mp3  ({raw}) [{used}]')
            else:
                if tmp.exists():
                    tmp.unlink()
                stats['failed'] += 1
                report['failed'].append(f'{folder}/{key}')
                print(f'FALHOU {folder}/{key}.mp3  ({raw})')
        # arquivos que nenhum item usa mais (só informa; não apaga)
        for f in sorted(out_dir.glob('*.mp3')):
            if f.stem not in words and not f.stem.endswith('.raw'):
                report['orphans'].append(f'{folder}/{f.name}')
        total_failed += stats['failed']
        report['folders'][folder] = stats
    for folder, st in report['folders'].items():
        print(f"\n{folder}: {st['made']} novos, {st['copied']} cópias, {st['existing']} já existiam, "
              f"{st['failed']} falharam | motores: {st['engines']}")
    if report['orphans']:
        print('Sem uso (não apagados):', ', '.join(report['orphans']))
    if total_failed:
        warn(f'{total_failed} áudio(s) não foram gerados; o app usa a voz do aparelho neles: '
             + ', '.join(report['failed'][:12]) + (' ...' if len(report['failed']) > 12 else ''))
    if REPORT:
        pathlib.Path(REPORT).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    if total_failed and REQUIRE:
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(asyncio.run(main()))
