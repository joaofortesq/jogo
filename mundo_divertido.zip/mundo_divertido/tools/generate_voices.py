#!/usr/bin/env python3
"""Gera a pronúncia (português e inglês) de cada palavra em arquivos mp3.

Lê assets/data/*.json e cria, para animais, frutas, cores e os objetos de
exemplo das cores (prefixo obj_):
  assets/audio/pt_br/<id>.mp3     assets/audio/en_us/<id>.mp3
Os nomes são os que o app procura; se o arquivo existe, ele toca no lugar da
voz do sistema.

Motores (tenta nesta ordem, palavra por palavra):
  1. Google Cloud Text-to-Speech, vozes Neural2 (a melhor pronúncia) —
     só se a variável de ambiente GOOGLE_TTS_KEY existir.
  2. edge-tts (vozes neurais da Microsoft)        pip install edge-tts
  3. gTTS (voz do Google Tradutor)                pip install gTTS

Palavra pronunciada errada? Escreva como ela deve SOAR em tools/pronuncia.json
(ex.: {"hippopotamus": "ipopótamo"}) e gere de novo (use --force).

Variáveis opcionais: PT_VOICE, EN_VOICE (nome da voz edge-tts), GOOGLE_PT_VOICE,
GOOGLE_EN_VOICE.

Uso (na raiz do projeto):
  python3 tools/generate_voices.py            # só cria o que falta
  python3 tools/generate_voices.py --force    # refaz tudo
Se tiver ffmpeg, corta o silêncio do começo e nivela o volume.
"""
import asyncio
import base64
import json
import os
import pathlib
import shutil
import subprocess
import sys
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parent.parent
DATA = ROOT / 'assets' / 'data'
FORCE = '--force' in sys.argv
GKEY = os.environ.get('GOOGLE_TTS_KEY', '').strip()

LANGS = {
    # pasta: (vozes edge-tts, voz Google, código Google, gTTS lang, gTTS tld, velocidade edge)
    'pt_br': ([os.environ.get('PT_VOICE', 'pt-BR-FranciscaNeural'), 'pt-BR-ThalitaNeural'],
              os.environ.get('GOOGLE_PT_VOICE', 'pt-BR-Neural2-A'), 'pt-BR', 'pt', 'com.br', '-18%'),
    'en_us': ([os.environ.get('EN_VOICE', 'en-US-AnaNeural'), 'en-US-JennyNeural'],
              os.environ.get('GOOGLE_EN_VOICE', 'en-US-Neural2-H'), 'en-US', 'en', 'com', '-12%'),
}


def load_words():
    """id -> {'pt': ..., 'en': ...}"""
    words = {}
    for f in sorted(DATA.glob('*.json')):
        for it in json.load(open(f, encoding='utf-8'))['items']:
            words[it['id']] = {'pt': it['pt'], 'en': it['en']}
            for ex in it.get('examples', []):
                words['obj_' + ex['id']] = {'pt': ex['pt'], 'en': ex['en']}
    # frases do app (hora de dormir)
    words['msg_boanoite'] = {'pt': 'Boa noite! Está na hora de dormir. Até amanhã!',
                             'en': "Good night! It's time to sleep. See you tomorrow!"}
    return words


def load_overrides():
    p = ROOT / 'tools' / 'pronuncia.json'
    if not p.exists():
        return {}
    try:
        return {k: v for k, v in json.load(open(p, encoding='utf-8')).items() if not k.startswith('_')}
    except Exception as e:
        print('pronuncia.json inválido:', e)
        return {}


def speakable(text):
    # O ponto final faz a voz fechar a palavra com entonação natural.
    t = text.strip()
    return t if t.endswith(('.', '!', '?')) else t + '.'


def google_save(text, voice, code, path):
    if not GKEY:
        return False
    body = json.dumps({
        'input': {'text': text},
        'voice': {'languageCode': code, 'name': voice},
        'audioConfig': {'audioEncoding': 'MP3', 'speakingRate': 0.82, 'pitch': 1.0},
    }).encode()
    req = urllib.request.Request(
        f'https://texttospeech.googleapis.com/v1/text:synthesize?key={GKEY}',
        data=body, headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            audio = base64.b64decode(json.load(r)['audioContent'])
        path.write_bytes(audio)
        return path.stat().st_size > 500
    except Exception as e:
        print('   Google TTS falhou:', e)
        return False


async def edge_save(text, voices, rate, path):
    try:
        import edge_tts
    except ImportError:
        print('edge-tts não instalado (pip install edge-tts)')
        return False
    last = None
    for voice in voices:
        for _ in range(3):
            try:
                await edge_tts.Communicate(text, voice, rate=rate).save(str(path))
                if path.exists() and path.stat().st_size > 500:
                    return True
            except Exception as e:  # rede, 403, voz inexistente...
                last = e
                await asyncio.sleep(1.5)
    print('   edge-tts falhou:', last)
    return False


def gtts_save(text, lang, tld, path):
    try:
        from gtts import gTTS
        gTTS(text=text, lang=lang, tld=tld).save(str(path))
        return path.exists() and path.stat().st_size > 500
    except Exception as e:
        print('   gTTS falhou:', e)
        return False


def polish(path):
    """Corta silêncio inicial e nivela o volume (opcional)."""
    if not shutil.which('ffmpeg'):
        return
    tmp = path.with_suffix('.tmp.mp3')
    r = subprocess.run(
        ['ffmpeg', '-y', '-v', 'error', '-i', str(path), '-af',
         'silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.05,'
         'loudnorm=I=-16:TP=-1.5:LRA=11', '-ac', '1', '-ar', '44100', '-b:a', '96k', str(tmp)])
    if r.returncode == 0 and tmp.exists() and tmp.stat().st_size > 500:
        tmp.replace(path)
    elif tmp.exists():
        tmp.unlink()


async def main():
    words = load_words()
    over = load_overrides()
    made = skipped = failed = 0
    engines = {'google': 0, 'edge': 0, 'gtts': 0}
    for folder, (voices, g_voice, g_code, g_lang, g_tld, rate) in LANGS.items():
        out_dir = ROOT / 'assets' / 'audio' / folder
        out_dir.mkdir(parents=True, exist_ok=True)
        for key, w in words.items():
            dest = out_dir / f'{key}.mp3'
            if dest.exists() and not FORCE:
                skipped += 1
                continue
            lang_field = 'pt' if folder == 'pt_br' else 'en'
            raw = over.get(key if folder == 'pt_br' else f'{key}:en', w[lang_field])
            text = speakable(raw)
            tmp = out_dir / f'{key}.raw.mp3'
            used = None
            if google_save(text, g_voice, g_code, tmp):
                used = 'google'
            elif await edge_save(text, voices, rate, tmp):
                used = 'edge'
            elif gtts_save(text, g_lang, g_tld, tmp):
                used = 'gtts'
            if used:
                polish(tmp)
                tmp.replace(dest)
                made += 1
                engines[used] += 1
                print(f'ok   {folder}/{key}.mp3  ({raw}) [{used}]')
            else:
                if tmp.exists():
                    tmp.unlink()
                failed += 1
                print(f'FALHOU {folder}/{key}.mp3  ({raw})')
    print(f'\nCriados: {made} | já existiam: {skipped} | falharam: {failed}')
    print('Motores usados:', engines)
    if failed:
        print('O que falhou continua usando a voz do sistema no app.')


if __name__ == '__main__':
    asyncio.run(main())
