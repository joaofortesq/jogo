#!/usr/bin/env python3
"""Depois de `flutter create`, troca o ícone do app pelo panda.

Copia tools/icon/mipmap-*/ic_launcher.png para android/app/src/main/res/.
Para trocar o ícone: substitua os PNGs em tools/icon/ (48, 72, 96, 144 e
192 px) e rode: python3 tools/apply_icon.py (na raiz do projeto).
"""
import pathlib, shutil, sys

res = pathlib.Path('android/app/src/main/res')
if not res.exists():
    sys.exit('android/ não existe. Rode antes: flutter create --platforms=android .')
n = 0
for d in sorted(pathlib.Path('tools/icon').glob('mipmap-*')):
    dest = res / d.name
    dest.mkdir(parents=True, exist_ok=True)
    shutil.copy(d / 'ic_launcher.png', dest / 'ic_launcher.png')
    n += 1
print(f'ícone aplicado em {n} pastas')
