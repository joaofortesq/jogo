#!/usr/bin/env python3
"""Gera os bichos de corpo inteiro em camadas (para animar no Flutter).

Cada animal vira várias camadas SVG 200x200 em assets/images/rig/:
  <id>_tail, <id>_legL, <id>_legR, <id>_body, <id>_armL, <id>_armR, <id>_head
e o JSON da categoria ganha a chave "rig" (camadas, pontos de giro, olhos).
A cabeça reaproveita a ilustração de generate_art.py; o corpo é desenhado aqui.

Uso (raiz do projeto):  python3 tools/generate_rigs.py
Pré-visualização (opcional, precisa de matplotlib): python3 tools/generate_rigs.py --preview
"""
import json, math, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import generate_art as G
from generate_art import O, K, el, ci, pa, line

SW = 3  # contorno do corpo

# elementos da cabeça (índices de generate_art.py) que NÃO entram na cabeça do rig
HEAD_DROP = {
    'cow': [0, 1, 2], 'horse': [0, 1], 'pig': [0, 1], 'hen': [0, 1, 2, 3], 'rooster': [0, 1, 2, 3],
    'duck': [0, 1, 2, 3], 'sheep': [0, 1], 'goat': [0, 1], 'donkey': [0, 1], 'rabbit': [0, 1],
    'cat': [0, 1], 'dog': [0, 1], 'lion': [0], 'elephant': [0], 'giraffe': [4, 5, 6, 7, 8],
    'zebra': [0, 1], 'monkey': [0, 1], 'hippopotamus': [0, 1], 'rhinoceros': [0, 1],
    'crocodile': [0], 'cheetah': [0, 1], 'ostrich': [0, 1, 2, 3, 4, 5, 6, 7, 8],
    'frog': [0], 'parrot': [0, 1], 'owl': [0, 1],
}


class A:
    def __init__(self, **kw):
        self.color = '#CCCCCC'; self.belly = None; self.rx = 36; self.ry = 33; self.cy = 130
        self.arm = 'paw'; self.arm_c = None; self.hand_c = None; self.arm_len = 26; self.arm_w = 11
        self.leg = 'paw'; self.leg_c = None; self.foot_c = None; self.leg_w = 14; self.leg_x = 17; self.foot_rx = 12
        self.tail = None; self.tail_c = None; self.tail_c2 = None
        self.deco = None; self.deco_c = K
        self.hs = .62; self.hy = 70; self.hcy = 100
        self.neck = None  # (cor, largura, y_topo, cor_manchas)
        self.flap = False
        self.__dict__.update(kw)


CFG = {
    'cow': A(color='#FFFFFF', belly='#FFF4F4', arm_c='#FFFFFF', hand_c='#4B4B5A', leg_c='#FFFFFF', foot_c='#4B4B5A', leg='hoof',
             tail='tuft', tail_c='#FFFFFF', tail_c2=K, deco='cow', arm='paw'),
    'horse': A(color='#B97A4B', belly='#D7A27A', hand_c='#3A2A1F', foot_c='#3A2A1F', leg='hoof', tail='tuft', tail_c='#6B3F25', tail_c2='#6B3F25'),
    'pig': A(color='#F9A8BD', belly='#FBC7D4', hand_c='#F27A9B', foot_c='#F27A9B', leg='hoof', leg_w=16, tail='curl', tail_c='#F27A9B', rx=38),
    'hen': A(color='#FFF3D6', belly='#FFFFFF', arm='wing', arm_c='#EACB93', leg='claw', leg_c='#FFA928', foot_c='#FFA928', leg_w=6,
             tail='fan', tail_c=['#EACB93', '#F7E2B8', '#EACB93'], deco='feathers', deco_c='#EACB93', flap=True),
    'rooster': A(color='#E9573F', belly='#F58A5E', arm='wing', arm_c='#E8913D', leg='claw', leg_c='#FFC93C', foot_c='#FFC93C', leg_w=6,
                 tail='fan', tail_c=['#2E9E8F', '#E8913D', '#E9573F', '#E8913D', '#2E9E8F'], deco='feathers', deco_c='#C73E2B', flap=True),
    'duck': A(color='#FFD84A', belly='#FFE98A', arm='wing', arm_c='#F5C21B', leg='webbed', leg_c='#FF9F1C', foot_c='#FF9F1C', leg_w=6,
              tail='short', tail_c='#F5C21B', flap=True),
    'sheep': A(color='#FFFFFF', arm_c='#3C3550', hand_c='#3C3550', arm_w=9, leg='hoof', leg_c='#3C3550', foot_c='#3C3550', leg_w=9, tail='pom', tail_c='#FFFFFF',
               deco='wool', hs=.58, hy=66, arm_len=18),
    'goat': A(color='#D8C4A5', belly='#F0E2CC', hand_c='#5A4632', foot_c='#5A4632', leg='hoof', tail='short', tail_c='#D8C4A5'),
    'donkey': A(color='#9BA2AC', belly='#ECE8E2', hand_c='#4A4F5A', foot_c='#4A4F5A', leg='hoof', tail='tuft', tail_c='#9BA2AC', tail_c2='#5E636E'),
    'rabbit': A(color='#F6D5E6', belly='#FFFFFF', foot_c='#F6D5E6', foot_rx=15, tail='pom', tail_c='#FFFFFF', rx=33, ry=31),
    'cat': A(color='#F2A65A', belly='#FBE3C6', tail='long', tail_c='#F2A65A', tail_c2='#C97B2E', deco='tabby', deco_c='#C97B2E'),
    'dog': A(color='#D0A57A', belly='#F6E4CE', tail='long', tail_c='#D0A57A', tail_c2='#8A5A3A', arm_c='#D0A57A'),
    'lion': A(color='#F7B648', belly='#FCE2A8', foot_c='#F7B648', tail='tuft', tail_c='#F7B648', tail_c2='#E8872E', hs=.56, hy=68),
    'elephant': A(color='#A993CB', belly='#C9B8E2', rx=40, ry=36, cy=129, arm_w=15, leg='stub', leg_w=19, leg_x=19, foot_c='#A993CB',
                  tail='tuft', tail_c='#A993CB', tail_c2='#8A74B0', hs=.58, hy=66),
    'giraffe': A(color='#F8D448', belly='#FBE9A8', rx=33, ry=25, cy=148, arm_w=9, arm_len=24, leg_w=9, leg_x=16, leg='hoof', foot_c='#8B5A2B',
                 hand_c='#8B5A2B', tail='tuft', tail_c='#F8D448', tail_c2='#8B5A2B', deco='spots', deco_c='#C77A2B',
                 neck=('#F8D448', 24, 40, '#C77A2B'), hs=.56, hy=36, hcy=64),
    'zebra': A(color='#F4F4F4', belly='#FFFFFF', hand_c=K, foot_c=K, leg='hoof', tail='tuft', tail_c='#F4F4F4', tail_c2=K, deco='stripes', deco_c=K),
    'monkey': A(color='#B76A49', belly='#F2C9A0', arm='hand', hand_c='#F2C9A0', foot_c='#F2C9A0', tail='long', tail_c='#B76A49', tail_c2='#B76A49'),
    'hippopotamus': A(color='#8EA6D8', belly='#A9BDE6', rx=42, ry=34, leg='stub', leg_w=19, leg_x=20, arm_w=15, foot_c='#8EA6D8', tail='short', tail_c='#8EA6D8'),
    'rhinoceros': A(color='#9CA4AF', belly='#B7BFC9', rx=39, ry=34, leg='stub', leg_w=18, leg_x=19, arm_w=14, foot_c='#9CA4AF', hand_c='#7C838D', tail='tuft', tail_c='#9CA4AF', tail_c2='#7C838D'),
    'crocodile': A(color='#6CBF6A', belly='#A8DB8F', rx=31, ry=27, cy=134, foot_c='#6CBF6A', tail='croc', tail_c='#6CBF6A', hs=.62, hy=70, hcy=110, deco='croc', deco_c='#4E9A4E'),
    'cheetah': A(color='#EAB65A', belly='#FBE7BE', foot_c='#EAB65A', tail='long', tail_c='#EAB65A', tail_c2='#6B4423', deco='spots', deco_c='#6B4423'),
    'ostrich': A(color='#3A3550', belly='#4B4566', rx=38, ry=30, cy=141, arm='wing', arm_c='#FFFFFF', arm_len=26, leg='claw', leg_c='#EBC9A6', foot_c='#EBC9A6', leg_w=7, leg_x=16,
                 tail='fan', tail_c=['#FFFFFF', '#F0F0F0', '#FFFFFF'], neck=('#EBC9A6', 15, 40, None), hs=.62, hy=34, hcy=52, flap=True),
    'frog': A(color='#6CC24A', belly='#BDE88F', rx=38, ry=28, cy=138, arm_c='#6CC24A', leg='webbed', leg_c='#6CC24A', foot_c='#6CC24A', leg_w=16, leg_x=24, foot_rx=16,
              deco='spots', deco_c='#4FA03A', hs=.6, hy=76),
    'parrot': A(color='#3FBF6C', belly='#B6EFA0', arm='wing', arm_c='#2E86DE', leg='claw', leg_c='#FFA928', foot_c='#FFA928', leg_w=6,
                tail='feathers', tail_c=['#E53E3E', '#2E86DE', '#FFC93C'], deco='feathers', deco_c='#2FA05A', flap=True),
    'owl': A(color='#A98462', belly='#FFF3DC', rx=38, ry=34, arm='wing', arm_c='#7A5A3E', leg='claw', leg_c='#FFB62E', foot_c='#FFB62E', leg_w=6,
             deco='feathers', deco_c='#C9A98A', flap=True),
}


def mirror(parts):
    return '<g transform="translate(200 0) scale(-1 1)">' + ''.join(parts) + '</g>'


def limb(x1, y1, x2, y2, w, fill):
    d = f'M{x1} {y1} L{x2} {y2}'
    return line(d, w + 2 * SW, O) + line(d, w, fill)


def body_parts(a):
    if a.deco == 'wool':  # ovelha: corpo de algodão
        pts = [(100, 118, 27), (72, 130, 22), (128, 130, 22), (80, 152, 23), (120, 152, 23), (100, 150, 25), (66, 112, 17), (134, 112, 17)]
        return [ci(x, y, r, '#FFFFFF', sw=SW) for x, y, r in pts] + [ci(x, y, r, '#FFFFFF', False) for x, y, r in pts[:6]]
    b = [el(100, a.cy, a.rx, a.ry, a.color, sw=SW)]
    if a.belly:
        b.append(el(100, a.cy + a.ry * .25, a.rx * .62, a.ry * .62, a.belly, st=False))
    d = a.deco
    cy, rx, ry = a.cy, a.rx, a.ry
    if d == 'cow':
        b += [el(78, cy - 8, 11, 9, K, st=False), el(124, cy + 10, 13, 10, K, st=False), el(112, cy - 20, 8, 6, K, st=False)]
    elif d == 'stripes':
        for x in (66, 78, 122, 134):
            b.append(line(f'M{x} {cy-ry*.6:.0f} Q{x+(4 if x<100 else -4)} {cy} {x} {cy+ry*.6:.0f}', 5, a.deco_c))
        b.append(line(f'M100 {cy-ry+3} L100 {cy-ry*.35:.0f}', 5, a.deco_c))
    elif d == 'spots':
        for x, y in [(72, cy - 6), (86, cy - 20), (114, cy - 18), (128, cy - 4), (76, cy + 14), (124, cy + 14), (100, cy - 8)]:
            b.append(ci(x, y, 4, a.deco_c, False))
    elif d == 'tabby':
        for y in (cy - 12, cy, cy + 12):
            b.append(line(f'M{100-rx} {y} L{100-rx+9} {y+1} M{100+rx} {y} L{100+rx-9} {y+1}', 4, a.deco_c))
    elif d == 'feathers':
        for k, (x, y) in enumerate([(88, cy + 4), (112, cy + 4), (100, cy + 14), (80, cy + 16), (120, cy + 16)]):
            b.append(line(f'M{x-6} {y} Q{x} {y+8} {x+6} {y}', 2.5, a.deco_c))
    elif d == 'croc':
        for x in (76, 92, 108, 124):
            b.append(pa(f'M{x-5} {cy-ry+2} L{x} {cy-ry-6} L{x+5} {cy-ry+2}Z', a.deco_c, sw=2.5))
    return b


def arm_parts(a):
    sx, sy = 100 - (a.rx - 5), a.cy - 12
    ex, ey = sx - 6, sy + a.arm_len
    if a.arm == 'wing':
        c = a.arm_c or a.color
        return [pa(f'M{sx+4} {sy-4} Q{sx-20} {sy+4} {sx-14} {sy+a.arm_len+8} Q{sx-2} {sy+a.arm_len+4} {sx+6} {sy+10}Z', c, sw=SW)], (sx, sy)
    c = a.arm_c or a.color
    p = [limb(sx, sy, ex, ey, a.arm_w, c)]
    hc = a.hand_c or c
    p.append(ci(ex, ey + 2, a.arm_w * .62 + 1, hc, sw=SW))
    return p, (sx, sy)


def leg_parts(a):
    x = 100 - a.leg_x
    top, bot = a.cy + a.ry - 16, 182
    c = a.leg_c or a.color
    if a.leg == 'claw':  # pernas finas de ave
        top = a.cy + a.ry - 8
        p = [limb(x, top, x, 184, a.leg_w, c)]
        fc = a.foot_c
        p.append(line(f'M{x-12} 190 L{x} 184 L{x+12} 190 M{x} 184 L{x} 191', 4, O))
        p.append(line(f'M{x-12} 190 L{x} 184 L{x+12} 190 M{x} 184 L{x} 191', 2, fc))
        return p, (x, top)
    p = [limb(x, top, x, bot, a.leg_w, c)]
    fc = a.foot_c or c
    if a.leg == 'hoof':
        p.append(el(x, 186, a.leg_w * .5 + 3, 6, fc, sw=SW))
    elif a.leg == 'webbed':
        p.append(pa(f'M{x-a.foot_rx} 190 Q{x} 178 {x+a.foot_rx} 190 Q{x} 194 {x-a.foot_rx} 190Z', fc, sw=SW))
    elif a.leg == 'stub':
        p.append(el(x, 186, a.leg_w * .5 + 3, 6, fc, sw=SW))
        for dx in (-6, 0, 6):
            p.append(el(x + dx, 188, 2.6, 2, '#FFF8E8', st=False))
    else:  # paw
        p.append(el(x, 185, a.foot_rx, 7, fc, sw=SW))
    return p, (x, top)


def tail_parts(a):
    t = a.tail
    if not t:
        return None
    rx, cy = a.rx, a.cy
    bx, by = 100 + rx - 7, cy + 12
    c, c2 = a.tail_c, a.tail_c2 or a.tail_c
    if t == 'tuft':
        d = f'M{bx} {by} Q{bx+24} {by+2} {bx+20} {by+30}'
        return [line(d, 5 + 2 * SW, O), line(d, 5, c), el(bx + 20, by + 36, 8, 12, c2, rot=-8, sw=SW)], (bx, by)
    if t == 'long':
        d = f'M{bx} {by} Q{bx+34} {by-4} {bx+28} {by-38}'
        return [line(d, 8 + 2 * SW, O), line(d, 8, c), line(f'M{bx+28} {by-38} L{bx+27} {by-30}', 8, c2)], (bx, by)
    if t == 'pom':
        return [ci(bx + 6, by + 6, 9, c, sw=SW)], (bx, by)
    if t == 'curl':
        d = f'M{bx} {by} Q{bx+16} {by-2} {bx+13} {by-12} Q{bx+10} {by-20} {bx+3} {by-14}'
        return [line(d, 5 + 2 * SW, O), line(d, 5, c)], (bx, by)
    if t == 'short':
        return [el(bx + 6, by + 6, 6, 10, c, rot=-30, sw=SW)], (bx, by)
    if t == 'croc':
        pts = f'M{bx} {by-8} Q{bx+34} {by-6} {bx+46} {by+24} Q{bx+30} {by+18} {bx} {by+8}Z'
        sp = ''.join(pa(f'M{bx+8+10*i} {by-8+i*3} L{bx+12+10*i} {by-16+i*4} L{bx+16+10*i} {by-7+i*5}Z', '#4E9A4E', sw=2) for i in range(3))
        return [pa(pts, c, sw=SW)] + [sp], (bx, by)
    if t == 'fan':  # penas em leque atrás do corpo
        cols = c if isinstance(c, list) else [c]
        n = len(cols)
        out = []
        ang = [(-1 + 2 * i / (n - 1)) * 48 if n > 1 else 0 for i in range(n)]
        for col, aa in zip(cols, ang):
            r = math.radians(aa)
            out.append(el(100 + math.sin(r) * 34, cy - 12 - math.cos(r) * 30, 11, 28, col, rot=aa, sw=SW))
        return out, (100, cy - 6)
    if t == 'feathers':  # penas longas apontando para baixo
        cols = c if isinstance(c, list) else [c]
        out = []
        for col, aa in zip(cols, (-14, 0, 14)):
            r = math.radians(aa)
            out.append(el(100 + math.sin(r) * 18, cy + a.ry + 6 + math.cos(r) * 8, 8, 19, col, rot=-aa, sw=SW))
        return out, (100, cy + a.ry - 6)
    return None


def head_layer(id_, a):
    fn = getattr(G, {'hippopotamus': 'hippo', 'rhinoceros': 'rhino'}.get(id_, id_))
    parts, eyes, er = fn()
    keep = [p for i, p in enumerate(parts) if i not in HEAD_DROP[id_]]
    hs = a.hs
    tx = 100 - 100 * hs
    ty = a.hy - a.hcy * hs
    g = f'<g transform="translate({tx:.2f} {ty:.2f}) scale({hs})">' + ''.join(keep) + '</g>'
    pre = []
    pivot_y = a.hy + 0.45 * hs * 100
    if a.neck:
        col, w, top, spots = a.neck
        bot = a.cy - a.ry + 8
        pre = [pa(f'M{100-w/2} {top} L{100+w/2} {top} L{100+w/2+2} {bot} L{100-w/2-2} {bot}Z', col, sw=SW)]
        if spots:
            pre += [el(94, 70, 5, 4, spots, st=False), el(107, 88, 5, 4, spots, st=False), el(95, 104, 5, 4, spots, st=False)]
        pivot_y = a.cy - a.ry + 4
    eyes2 = [(round(tx + hs * x, 1), round(ty + hs * y, 1)) for x, y in eyes]
    return ''.join(pre) + g, eyes2, round(er * hs, 2), (100, round(pivot_y, 1))


def build(id_):
    a = CFG[id_]
    layers = []
    t = tail_parts(a)
    if t:
        layers.append(('tail', t[0], t[1]))
    lp, lpv = leg_parts(a)
    layers.append(('legL', lp, lpv))
    layers.append(('legR', [mirror(lp)], (200 - lpv[0], lpv[1])))
    layers.append(('body', body_parts(a), (100, a.cy + a.ry)))
    ap, apv = arm_parts(a)
    layers.append(('armL', ap, apv))
    layers.append(('armR', [mirror(ap)], (200 - apv[0], apv[1])))
    head, eyes, er, hp = head_layer(id_, a)
    layers.append(('head', [head], hp))
    return layers, eyes, er


def main(preview=False):
    out_dir = 'assets/images/rig'
    os.makedirs(out_dir, exist_ok=True)
    previews = {}
    for cat in ('farm', 'safari'):
        path = f'assets/data/{cat}.json'
        data = json.load(open(path, encoding='utf-8'))
        for it in data['items']:
            layers, eyes, er = build(it['id'])
            spec = []
            texts = []
            for role, parts, pivot in layers:
                asset = f'{out_dir}/{it["id"]}_{role}.svg'
                text = G.svg(parts)
                open(asset, 'w', encoding='utf-8').write(text)
                texts.append(text)
                spec.append({'role': role, 'asset': asset, 'pivot': [round(pivot[0], 1), round(pivot[1], 1)]})
            it['rig'] = {'layers': spec, 'eyes': [list(e) for e in eyes], 'eyeRadius': er,
                         'armMode': 'flap' if CFG[it['id']].flap else 'swing'}
            previews[it['id']] = (texts, spec, eyes, er)
        json.dump(data, open(path, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    print('rigs ok:', len(previews))
    return previews


if __name__ == '__main__':
    main('--preview' in sys.argv)
