#!/usr/bin/env python3
"""Gera as ilustrações SVG originais (sem olhos) e grava 'art' nos JSONs.

Os olhos são desenhados pelo Flutter por cima do SVG para poderem piscar.
Uso: python3 tools/generate_art.py   (a partir da raiz do projeto)
"""
import json, math, os

O = "#4B2E43"   # contorno único para manter o estilo consistente
K = "#2E2A3D"   # preto suave
PINK = "#F7A8BC"

def sh(): return '<ellipse cx="100" cy="188" rx="54" ry="7" fill="#000" opacity=".12"/>'
def el(cx, cy, rx, ry, f, rot=0, st=True, sw=4, op=None):
    t = f' transform="rotate({rot} {cx} {cy})"' if rot else ''
    s = f' stroke="{O}" stroke-width="{sw}"' if st else ''
    o = f' opacity="{op}"' if op else ''
    return f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" fill="{f}"{s}{o}{t}/>'
def ci(cx, cy, r, f, st=True, sw=4, op=None): return el(cx, cy, r, r, f, 0, st, sw, op)
def pa(d, f, st=True, sw=4, op=None):
    s = f' stroke="{O}" stroke-width="{sw}" stroke-linejoin="round" stroke-linecap="round"' if st else ''
    o = f' opacity="{op}"' if op else ''
    return f'<path d="{d}" fill="{f}"{s}{o}/>'
def line(d, sw=4, col=O): return f'<path d="{d}" fill="none" stroke="{col}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round"/>'
def smile(cx, cy, w=22, d=10): return line(f'M{cx-w/2} {cy} Q{cx} {cy+d} {cx+w/2} {cy}')
def cheeks(y, dx=44, r=8): return ci(100-dx, y, r, "#FF6F91", False, op=.45) + ci(100+dx, y, r, "#FF6F91", False, op=.45)
def nostrils(cx, cy, dx=10, r=3.2): return ci(cx-dx, cy, r, O, False) + ci(cx+dx, cy, r, O, False)
def bust(f, cy=164, rx=54, ry=26): return el(100, cy, rx, ry, f)
def pair(fn):  # espelha um desenho no eixo x=100
    return fn(1) + fn(-1)
def mx(x, s): return 100 + (x - 100) * s

# ---------------- FAZENDA ----------------
def cow():
    b = [sh(), bust('#FFFFFF'), el(70, 168, 14, 9, K, st=False)]
    b += [pa('M66 54 Q58 28 78 32 Q82 46 80 58Z', '#E9C88F'), pa('M134 54 Q142 28 122 32 Q118 46 120 58Z', '#E9C88F')]
    b += [el(46, 86, 20, 12, PINK, rot=-25), el(154, 86, 20, 12, PINK, rot=25)]
    b += [el(100, 94, 50, 44, '#FFFFFF'), el(130, 72, 15, 11, K, st=False), el(62, 100, 9, 12, K, st=False)]
    b += [el(100, 124, 30, 20, PINK), ci(90, 124, 3.5, O, False), ci(110, 124, 3.5, O, False), smile(100, 136, 18, 6), cheeks(108, 54)]
    return b, [(78, 92), (122, 92)], 9

def horse():
    b = [sh(), bust('#B97A4B')]
    b += [pa('M66 44 Q46 90 58 140 L92 124Z', '#6B3F25'), pa('M134 44 Q154 90 142 140 L108 124Z', '#6B3F25')]
    b += [pa('M70 52 L62 18 L90 42Z', '#B97A4B'), pa('M130 52 L138 18 L110 42Z', '#B97A4B')]
    b += [el(100, 98, 42, 56, '#B97A4B')]
    b += [pa('M76 50 Q100 28 124 50 Q112 66 100 58 Q88 66 76 50Z', '#6B3F25')]
    b += [el(100, 138, 28, 20, '#E3B48A'), nostrils(100, 140), smile(100, 152, 16, 5), cheeks(112, 38, 7)]
    return b, [(80, 94), (120, 94)], 9

def pig():
    b = [sh(), bust('#F9A8BD')]
    b += [pa('M54 64 L40 34 L78 50Z', '#F27A9B'), pa('M146 64 L160 34 L122 50Z', '#F27A9B')]
    b += [el(100, 100, 58, 50, '#F9A8BD')]
    b += [el(100, 120, 25, 18, '#F27A9B'), nostrils(100, 120, 8, 3.6), smile(100, 146, 18, 6), cheeks(110, 46)]
    return b, [(74, 92), (126, 92)], 9

def hen():
    b = [sh(), el(100, 152, 54, 36, '#F7E2B8'), el(48, 152, 14, 22, '#EACB93', rot=15), el(152, 152, 14, 22, '#EACB93', rot=-15)]
    b += [ci(84, 54, 12, '#E53E3E'), ci(100, 46, 14, '#E53E3E'), ci(116, 54, 12, '#E53E3E')]
    b += [el(100, 100, 50, 46, '#FFF3D6')]
    b += [pa('M91 106 L109 106 L100 124Z', '#FFA928'), el(100, 130, 7, 9, '#E53E3E'), cheeks(108, 42)]
    return b, [(78, 92), (122, 92)], 9

def rooster():
    b = [sh(), el(54, 92, 16, 48, '#2E9E8F', rot=-28), el(146, 92, 16, 48, '#E8913D', rot=28), el(100, 154, 50, 34, '#E9573F')]
    b += [ci(74, 58, 12, '#C62828'), ci(90, 46, 13, '#C62828'), ci(110, 46, 13, '#C62828'), ci(126, 58, 12, '#C62828')]
    b += [el(100, 100, 48, 44, '#F26A4F')]
    b += [pa('M90 106 L110 106 L100 126Z', '#FFC93C'), el(100, 134, 8, 10, '#C62828'), cheeks(108, 42)]
    return b, [(80, 92), (120, 92)], 9

def duck():
    b = [sh(), el(100, 156, 56, 30, '#FFD84A'), el(48, 152, 15, 22, '#F5C21B', rot=15), el(152, 152, 15, 22, '#F5C21B', rot=-15)]
    b += [el(100, 98, 52, 48, '#FFD84A'), pa('M96 52 Q98 32 114 40 Q104 44 104 54Z', '#FFD84A')]
    b += [el(100, 122, 32, 16, '#FF9F1C'), ci(90, 118, 2.5, O, False), ci(110, 118, 2.5, O, False), line('M72 124 Q100 132 128 124', 3), cheeks(106, 52)]
    return b, [(76, 88), (124, 88)], 9

def sheep():
    w = '#FFFFFF'
    b = [sh(), el(100, 160, 54, 26, w)]
    b += [ci(58, 72, 24, w), ci(100, 54, 26, w), ci(142, 72, 24, w), ci(52, 108, 22, w), ci(148, 108, 22, w), ci(72, 142, 24, w), ci(128, 142, 24, w)]
    b += [el(46, 100, 15, 8, '#3C3550', rot=25), el(154, 100, 15, 8, '#3C3550', rot=-25)]
    b += [el(100, 108, 34, 42, '#F3E1CF'), ci(86, 66, 14, w), ci(114, 66, 14, w), ci(100, 120, 5, '#E39AA6', False), smile(100, 132, 14, 6), cheeks(118, 30, 6)]
    return b, [(85, 102), (115, 102)], 8.5

def goat():
    b = [sh(), bust('#D8C4A5')]
    b += [pa('M70 52 Q52 22 74 12 Q68 32 84 48Z', '#EFE2CB'), pa('M130 52 Q148 22 126 12 Q132 32 116 48Z', '#EFE2CB')]
    b += [el(44, 90, 22, 10, '#CDB799', rot=22), el(156, 90, 22, 10, '#CDB799', rot=-22)]
    b += [el(100, 98, 44, 50, '#D8C4A5'), el(100, 128, 26, 18, '#F0E2CC'), nostrils(100, 126, 8), pa('M92 144 Q100 178 108 144Z', '#F0E2CC'), smile(100, 138, 14, 4), cheeks(110, 40, 7)]
    return b, [(80, 92), (120, 92)], 9

def donkey():
    b = [sh(), bust('#9BA2AC')]
    b += [el(66, 40, 13, 34, '#9BA2AC', rot=-14), el(66, 42, 6, 24, '#F4C1CC', rot=-14, st=False), el(134, 40, 13, 34, '#9BA2AC', rot=14), el(134, 42, 6, 24, '#F4C1CC', rot=14, st=False)]
    b += [el(100, 98, 44, 52, '#9BA2AC'), pa('M80 58 Q100 36 120 58 Q108 70 100 64 Q92 70 80 58Z', '#5E636E')]
    b += [el(100, 134, 30, 22, '#ECE8E2'), nostrils(100, 134, 10), smile(100, 148, 16, 5), cheeks(110, 40, 7)]
    return b, [(80, 94), (120, 94)], 9

def rabbit():
    b = [sh(), bust('#F6D5E6')]
    b += [el(76, 42, 14, 42, '#F6D5E6', rot=-8), el(76, 46, 7, 30, '#F29CB8', rot=-8, st=False), el(124, 42, 14, 42, '#F6D5E6', rot=8), el(124, 46, 7, 30, '#F29CB8', rot=8, st=False)]
    b += [el(100, 106, 50, 46, '#F6D5E6'), pa('M94 112 L106 112 L100 120Z', '#F2799E'), line('M100 120 L100 126 M100 126 Q92 134 85 128 M100 126 Q108 134 115 128'), pa('M94 130 L106 130 L106 140 L94 140Z', '#FFFFFF', sw=3), cheeks(112, 44)]
    return b, [(78, 98), (122, 98)], 9

# ---------------- SAFÁRI ----------------
def lion():
    b = [sh()]
    for i in range(16):
        a = i * 2 * math.pi / 16
        b.append(ci(round(100 + 56 * math.cos(a), 1), round(100 + 56 * math.sin(a), 1), 19, '#E8872E'))
    b += [ci(100, 100, 56, '#E8872E', False), ci(62, 58, 13, '#F7B648'), ci(138, 58, 13, '#F7B648'), el(100, 102, 44, 42, '#F7B648')]
    b += [el(100, 122, 25, 16, '#FCE2A8'), pa('M92 113 L108 113 L100 123Z', '#7A3E2D'), line('M100 123 L100 129 Q90 137 82 131 M100 129 Q110 137 118 131'), cheeks(110, 46)]
    return b, [(80, 94), (120, 94)], 9

def elephant():
    b = [sh(), el(38, 100, 34, 42, '#B9A4D8'), el(40, 102, 19, 28, '#DCCBF0', st=False), el(162, 100, 34, 42, '#B9A4D8'), el(160, 102, 19, 28, '#DCCBF0', st=False)]
    b += [el(100, 94, 50, 48, '#A993CB'), pa('M84 110 Q80 160 102 170 Q118 174 122 160 Q112 160 112 148 Q114 124 116 110Z', '#A993CB'),
          line('M90 130 Q99 135 108 130', 3), line('M90 142 Q99 147 109 142', 3),
          pa('M76 124 Q64 146 78 154 Q80 140 90 128Z', '#FFF8E8'), cheeks(108, 44)]
    return b, [(80, 88), (120, 88)], 9

def giraffe():
    y = '#F8D448'; s = '#C77A2B'
    b = [line('M82 40 L80 24', 5), ci(80, 20, 7, '#8B5A2B'), line('M118 40 L120 24', 5), ci(120, 20, 7, '#8B5A2B')]
    b += [pa('M74 96 L66 196 L134 196 L126 96Z', y), el(90, 128, 9, 7, s, st=False), el(114, 150, 10, 8, s, st=False), el(92, 170, 10, 8, s, st=False), el(116, 112, 7, 6, s, st=False)]
    b += [el(52, 58, 15, 8, y, rot=-20), el(148, 58, 15, 8, y, rot=20), el(100, 64, 40, 34, y), el(80, 44, 6, 5, s, st=False), el(120, 42, 5, 4, s, st=False)]
    b += [el(100, 82, 24, 16, '#F9E2B8'), nostrils(100, 82, 8, 2.8), smile(100, 92, 14, 4), cheeks(72, 44, 6)]
    return b, [(84, 60), (116, 60)], 8

def zebra():
    W = '#F4F4F4'
    b = [sh(), bust(W)]
    b += [pa('M70 52 L62 20 L90 42Z', K), pa('M130 52 L138 20 L110 42Z', K)]
    b += [el(100, 98, 42, 54, W)]
    for x1, y1, x2, y2 in [(62, 70, 76, 86), (62, 100, 72, 116)]:
        b += [line(f'M{x1} {y1} Q80 {y1+6} {x2} {y2}', 6, K), line(f'M{200-x1} {y1} Q120 {y1+6} {200-x2} {y2}', 6, K)]
    b += [line('M100 46 L100 66', 6, K), pa('M68 50 Q100 24 132 50 Q116 44 100 46 Q84 44 68 50Z', K)]
    b += [el(100, 134, 28, 20, '#C9CFD6'), nostrils(100, 136), smile(100, 148, 16, 5), cheeks(112, 38, 7)]
    return b, [(80, 92), (120, 92)], 9

def monkey():
    f = '#B76A49'; c = '#F2C9A0'
    b = [sh(), bust(f), ci(46, 100, 18, f), ci(46, 100, 9, c, False), ci(154, 100, 18, f), ci(154, 100, 9, c, False)]
    b += [el(100, 96, 50, 46, f), ci(84, 92, 19, c), ci(116, 92, 19, c), el(100, 112, 32, 28, c)]
    b += [ci(93, 112, 2.6, O, False), ci(107, 112, 2.6, O, False), smile(100, 124, 24, 10), cheeks(112, 38, 7)]
    return b, [(84, 94), (116, 94)], 8.5

def hippo():
    f = '#8EA6D8'
    b = [sh(), bust(f), el(56, 56, 11, 9, f), el(144, 56, 11, 9, f)]
    b += [el(100, 100, 56, 46, f), ci(72, 74, 14, f), ci(128, 74, 14, f), el(100, 126, 46, 28, '#A9BDE6')]
    b += [el(82, 118, 5, 4, O, False), el(118, 118, 5, 4, O, False), line('M80 138 Q100 150 120 138'), cheeks(116, 58, 7)]
    return b, [(72, 74), (128, 74)], 8

def rhino():
    f = '#9CA4AF'
    b = [sh(), bust(f), el(56, 54, 12, 17, f, rot=-25), el(144, 54, 12, 17, f, rot=25)]
    b += [el(100, 102, 50, 48, f), el(100, 128, 34, 20, '#B7BFC9'), nostrils(100, 130, 12), pa('M89 114 Q100 58 111 114Z', '#F0E6D2'), line('M94 100 L106 100 M92 108 L108 108', 3), smile(100, 142, 16, 5), cheeks(112, 46, 7)]
    return b, [(74, 92), (126, 92)], 9

def crocodile():
    g = '#6CBF6A'
    b = [sh(), ci(70, 64, 16, g), ci(130, 64, 16, g)]
    b += [pa('M40 104 Q40 70 100 70 Q160 70 160 104 L160 140 Q160 164 100 164 Q40 164 40 140Z', g), el(100, 138, 50, 22, '#A8DB8F', st=False)]
    b += [ci(88, 112, 4, O, False), ci(112, 112, 4, O, False), line('M52 144 Q100 162 148 144')]
    for x in (66, 84, 116, 134):
        b.append(pa(f'M{x} 148 L{x+5} 158 L{x+10} 148Z', '#FFFFFF', sw=2.5))
    b += [ci(60, 96, 3, '#4E9A4E', False), ci(140, 96, 3, '#4E9A4E', False), ci(100, 84, 3, '#4E9A4E', False), cheeks(124, 56, 6)]
    return b, [(70, 62), (130, 62)], 9

def cheetah():
    f = '#EAB65A'
    b = [sh(), bust(f), ci(58, 56, 13, f), ci(58, 56, 6, '#8A5A2B', False), ci(142, 56, 13, f), ci(142, 56, 6, '#8A5A2B', False)]
    b += [el(100, 100, 48, 46, f), el(100, 124, 26, 18, '#FBE7BE'), pa('M93 114 L107 114 L100 122Z', O), line('M100 122 L100 128 Q92 134 86 129 M100 128 Q108 134 114 129', 3)]
    b += [line('M80 102 Q76 120 86 134', 4, '#6B4423'), line('M120 102 Q124 120 114 134', 4, '#6B4423')]
    for x, y in [(66, 80), (78, 64), (100, 66), (122, 64), (134, 80), (60, 112), (140, 112)]:
        b.append(ci(x, y, 3.8, '#6B4423', False))
    return b, [(80, 94), (120, 94)], 9

def ostrich():
    sk = '#EBC9A6'
    b = [sh(), line('M86 176 L84 192', 5), line('M114 176 L116 192', 5), line('M84 192 L74 192 M116 192 L126 192', 5)]
    b += [el(42, 126, 16, 26, '#FFFFFF', rot=28), el(158, 126, 16, 26, '#FFFFFF', rot=-28)]
    b += [pa('M86 150 C80 112 84 86 90 70 L110 70 C116 86 120 112 114 150Z', sk)]
    b += [el(100, 148, 52, 36, '#3A3550'), el(100, 130, 22, 8, '#4B4566', st=False)]
    b += [line('M92 28 Q88 14 96 10 M100 26 L100 10 M108 28 Q112 14 104 10', 3.5)]
    b += [ci(100, 52, 28, sk), pa('M90 62 L110 62 L100 80Z', '#FFA928'), cheeks(64, 26, 5.5)]
    return b, [(88, 48), (112, 48)], 9

# ---------------- FRUTAS ----------------
def hl(x, y, rx=8, ry=14, rot=20): return el(x, y, rx, ry, '#FFFFFF', rot=rot, st=False, op=.4)
def leaf(x, y, dx=40, dy=-14): return pa(f'M{x} {y} Q{x+dx*.5} {y+dy*2.2} {x+dx} {y+dy} Q{x+dx*.6} {y+dy*-.9} {x} {y}Z', '#5DB86B')

def apple():
    b = [sh(), pa('M100 56 C70 40 36 66 44 110 C50 150 80 176 100 168 C120 176 150 150 156 110 C164 66 130 40 100 56Z', '#E8483D')]
    b += [pa('M96 54 Q98 38 108 28 L114 32 Q106 40 106 56Z', '#7A4A2B'), leaf(106, 44, 38, -14), hl(66, 86), smile(100, 124, 22, 10), cheeks(118, 38)]
    return b, [(80, 100), (120, 100)], 9

def banana():
    b = [sh(), pa('M18 84 C30 170 140 190 184 62 C186 54 176 52 170 58 C130 116 76 104 42 62 C36 56 20 68 18 84Z', '#FFD94A')]
    b += [pa('M170 58 L184 62 L192 46 L178 42Z', '#7A5A2B'), ci(22, 80, 5, '#7A5A2B'), line('M36 96 Q90 156 156 104', 3, '#E0B52C')]
    b += [smile(92, 138, 18, 6), ci(62, 134, 6, "#FF6F91", False, op=.45), ci(124, 134, 6, "#FF6F91", False, op=.45)]
    return b, [(76, 118), (108, 120)], 8.5

def orange():
    b = [sh(), ci(100, 108, 64, '#FF9A2E'), ci(100, 46, 6, '#7A4A2B'), leaf(102, 46, 40, -14), hl(62, 86, 8, 16)]
    for x, y in [(60, 126), (140, 126), (150, 98), (52, 98), (100, 160), (120, 152), (80, 152)]:
        b.append(ci(x, y, 2.2, '#E57F14', False))
    b += [smile(100, 126, 22, 10), cheeks(120, 40)]
    return b, [(80, 102), (120, 102)], 9

def strawberry():
    b = [sh(), pa('M100 178 C48 150 34 100 40 72 C46 50 72 46 100 58 C128 46 154 50 160 72 C166 100 152 150 100 178Z', '#F0455A')]
    for x, y in [(60, 78), (140, 78), (52, 110), (148, 110), (66, 138), (134, 138), (100, 156), (84, 76), (116, 76)]:
        b.append(el(x, y, 2.6, 4, '#FFE4A0', st=False))
    b += [pa('M100 62 L72 54 L84 42 L100 52 L116 42 L128 54Z', '#4FAE5E'), pa('M100 56 L96 36 L106 36Z', '#4FAE5E'), smile(100, 118, 20, 9), cheeks(112, 36)]
    return b, [(80, 98), (120, 98)], 9

def grapes():
    cols = ['#8E5BC4', '#9C69D2']
    pts = [(66, 66), (100, 56), (134, 66), (50, 96), (150, 96), (62, 130), (138, 130), (82, 156), (118, 156), (100, 174)]
    b = [sh(), line('M100 48 Q100 32 112 22', 6, '#7A4A2B'), leaf(104, 40, 44, -14)]
    for i, (x, y) in enumerate(pts):
        b.append(ci(x, y, 23, cols[i % 2]))
    b += [ci(100, 106, 40, '#B183E0'), hl(80, 76, 5, 8), smile(100, 122, 22, 10), cheeks(116, 40, 7)]
    return b, [(84, 100), (116, 100)], 9

def watermelon():
    b = ['<g transform="translate(0 16)">', sh().replace('cy="188"', 'cy="170"'),
         pa('M20 66 A80 80 0 0 0 180 66Z', '#4CAF50'), pa('M28 66 A72 72 0 0 0 172 66Z', '#F6FFF0', st=False), pa('M33 66 A67 67 0 0 0 167 66Z', '#F2495B', st=False)]
    for x, y in [(60, 86), (140, 86), (78, 118), (122, 118), (100, 134)]:
        b.append(el(x, y, 3.4, 5.5, K, st=False, rot=-15))
    b += [smile(100, 108, 22, 10), cheeks(102, 44, 8), '</g>']
    return b, [(78, 96 + 16), (122, 96 + 16)], 9

def pineapple():
    b = [sh(), '<clipPath id="pc"><ellipse cx="100" cy="130" rx="46" ry="56"/></clipPath>', el(100, 130, 46, 56, '#F6C23E')]
    b.append('<g clip-path="url(#pc)">' + ''.join(line(f'M{x} 70 L{x+60} 190', 2.5, '#D9941F') + line(f'M{x+60} 70 L{x} 190', 2.5, '#D9941F') for x in range(20, 140, 24)).replace('stroke-width="2.5"', 'stroke-width="2.5" opacity=".35"') + '</g>')
    b.append(el(100, 130, 46, 56, 'none'))
    b += [pa('M100 78 Q64 44 70 12 Q90 40 100 56 Q110 40 130 12 Q136 44 100 78Z', '#4FAE5E'), pa('M100 80 Q50 70 40 42 Q76 52 100 74Z', '#5DB86B'), pa('M100 80 Q150 70 160 42 Q124 52 100 74Z', '#5DB86B')]
    b += [smile(100, 142, 20, 9), cheeks(136, 34, 7)]
    return b, [(84, 122), (116, 122)], 8.5

def pear():
    b = [sh(), pa('M100 42 C120 42 124 66 132 88 C150 108 160 130 150 154 C140 182 60 182 50 154 C40 130 50 108 68 88 C76 66 80 42 100 42Z', '#B8D45A')]
    b += [pa('M96 44 Q98 28 108 20 L114 24 Q106 32 106 46Z', '#7A4A2B'), leaf(106, 38, 38, -12), hl(70, 124, 7, 14, 15), smile(100, 150, 20, 9), cheeks(144, 34, 7)]
    return b, [(82, 130), (118, 130)], 9

def mango():
    g = '<defs><linearGradient id="mg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFD05A"/><stop offset=".55" stop-color="#FFA640"/><stop offset="1" stop-color="#F26B3A"/></linearGradient></defs>'
    b = [sh(), g, pa('M96 56 C150 40 182 92 164 134 C148 174 92 182 60 160 C26 136 36 72 96 56Z', 'url(#mg)')]
    b += [pa('M92 58 Q92 44 102 36 L108 40 Q102 48 102 60Z', '#7A4A2B'), leaf(102, 50, 42, -14), hl(62, 92, 7, 14)]
    b += [smile(100, 132, 22, 10), cheeks(126, 40, 8)]
    return b, [(80, 108), (120, 108)], 9

def lemon():
    b = [sh(), pa('M22 108 Q30 96 44 94 C52 52 148 52 156 94 Q170 96 178 108 Q170 120 156 122 C148 166 52 166 44 122 Q30 120 22 108Z', '#F5E33D')]
    b += [leaf(112, 62, 38, -12), hl(70, 82, 8, 12, 25), smile(100, 124, 22, 10), cheeks(118, 42, 8)]
    return b, [(80, 104), (120, 104)], 9

ART = {
 'farm': dict(cow=cow, horse=horse, pig=pig, hen=hen, rooster=rooster, duck=duck, sheep=sheep, goat=goat, donkey=donkey, rabbit=rabbit),
 'safari': dict(lion=lion, elephant=elephant, giraffe=giraffe, zebra=zebra, monkey=monkey, hippopotamus=hippo, rhinoceros=rhino, crocodile=crocodile, cheetah=cheetah, ostrich=ostrich),
 'fruits': dict(apple=apple, banana=banana, orange=orange, strawberry=strawberry, grapes=grapes, watermelon=watermelon, pineapple=pineapple, pear=pear, mango=mango, lemon=lemon),
}

def svg(parts): return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200">' + ''.join(parts) + '</svg>\n'

# ---------------- CENÁRIOS (400x800) ----------------
def scene(body): return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 800" preserveAspectRatio="xMidYMax slice">' + body + '</svg>\n'
def cloud(x, y, s=1):
    return f'<g transform="translate({x} {y}) scale({s})" fill="#fff" opacity=".9"><ellipse cx="0" cy="0" rx="40" ry="16"/><ellipse cx="-22" cy="-10" rx="22" ry="16"/><ellipse cx="14" cy="-14" rx="26" ry="20"/></g>'
def acacia(x, y, s=1):
    return (f'<g transform="translate({x} {y}) scale({s})"><path d="M-6 0 Q-4 -50 -18 -90 L-10 -92 Q0 -60 2 -50 Q6 -70 18 -96 L26 -92 Q10 -60 6 0Z" fill="#7A5230"/>'
            '<ellipse cx="0" cy="-100" rx="64" ry="18" fill="#5E9E4A"/><ellipse cx="-30" cy="-112" rx="36" ry="14" fill="#6DB257"/><ellipse cx="34" cy="-110" rx="34" ry="13" fill="#6DB257"/></g>')

SCENES = {
 'safari': scene(
   '<defs><linearGradient id="s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFD58A"/><stop offset=".55" stop-color="#FFF0C9"/></linearGradient>'
   '<linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#E9C46A"/><stop offset="1" stop-color="#CFA044"/></linearGradient></defs>'
   '<rect width="400" height="800" fill="url(#s)"/><circle cx="310" cy="130" r="86" fill="#FFE29A" opacity=".5"/><circle cx="310" cy="130" r="56" fill="#FFC93C"/>'
   + cloud(80, 120, 1.1) + cloud(220, 230, .8) +
   '<path d="M0 520 Q100 470 200 510 T400 490 L400 800 L0 800Z" fill="#D9B35A"/><path d="M0 560 L400 560 L400 800 L0 800Z" fill="url(#g)"/>'
   + acacia(70, 560, 1) + acacia(330, 540, .8) +
   '<g fill="#8DB84A">' + ''.join(f'<path d="M{x} 790 L{x-6} 760 L{x} 776 L{x+4} 750 L{x+8} 776 L{x+14} 762 L{x+12} 790Z"/>' for x in range(10, 400, 70)) + '</g>'),
 'farm': scene(
   '<defs><linearGradient id="s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8FD6FF"/><stop offset="1" stop-color="#E4F8FF"/></linearGradient></defs>'
   '<rect width="400" height="800" fill="url(#s)"/><circle cx="70" cy="110" r="44" fill="#FFE27A"/>' + cloud(250, 120, 1.1) + cloud(120, 250, .8) +
   '<path d="M0 520 Q120 440 260 500 T400 480 L400 800 L0 800Z" fill="#8BDB5E"/><path d="M0 600 Q140 540 400 590 L400 800 L0 800Z" fill="#6CCB4A"/>'
   '<g transform="translate(300 470)"><rect x="0" y="0" width="80" height="60" fill="#D9473A"/><path d="M-8 4 L40 -32 L88 4Z" fill="#B8322A"/><rect x="26" y="22" width="28" height="38" fill="#fff" opacity=".9"/><path d="M26 22 L54 60 M54 22 L26 60" stroke="#D9473A" stroke-width="3"/></g>'
   '<g fill="#fff" opacity=".95">' + ''.join(f'<rect x="{x}" y="560" width="10" height="46" rx="3"/>' for x in range(0, 300, 36)) + '<rect x="0" y="574" width="290" height="8" rx="3"/><rect x="0" y="592" width="290" height="8" rx="3"/></g>'
   '<g fill="#FFF">' + ''.join(f'<circle cx="{x}" cy="{y}" r="5"/>' for x, y in [(40, 700), (140, 740), (260, 690), (350, 750), (90, 780)]) + '</g>'),
 'fruits': scene(
   '<defs><linearGradient id="s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFC9D9"/><stop offset="1" stop-color="#FFF1D6"/></linearGradient></defs>'
   '<rect width="400" height="800" fill="url(#s)"/>'
   + ''.join(f'<circle cx="{x}" cy="{y}" r="{r}" fill="#fff" opacity=".35"/>' for x, y, r in [(60, 90, 30), (330, 160, 44), (120, 300, 20), (350, 420, 26), (50, 520, 36), (300, 640, 30)]) +
   '<path d="M0 640 Q100 600 200 640 T400 630 L400 800 L0 800Z" fill="#9BE0A5"/><path d="M0 700 Q120 670 240 705 T400 690 L400 800 L0 800Z" fill="#7DD08A"/>'
   + ''.join(f'<g transform="translate({x} {y}) rotate({r})"><path d="M0 0 Q18 -26 44 -14 Q28 14 0 0Z" fill="#5DB86B" opacity=".8"/></g>' for x, y, r in [(20, 760, -20), (300, 740, 10), (170, 770, -5)])),
}

def main():
    os.makedirs('assets/images/scenes', exist_ok=True)
    for cat, items in ART.items():
        os.makedirs(f'assets/images/{cat}', exist_ok=True)
        data_path = f'assets/data/{cat}.json'
        data = json.load(open(data_path, encoding='utf-8'))
        for it in data['items']:
            parts, eyes, er = items[it['id']]()
            path = f'assets/images/{cat}/{it["id"]}.svg'
            open(path, 'w', encoding='utf-8').write(svg(parts))
            it['art'] = {'asset': path, 'eyes': [list(e) for e in eyes], 'eyeRadius': er}
        if cat in SCENES:
            data['scene'] = f'assets/images/scenes/{cat}.svg'
            open(data['scene'], 'w', encoding='utf-8').write(SCENES[cat])
        json.dump(data, open(data_path, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    print('ok')

if __name__ == '__main__':
    main()
