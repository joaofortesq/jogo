#!/usr/bin/env python3
"""Gera a música de fundo da Festa dos Bichos: assets/audio/music/festa.ogg

Arranjo próprio (sintetizado aqui, sem gravações de terceiros) de melodias
infantis tradicionais em domínio público:
  - "Brilha, brilha, estrelinha" (Twinkle Twinkle / Ah! vous dirai-je, maman)
  - "Frère Jacques" (Meu lanchinho / Are you sleeping?)
  - "Mary had a little lamb" (Mary tinha um carneirinho)
  - "Old MacDonald had a farm" (O velho MacDonald / Seu Lobato tinha um sítio)

Instrumentos: xilofone (melodia), baixo, ukulele (acordes no contratempo),
bumbo, palmas e chocalho. Cerca de 1min45s, em loop sem emenda (o fim
encaixa no começo). Formato OGG porque o Android repete OGG sem o "buraco"
que o MP3 deixa no ponto do loop.

Requer numpy e ffmpeg. Uso (na raiz do projeto): python3 tools/generate_music.py
"""
import pathlib
import shutil
import subprocess
import sys
import tempfile
import wave

import numpy as np

RATE = 44100
BPM = 116
BEAT = 60.0 / BPM
OUT = pathlib.Path(__file__).resolve().parent.parent / 'assets' / 'audio' / 'music' / 'festa.ogg'

NOTE = {'C': 0, 'D': 2, 'E': 4, 'F': 5, 'G': 7, 'A': 9, 'B': 11}


def hz(name):
    """'C5', 'F#4', 'Bb3' -> frequência."""
    pitch = NOTE[name[0]]
    rest = name[1:]
    if rest[0] == '#':
        pitch += 1
        rest = rest[1:]
    elif rest[0] == 'b':
        pitch -= 1
        rest = rest[1:]
    midi = 12 * (int(rest) + 1) + pitch
    return 440.0 * 2 ** ((midi - 69) / 12)


def t(n):
    return np.arange(int(n)) / RATE


# ---------------- instrumentos ----------------

def xylophone(f, dur, vol=0.32):
    n = int(RATE * min(dur + 0.35, 1.2))
    x = t(n)
    env = np.minimum(1, x / 0.003) * np.exp(-x * 7.5)
    s = (np.sin(2 * np.pi * f * x)
         + 0.32 * np.sin(2 * np.pi * f * 3.93 * x) * np.exp(-x * 22)
         + 0.12 * np.sin(2 * np.pi * f * 9.2 * x) * np.exp(-x * 40))
    return vol * env * s


def bell(f, dur, vol=0.10):
    """Brilhinho uma oitava acima (dobra a melodia, bem baixinho)."""
    n = int(RATE * min(dur + 0.5, 1.4))
    x = t(n)
    env = np.minimum(1, x / 0.002) * np.exp(-x * 5)
    s = np.sin(2 * np.pi * f * 2 * x) + 0.4 * np.sin(2 * np.pi * f * 5.4 * x) * np.exp(-x * 12)
    return vol * env * s


def bass(f, dur, vol=0.34):
    n = int(RATE * dur * 0.9)
    x = t(n)
    env = np.minimum(1, x / 0.006) * np.exp(-x * 3.2) * np.minimum(1, (n - np.arange(n)) / (RATE * 0.02))
    s = np.sin(2 * np.pi * f * x) + 0.35 * np.sin(2 * np.pi * f * 2 * x) + 0.1 * np.sin(2 * np.pi * f * 3 * x)
    return vol * env * s


def pluck(f, dur, vol=0.07):
    """Karplus-Strong simples: som de ukulele."""
    n = int(RATE * dur)
    period = max(2, int(RATE / f))
    rng = np.random.default_rng(int(f * 10))
    buf = rng.uniform(-1, 1, period)
    out = np.zeros(n)
    for i in range(n):
        j = i % period
        out[i] = buf[j]
        buf[j] = 0.5 * (buf[j] + buf[(j + 1) % period]) * 0.996
    return vol * out


def kick(vol=0.55):
    x = t(RATE * 0.22)
    f = 120 * np.exp(-x * 25) + 45
    phase = 2 * np.pi * np.cumsum(f) / RATE
    return vol * np.sin(phase) * np.exp(-x * 14)


def clap(vol=0.16):
    x = t(RATE * 0.16)
    rng = np.random.default_rng(7)
    noise = rng.uniform(-1, 1, len(x))
    # passa-alta simples
    noise = np.concatenate([[0], np.diff(noise)])
    env = np.exp(-x * 30) + 0.6 * np.exp(-((x - 0.012) * 300) ** 2)
    return vol * noise * env


def shaker(vol=0.045):
    x = t(RATE * 0.07)
    rng = np.random.default_rng(3)
    noise = np.concatenate([[0], np.diff(rng.uniform(-1, 1, len(x)))])
    return vol * noise * np.minimum(1, x / 0.01) * np.exp(-x * 60)


# ---------------- música ----------------
# Cada melodia: lista de (nota, batidas). '-' = pausa. Acordes: um por compasso (4 batidas).

TWINKLE = [
    ('C5', 1), ('C5', 1), ('G5', 1), ('G5', 1), ('A5', 1), ('A5', 1), ('G5', 2),
    ('F5', 1), ('F5', 1), ('E5', 1), ('E5', 1), ('D5', 1), ('D5', 1), ('C5', 2),
    ('G5', 1), ('G5', 1), ('F5', 1), ('F5', 1), ('E5', 1), ('E5', 1), ('D5', 2),
    ('G5', 1), ('G5', 1), ('F5', 1), ('F5', 1), ('E5', 1), ('E5', 1), ('D5', 2),
    ('C5', 1), ('C5', 1), ('G5', 1), ('G5', 1), ('A5', 1), ('A5', 1), ('G5', 2),
    ('F5', 1), ('F5', 1), ('E5', 1), ('E5', 1), ('D5', 1), ('D5', 1), ('C5', 2),
]
TWINKLE_CH = ['C', 'C', 'F', 'C', 'G', 'C', 'C', 'G', 'C', 'G', 'C', 'G', 'C', 'C', 'F', 'C', 'G', 'C', 'G', 'C'][:12]
TWINKLE_CH = ['C', 'F C', 'G C', 'G C', 'C G', 'C G', 'C G', 'C G', 'C', 'F C', 'G C', 'G C']

JACQUES = [
    ('C5', 1), ('D5', 1), ('E5', 1), ('C5', 1), ('C5', 1), ('D5', 1), ('E5', 1), ('C5', 1),
    ('E5', 1), ('F5', 1), ('G5', 2), ('E5', 1), ('F5', 1), ('G5', 2),
    ('G5', .5), ('A5', .5), ('G5', .5), ('F5', .5), ('E5', 1), ('C5', 1),
    ('G5', .5), ('A5', .5), ('G5', .5), ('F5', .5), ('E5', 1), ('C5', 1),
    ('C5', 1), ('G4', 1), ('C5', 2), ('C5', 1), ('G4', 1), ('C5', 2),
]
JACQUES_CH = ['C', 'C', 'C', 'C', 'C', 'C', 'C G', 'C']

MARY = [
    ('E5', 1), ('D5', 1), ('C5', 1), ('D5', 1), ('E5', 1), ('E5', 1), ('E5', 2),
    ('D5', 1), ('D5', 1), ('D5', 2), ('E5', 1), ('G5', 1), ('G5', 2),
    ('E5', 1), ('D5', 1), ('C5', 1), ('D5', 1), ('E5', 1), ('E5', 1), ('E5', 1), ('E5', 1),
    ('D5', 1), ('D5', 1), ('E5', 1), ('D5', 1), ('C5', 4),
]
MARY_CH = ['C', 'C', 'G', 'C', 'C', 'C', 'G', 'C']

MACDONALD = [
    ('G5', 1), ('G5', 1), ('G5', 1), ('D5', 1), ('E5', 1), ('E5', 1), ('D5', 2),
    ('B5', 1), ('B5', 1), ('A5', 1), ('A5', 1), ('G5', 3), ('D5', 1),
    ('G5', 1), ('G5', 1), ('G5', 1), ('D5', 1), ('E5', 1), ('E5', 1), ('D5', 2),
    ('B5', 1), ('B5', 1), ('A5', 1), ('A5', 1), ('G5', 4),
]
MACDONALD_CH = ['G', 'C G', 'G', 'D G', 'G', 'C G', 'G', 'D G']

# Introdução e ponte originais (só acordes e um motivo curto).
INTRO = [('-', 2), ('G4', .5), ('A4', .5), ('B4', .5), ('D5', .5),
         ('C5', 1), ('E5', 1), ('G5', 1), ('E5', 1),
         ('F5', 1), ('A5', 1), ('G5', 1), ('E5', 1),
         ('D5', 1), ('E5', .5), ('D5', .5), ('C5', 1), ('-', 1)]
INTRO_CH = ['G', 'C', 'F C', 'G C']

BRIDGE = [('E5', .5), ('G5', .5), ('C6', 1), ('G5', 1), ('E5', 1),
          ('F5', .5), ('A5', .5), ('C6', 1), ('A5', 1), ('F5', 1),
          ('G5', .5), ('F5', .5), ('E5', .5), ('D5', .5), ('E5', 1), ('C5', 1),
          ('D5', .5), ('E5', .5), ('F5', .5), ('D5', .5), ('G5', 2)]
BRIDGE_CH = ['C', 'F', 'C', 'G']

CHORDS = {
    'C': ['C4', 'E4', 'G4'], 'F': ['F4', 'A4', 'C5'], 'G': ['G3', 'B3', 'D4'],
    'D': ['D4', 'F#4', 'A4'],
}
ROOT = {'C': ('C3', 'G2'), 'F': ('F2', 'C3'), 'G': ('G2', 'D3'), 'D': ('D3', 'A2')}


def transpose(melody, semis):
    if semis == 0:
        return melody
    out = []
    for n, b in melody:
        if n == '-':
            out.append((n, b))
        else:
            out.append((n, b, semis))
    return out


SECTIONS = [
    (INTRO, INTRO_CH, 0),
    (TWINKLE, TWINKLE_CH, 0),
    (JACQUES, JACQUES_CH, 0),
    (BRIDGE, BRIDGE_CH, 0),
    (MARY, MARY_CH, 0),
    (MACDONALD, MACDONALD_CH, 0),
    (BRIDGE, BRIDGE_CH, 0),
]


def render():
    bars = sum(len(ch) for _, ch, _ in SECTIONS)
    total = int(bars * 4 * BEAT * RATE)
    buf = np.zeros(total + RATE * 2)

    def put(sig, start_s):
        i = int(start_s * RATE)
        buf[i:i + len(sig)] += sig

    bar0 = 0
    rng = np.random.default_rng(1)
    for melody, chords, _ in SECTIONS:
        # melodia
        pos = bar0 * 4 * BEAT
        for n, b in melody:
            if n != '-':
                f = hz(n)
                swing = rng.uniform(-0.004, 0.004)  # humaniza um pouquinho
                put(xylophone(f, b * BEAT), pos + swing)
                put(bell(f, b * BEAT), pos + swing)
            pos += b * BEAT
        # acordes, baixo e bateria, compasso a compasso
        for k, ch in enumerate(chords):
            bar_start = (bar0 + k) * 4 * BEAT
            halves = ch.split()
            for h in range(4):
                c = halves[0] if (len(halves) == 1 or h < 2) else halves[1]
                beat_t = bar_start + h * BEAT
                root, fifth = ROOT[c]
                put(bass(hz(root if h % 2 == 0 else fifth), BEAT), beat_t)
                # ukulele no contratempo
                for j, nn in enumerate(CHORDS[c]):
                    put(pluck(hz(nn), BEAT * 0.5), beat_t + BEAT * 0.5 + j * 0.012)
                if h % 2 == 0:
                    put(kick(), beat_t)
                else:
                    put(clap(), beat_t)
                put(shaker(), beat_t)
                put(shaker(0.03), beat_t + BEAT * 0.5)
        bar0 += len(chords)
    # Loop sem emenda: o que passa do fim (rabo das notas) volta para o começo.
    tail = buf[total:]
    buf = buf[:total]
    buf[:len(tail)] += tail
    # Leve eco curto, deixa o som mais "cheio".
    d = int(RATE * 0.11)
    wet = np.zeros_like(buf)
    wet[d:] = buf[:-d] * 0.18
    wet[:d] += buf[-d:] * 0.18  # o eco também dá a volta
    buf = buf + wet
    # Compressão suave e normalização
    buf = np.tanh(buf * 1.2) / np.tanh(1.2)
    buf = buf / np.max(np.abs(buf)) * 0.85
    return buf


def main():
    if not shutil.which('ffmpeg'):
        print('Precisa do ffmpeg para gerar o OGG.')
        return 1
    audio = render()
    # Estéreo leve: o canal direito um pouquinho atrasado (abre o som).
    shift = int(RATE * 0.008)
    right = np.roll(audio, shift)
    stereo = np.stack([audio, right], axis=1)
    pcm = (stereo * 32767).astype('<i2')
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        wav = pathlib.Path(tmp) / 'festa.wav'
        with wave.open(str(wav), 'wb') as w:
            w.setnchannels(2)
            w.setsampwidth(2)
            w.setframerate(RATE)
            w.writeframes(pcm.tobytes())
        subprocess.run(['ffmpeg', '-y', '-v', 'error', '-i', str(wav), '-c:a', 'libvorbis',
                        '-q:a', '4', str(OUT)], check=True)
    print(f'ok {OUT} ({len(audio) / RATE:.1f} s)')
    return 0


if __name__ == '__main__':
    sys.exit(main())
