# Mundo Divertido — Aprenda brincando!

Aplicativo infantil bilíngue (português do Brasil e inglês) com animais da fazenda,
animais do safári, frutas e cores. Funciona offline, sem anúncios, sem login, sem
rastreadores e sem permissões extras.

## Novidades da versão 0.4.0 (partes do corpo e sons reais de animais)

- **Partes do Corpo / Body** (novo cartão na tela inicial): uma criança desenhada
  (respira e pisca). Ao tocar numa parte, ela brilha e o nome é dito em
  português e depois em inglês. São 14 partes: cabeça, cabelo, olhos, orelhas,
  nariz, boca, pescoço, ombros, braços, mãos, barriga, pernas, joelhos e pés.
  - Fileira com os nomes embaixo (tocar também acende a parte).
  - **Mostrar tudo / Show all**: passa por todas as partes, acendendo cada uma
    enquanto fala.
  - **Onde está? / Where is it?** (também em Brincadeiras): "Onde está o nariz?
    Where is the nose?", e a criança toca na parte certa. São 6 rodadas, com
    estrelas e confete. Depois de dois erros, a parte certa brilha de leve.
  - Os dados ficam em `assets/data/body.json` (`askPt`/`askEn` = pergunta do
    jogo; `tools/generate_voices.py` gera `ask_<id>.mp3`). O desenho e as
    áreas de toque ficam em `lib/widgets/body_figure.dart`.
- **Sons de animais trocados por gravações reais.** Os sons antigos eram
  gerados por IA: vários tinham exatamente 3,03 s, o do pato era quase só
  silêncio e o da galinha parecia cliques. Agora são gravações reais com
  licença livre, recortadas e com volume nivelado:
  - BigSoundBank.com (Joseph Sardin, licença CC0): vaca, cavalo, galinha,
    galo, ovelha, cabra, burro, gato, cachorro, sapo, coruja e coelho
    (cenoura sendo mastigada, o "nhac nhac").
  - Wikimedia Commons: elefante (CC0) e chimpanzé (CC BY 4.0).
  - Créditos em `lib/data/sound_credits.dart` e na área dos responsáveis
    ("Créditos dos sons dos animais"). Um teste confere que todo arquivo de
    `animal_sounds/` tem crédito.
  - Porco, pato, leão, papagaio, crocodilo e hipopótamo continuam com os sons
    que já estavam no app, porque não achei gravação livre melhor. Eles só
    tiveram o silêncio cortado (o do pato tinha 2,6 s de silêncio) e o volume
    nivelado. Girafa, zebra, rinoceronte, guepardo e avestruz nunca tiveram
    arquivo e usam a onomatopeia falada pela voz.
  - Para trocar um som, basta colocar `assets/audio/animal_sounds/<id>.mp3`
    e o crédito em `sound_credits.dart`.

## Novidades da versão 0.3.0 (cores, pintar, música e visual)

- **Cores renovadas**: cada cor é uma gotinha de tinta com carinha que pisca e
  "fala" (a boca mexe) enquanto diz o nome em **português e logo depois em
  inglês**. Ao abrir e ao trocar de cor ela se apresenta sozinha (mesma opção dos
  responsáveis das letras: "Falar o nome ao abrir"). Cada cor tem 3 coisas
  daquela cor com emoji (🍎 Maçã/Apple, 🐳 Baleia/Whale...), e foi incluída a cor
  **Cinza / Gray** (11 cores).
- **Pintar / Paint** (novo, em Cores e em Brincadeiras): escolha um potinho de
  tinta (ele fala a cor nos dois idiomas) e toque no desenho para pintar; a tinta
  se espalha a partir do dedo. 6 desenhos (casinha, flor, peixinho, arco-íris,
  borboleta, carrinho), botão de apagar e confete quando termina.
  Desenhos em `lib/data/paint_pictures.dart`.
- **Menos espera entre as palavras**: as vozes geradas vinham com ~0,2 s de
  silêncio no começo e ~1 s no fim. `tools/generate_voices.py` agora corta o
  silêncio dos dois lados (ffmpeg) e a pausa entre português e inglês caiu de
  450 ms para 150 ms. Entre "Vermelho" e "Red" eram quase 2 s; agora é um
  respiro curto.
- **Música contínua na Festa dos Bichos**: `assets/audio/music/festa.ogg`
  (~1min40s em loop sem emenda), arranjo próprio de cantigas infantis em
  **domínio público** (Brilha brilha estrelinha, Frère Jacques, Mary had a little
  lamb, Old MacDonald) com xilofone, baixo, ukulele e percussão, gerado por
  `tools/generate_music.py` (sem gravações de terceiros, sem problema de licença).
  Os bichos dançam no ritmo da música (116 batidas por minuto).
- **Visual e movimentos**: fonte arredondada Nunito (licença OFL,
  `assets/fonts/OFL.txt`), título colorido, cartões com degradê e borda branca,
  botões que afundam e voltam com um quique ao tocar (`lib/widgets/bouncy.dart`),
  figuras dos cartões flutuando de leve.
- **Correções**: os 2 avisos do `flutter analyze` e os 2 testes que falhavam
  (o build ficava vermelho) foram corrigidos; novos testes de cores, pintura e
  áudio (84 testes). O aviso "Falta a voz do aparelho" aparece no máximo a cada
  2 minutos.

## Novidades da versão 0.2.0

- **Letras só em maiúsculas** (A a Z) em todas as telas e jogos, nunca "Aa".
- **Letras bilíngues**: cada letra mostra e fala o nome em português (PT-BR) e em
  inglês (EN-US), um idioma de cada vez. Botões *Português*, *English* e
  *Palavras*; ao abrir a letra ela se apresenta sozinha (pode ser desligado em
  Ajustes dos responsáveis > "Falar a letra ao abrir").
  O que aparece na tela é `namePt`/`nameEn` e o que vai para a voz é
  `speakPt`/`speakEn`, todos em `assets/data/letters.json`.
- **Transições** padronizadas (`lib/widgets/app_route.dart`): fade + escala + deslize.
- **Jogos**: som de acerto, estrelinhas, som suave ao errar (nunca punitivo) e, depois
  de dois erros, a resposta certa pulsa e a pergunta é repetida.
- **Áudio**: efeitos em `assets/audio/sfx/` (gerados por `tools/generate_sfx.py`),
  arquivo ausente ou corrompido cai na voz do aparelho, erros ficam em `AudioService.errors`.
- **GitHub Actions**: veja `build.yml` (analyze/test não são mais ignorados; o APK
  sai em `mundo_divertido-apk/app-release.apk`).

## Status (Etapas 1 a 4 de 4)

| Item | Situação |
|---|---|
| Arquitetura, tema, dados JSON dos 40 itens | Pronto |
| Tela inicial, listas, detalhe de animais/frutas, módulo de cores | Pronto |
| 30 ilustrações SVG originais + 3 cenários | Pronto (`docs/ilustracoes.png`) |
| Animações: respiração, piscar, entrada, reação ao toque | Pronto (desenho em cache, só os olhos redesenham) |
| Áudio por voz do sistema (português e inglês), **sem arquivos** | Pronto |
| Sons de animais como onomatopeia falada ("Muuu!") | Pronto |
| 6 brincadeiras (Cadê?, Memória, Qual é a cor?, Quem faz esse som?, Descubra a letra, Descubra o número) | Pronto |
| Ajustes dos responsáveis (volume, silenciar sons de animais) | Pronto (toque longo na engrenagem) |

As ilustrações são geradas por `tools/generate_art.py` (arte original, sem terceiros).
Os olhos são desenhados pelo Flutter sobre o SVG para poderem piscar. Para ajustar um
desenho, edite o script e rode `python3 tools/generate_art.py`.

## Como executar

1. Instale o Flutter 3.22 ou mais novo.
2. Dentro desta pasta, gere a parte Android uma única vez:
   `flutter create --platforms=android --org br.com.mundodivertido .`
   (não sobrescreve `lib/`, `pubspec.yaml` nem `test/`; se pedir, mantenha os seus)
3. Prepare o Android para a voz do sistema: `python3 tools/patch_android.py`
   (acrescenta `<queries>` ao `AndroidManifest.xml`; sem isso o Android 11+ não
   deixa o app achar o motor de voz)
4. `flutter pub get`
5. `flutter analyze` e `flutter test`
6. `flutter run` (celular Android ou emulador)
7. APK: `flutter build apk --debug` ou `flutter build apk --release`
   (saída em `build/app/outputs/flutter-apk/`)

Sem internet em release: o app não precisa de permissão de internet.

## Áudio sem baixar nem gravar nada

O app **fala** os nomes usando a voz de texto-para-fala do próprio Android
(`flutter_tts`): português do Brasil (`pt-BR`) e inglês (`en-US`). Funciona offline
se as vozes estiverem instaladas, o que é o normal em celulares com Google TTS.

- Botão **Falar**: nome em português e depois em inglês.
- Botão **Som** (animais): onomatopeia falada com tom e velocidade próprios
  (vaca grave e lenta, pintinho agudo e rápido). Os textos ficam em `"sound"` nos
  JSONs e são gerados por `tools/add_sounds.py`; edite a tabela do script para trocar.
- Se faltar uma voz, o app avisa o adulto: Ajustes do Android > Texto para voz >
  instalar português e inglês.

**Gravações são opcionais e têm prioridade.** Se um dia quiser vozes ou sons reais,
basta soltar o arquivo com o nome certo, sem mexer em código:

- `assets/audio/pt_br/<id>.mp3`: pronúncia em português
- `assets/audio/en_us/<id>.mp3`: pronúncia em inglês
- `assets/audio/animal_sounds/<id>.mp3`: som do animal

Arquivo existe, toca o arquivo; não existe, o app fala. Dá para misturar.

## Brincadeiras

Menu na faixa "Brincadeiras" da tela inicial. Cada partida tem 6 rodadas (a memória
começa com 3 pares e sobe até 6 a cada vitória). Errar nunca pune: a opção balança e
fica mais clara. Acertar fala o nome em português e inglês.

| Brincadeira | Como funciona |
|---|---|
| Cadê? | Ouve o nome e toca na figura certa entre 3 (animais ou frutas) |
| Memória | Vira cartas e acha os pares; cada carta fala seu nome |
| Qual é a cor? | Ouve o nome da cor e toca na bolinha certa |
| Quem sou eu? | Vê uma sombra, escolhe quem é; a sombra se revela ao acertar |

As regras ficam em `lib/games/game_logic.dart` (puras, testadas); as telas em
`lib/games/`.

## Estrutura

```
lib/
  main.dart, app.dart          inicialização, providers, parar áudio ao sair do app
  models/learning_item.dart    LearningItem, Category, ColorExample
  data/content_repository.dart carrega assets/data/*.json
  services/audio_service.dart  fila de áudio única + AudioBackend (testável)
  services/settings_service.dart volume e silenciar efeitos (shared_preferences)
  screens/                     home, category, item_detail, color_detail
  games/                       menu, escolha (Cadê?/Cores/Sombra), memória, regras
  widgets/                     cartões, controles de áudio, personagem animado
assets/data/                   farm, safari, fruits, colors (.json)
assets/audio/                  (opcional) gravações que substituem a voz
test/                          dados, áudio, regras dos jogos, navegação
tools/                         generate_art.py, add_sounds.py, patch_android.py
```

Para adicionar um item, edite o JSON da categoria. Para adicionar uma categoria,
crie um JSON novo e inclua o nome em `ContentRepository.files`.

## Limitações atuais

- Código **nunca foi compilado nem executado** onde foi escrito (sem Flutter SDK).
  Rode `flutter analyze` e `flutter test` primeiro e envie qualquer erro.
- A qualidade da voz depende do aparelho. Os sons de animais são onomatopeias
  faladas, não gravações reais.
- A tela de cores usa ícones do Material como objetos de exemplo.
- A pasta `android/` é gerada pelo passo 2.
- Fonte: padrão do sistema.

## Dependências

`provider`, `flutter_tts`, `audioplayers` (só para gravações opcionais), `shared_preferences`, `flutter_svg` (e `flutter_lints`, `flutter_test` em desenvolvimento).


## Sons, vozes e animações (atualização)

- **Sons de animais:** `assets/audio/animal_sounds/<id>.mp3` (15 de 20 incluídos;
  faltam giraffe, zebra, rhinoceros, cheetah, ostrich — usam a onomatopeia falada).
- **Pronúncia:** `python3 tools/generate_voices.py` gera `pt_br/<id>.mp3` e
  `en_us/<id>.mp3` (edge-tts, com gTTS de reserva). O workflow `build.yml` roda isso
  antes de montar o APK. Há uma pausa curta (`clipGap`) entre português e inglês.
- **Movimento:** cada bicho tem seu jeito (`lib/widgets/motion_profile.dart`): coelho e
  macaco pulam, elefante balança, cavalo trota, pato rebola, leão caminha devagar.
  Ao falar ou fazer o som, o personagem se anima mais. Listas entram em sequência
  (`PopIn`) e as brincadeiras terminam com confete.

## Corpo inteiro, festa e novos jogos

- **Bichos de corpo inteiro** (`tools/generate_rigs.py`): 25 animais em camadas SVG
  (cauda, pernas, corpo, braços, cabeça). Cada parte se mexe separada
  (`lib/widgets/rig_animal.dart`). Novos: gato, cachorro, sapo, papagaio, coruja.
- **Festa dos Bichos**: fazenda e safári juntos, dançando; tocar faz o som.
- **Quem faz esse som?** sorteia um som entre os que existem e a criança escolhe o animal.
- **Cores:** tocar no objeto fala o nome dele (arquivos `obj_<id>.mp3`).
- **Arrastar** para o lado troca de figura, além das setas.
- **Pronúncia:** `tools/pronuncia.json` corrige palavras; chave `GOOGLE_TTS_KEY`
  (secret do GitHub) usa vozes Neural2 do Google, bem melhores.

### Bichos de corpo inteiro (em pé)
`tools/generate_rigs.py` monta cada animal em camadas (cauda, pernas, corpo, braços/asas, cabeça) e `lib/widgets/rig_animal.dart`
anima cada parte. As tentativas de bichos de lado e de frente (quatro patas) ficaram em `tools/old/`, sem uso.

### Tempo de uso e hora de dormir
Área dos responsáveis (toque longo na engrenagem): tempo por dia, o que fazer ao acabar (tela de dormir ou fechar o app),
+10 minutos, reiniciar o dia e um teste do céu. O céu (sol, pôr do sol, lua e estrelas) muda conforme o tempo
(`lib/widgets/sky_backdrop.dart`); ao fim o gato ou o cachorro dorme e deseja boa noite (`lib/widgets/bedtime_overlay.dart`).
