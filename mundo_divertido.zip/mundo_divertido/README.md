# Mundo Divertido — Aprenda brincando!

Aplicativo infantil bilíngue (português do Brasil e inglês) com animais da fazenda,
animais do safári, frutas e cores. Funciona offline, sem anúncios, sem login, sem
rastreadores e sem permissões extras.

## Status (Etapas 1 a 4 de 4)

| Item | Situação |
|---|---|
| Arquitetura, tema, dados JSON dos 40 itens | Pronto |
| Tela inicial, listas, detalhe de animais/frutas, módulo de cores | Pronto |
| 30 ilustrações SVG originais + 3 cenários | Pronto (`docs/ilustracoes.png`) |
| Animações: respiração, piscar, entrada, reação ao toque | Pronto (desenho em cache, só os olhos redesenham) |
| Áudio por voz do sistema (português e inglês), **sem arquivos** | Pronto |
| Sons de animais como onomatopeia falada ("Muuu!") | Pronto |
| 4 brincadeiras (Cadê?, Memória, Qual é a cor?, Quem sou eu?) | Pronto |
| Ajustes dos responsáveis (volume, silenciar sons de animais) | Pronto (toque longo na engrenagem) |

As ilustrações são geradas por `tools/generate_art.py` (arte original, sem terceiros).
Os olhos são desenhados pelo Flutter sobre o SVG para poderem piscar. Para ajustar um
desenho, edite o script e rode `python3 tools/generate_art.py`.

## Como executar

1. Instale o Flutter 3.22 ou mais novo.
2. Dentro desta pasta, gere a parte Android uma única vez:
   `flutter create --platforms=android --org br.com.mundodivertido .`
   (não sobrescreve `lib/`, `pubspec.yaml` nem `test/`; se pedir, mantenha os seus)
3. Prepare o Android para a voz do sistema: `python3 tools/patch_android.py`
   (acrescenta `<queries>` ao `AndroidManifest.xml`; sem isso o Android 11+ não
   deixa o app achar o motor de voz)
4. `flutter pub get`
5. `flutter analyze` e `flutter test`
6. `flutter run` (celular Android ou emulador)
7. APK: `flutter build apk --debug` ou `flutter build apk --release`
   (saída em `build/app/outputs/flutter-apk/`)

Sem internet em release: o app não precisa de permissão de internet.

## Áudio sem baixar nem gravar nada

O app **fala** os nomes usando a voz de texto-para-fala do próprio Android
(`flutter_tts`): português do Brasil (`pt-BR`) e inglês (`en-US`). Funciona offline
se as vozes estiverem instaladas, o que é o normal em celulares com Google TTS.

- Botão **Falar**: nome em português e depois em inglês.
- Botão **Som** (animais): onomatopeia falada com tom e velocidade próprios
  (vaca grave e lenta, pintinho agudo e rápido). Os textos ficam em `"sound"` nos
  JSONs e são gerados por `tools/add_sounds.py`; edite a tabela do script para trocar.
- Se faltar uma voz, o app avisa o adulto: Ajustes do Android > Texto para voz >
  instalar português e inglês.

**Gravações são opcionais e têm prioridade.** Se um dia quiser vozes ou sons reais,
basta soltar o arquivo com o nome certo, sem mexer em código:

- `assets/audio/pt_br/<id>.mp3`: pronúncia em português
- `assets/audio/en_us/<id>.mp3`: pronúncia em inglês
- `assets/audio/animal_sounds/<id>.mp3`: som do animal

Arquivo existe, toca o arquivo; não existe, o app fala. Dá para misturar.

## Brincadeiras

Menu na faixa "Brincadeiras" da tela inicial. Cada partida tem 6 rodadas (a memória
começa com 3 pares e sobe até 6 a cada vitória). Errar nunca pune: a opção balança e
fica mais clara. Acertar fala o nome em português e inglês.

| Brincadeira | Como funciona |
|---|---|
| Cadê? | Ouve o nome e toca na figura certa entre 3 (animais ou frutas) |
| Memória | Vira cartas e acha os pares; cada carta fala seu nome |
| Qual é a cor? | Ouve o nome da cor e toca na bolinha certa |
| Quem sou eu? | Vê uma sombra, escolhe quem é; a sombra se revela ao acertar |

As regras ficam em `lib/games/game_logic.dart` (puras, testadas); as telas em
`lib/games/`.

## Estrutura

```
lib/
  main.dart, app.dart          inicialização, providers, parar áudio ao sair do app
  models/learning_item.dart    LearningItem, Category, ColorExample
  data/content_repository.dart carrega assets/data/*.json
  services/audio_service.dart  fila de áudio única + AudioBackend (testável)
  services/settings_service.dart volume e silenciar efeitos (shared_preferences)
  screens/                     home, category, item_detail, color_detail
  games/                       menu, escolha (Cadê?/Cores/Sombra), memória, regras
  widgets/                     cartões, controles de áudio, personagem animado
assets/data/                   farm, safari, fruits, colors (.json)
assets/audio/                  (opcional) gravações que substituem a voz
test/                          dados, áudio, regras dos jogos, navegação
tools/                         generate_art.py, add_sounds.py, patch_android.py
```

Para adicionar um item, edite o JSON da categoria. Para adicionar uma categoria,
crie um JSON novo e inclua o nome em `ContentRepository.files`.

## Limitações atuais

- Código **nunca foi compilado nem executado** onde foi escrito (sem Flutter SDK).
  Rode `flutter analyze` e `flutter test` primeiro e envie qualquer erro.
- A qualidade da voz depende do aparelho. Os sons de animais são onomatopeias
  faladas, não gravações reais.
- A tela de cores usa ícones do Material como objetos de exemplo.
- A pasta `android/` é gerada pelo passo 2.
- Fonte: padrão do sistema.

## Dependências

`provider`, `flutter_tts`, `audioplayers` (só para gravações opcionais), `shared_preferences`, `flutter_svg` (e `flutter_lints`, `flutter_test` em desenvolvimento).


## Sons, vozes e animações (atualização)

- **Sons de animais:** `assets/audio/animal_sounds/<id>.mp3` (15 de 20 incluídos;
  faltam giraffe, zebra, rhinoceros, cheetah, ostrich — usam a onomatopeia falada).
- **Pronúncia:** `python3 tools/generate_voices.py` gera `pt_br/<id>.mp3` e
  `en_us/<id>.mp3` (edge-tts, com gTTS de reserva). O workflow `build.yml` roda isso
  antes de montar o APK. Há uma pausa curta (`clipGap`) entre português e inglês.
- **Movimento:** cada bicho tem seu jeito (`lib/widgets/motion_profile.dart`): coelho e
  macaco pulam, elefante balança, cavalo trota, pato rebola, leão caminha devagar.
  Ao falar ou fazer o som, o personagem se anima mais. Listas entram em sequência
  (`PopIn`) e as brincadeiras terminam com confete.
