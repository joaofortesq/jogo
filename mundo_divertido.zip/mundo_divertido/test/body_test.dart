import 'package:flutter/painting.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mundo_divertido/widgets/body_figure.dart';

void main() {
  test('toda parte do corpo pode ser tocada (não fica escondida por outra)',
      () {
    for (final id in BodyMap.hit.keys) {
      expect(BodyMap.partAt(BodyMap.tapPoint(id)), id, reason: id);
    }
  });

  test('pontos conhecidos caem na parte certa', () {
    expect(BodyMap.partAt(const Offset(100, 91)), 'nose');
    expect(BodyMap.partAt(const Offset(85, 78)), 'eyes');
    expect(BodyMap.partAt(const Offset(100, 60)), 'head');
    expect(BodyMap.partAt(const Offset(100, 30)), 'hair');
    expect(BodyMap.partAt(const Offset(100, 170)), 'belly');
    expect(BodyMap.partAt(const Offset(42, 202)), 'hands');
    expect(BodyMap.partAt(const Offset(85, 230)), 'legs');
    expect(BodyMap.partAt(const Offset(81, 283)), 'feet');
    expect(BodyMap.partAt(const Offset(5, 5)), isNull);
  });

  test('converte o toque da tela para o quadro e de volta', () {
    const size = Size(400, 450);
    const p = Offset(100, 91);
    final back = toBodyFrame(fromBodyFrame(p, size), size);
    expect((back - p).distance, lessThan(.001));
  });
}
