import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:mundo_divertido/data/sound_credits.dart';

void main() {
  test('todo som de animal tem crédito e todo crédito tem arquivo', () {
    final files = Directory('assets/audio/animal_sounds')
        .listSync()
        .whereType<File>()
        .map((f) => f.uri.pathSegments.last)
        .where((n) => n.endsWith('.mp3'))
        .map((n) => n.substring(0, n.length - 4))
        .toSet();
    final credited = soundCredits.map((c) => c.id).toSet();
    expect(credited.length, soundCredits.length, reason: 'crédito repetido');
    expect(files, credited);
    for (final c in soundCredits) {
      expect(c.license.trim(), isNotEmpty, reason: c.id);
      expect(c.author.trim(), isNotEmpty, reason: c.id);
    }
  });
}
