import 'package:flutter_test/flutter_test.dart';
import 'package:mundo_divertido/services/settings_service.dart';
import 'package:mundo_divertido/services/usage_service.dart';
import 'package:mundo_divertido/widgets/sky_backdrop.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<SettingsService> _settings([Map<String, Object> initial = const {}]) async {
  SharedPreferences.setMockInitialValues(initial);
  return SettingsService(await SharedPreferences.getInstance());
}

void main() {
  group('UsageService', () {
    test('sem limite nunca chega a hora de dormir', () async {
      final u = UsageService(settings: await _settings());
      for (var i = 0; i < 500; i++) {
        u.tickOnce();
      }
      expect(u.bedtime, isFalse);
      expect(u.progress, 0);
      u.dispose();
    });

    test('com limite o céu avança e, no fim, é hora de dormir', () async {
      final s = await _settings();
      await s.setLimitMinutes(1);
      final u = UsageService(settings: s);
      expect(u.progress, 0);
      for (var i = 0; i < 30; i++) {
        u.tickOnce();
      }
      expect(u.progress, closeTo(.5, .001));
      expect(u.bedtime, isFalse);
      for (var i = 0; i < 40; i++) {
        u.tickOnce();
      }
      expect(u.bedtime, isTrue);
      expect(u.progress, 1);
      expect(u.remainingSeconds, 0);
      u.dispose();
    });

    test('fechar e abrir de novo no mesmo dia não zera o tempo', () async {
      final s = await _settings();
      await s.setLimitMinutes(1);
      final day = DateTime(2026, 10, 13, 9);
      final a = UsageService(settings: s, now: () => day);
      for (var i = 0; i < 60; i++) {
        a.tickOnce();
      }
      expect(a.bedtime, isTrue);
      a.dispose();
      await Future<void>.delayed(Duration.zero);
      final b = UsageService(settings: s, now: () => day.add(const Duration(hours: 3)));
      expect(b.bedtime, isTrue);
      b.dispose();
    });

    test('no dia seguinte o tempo recomeça', () async {
      final s = await _settings();
      await s.setLimitMinutes(1);
      final a = UsageService(settings: s, now: () => DateTime(2026, 10, 13, 20));
      for (var i = 0; i < 60; i++) {
        a.tickOnce();
      }
      expect(a.bedtime, isTrue);
      a.dispose();
      await Future<void>.delayed(Duration.zero);
      final b = UsageService(settings: s, now: () => DateTime(2026, 10, 14, 7));
      expect(b.bedtime, isFalse);
      expect(b.usedSeconds, 0);
      b.dispose();
    });

    test('mais tempo e reiniciar tiram a hora de dormir', () async {
      final s = await _settings();
      await s.setLimitMinutes(1);
      final u = UsageService(settings: s);
      for (var i = 0; i < 60; i++) {
        u.tickOnce();
      }
      expect(u.bedtime, isTrue);
      u.addTime(const Duration(seconds: 30));
      expect(u.bedtime, isFalse);
      expect(u.usedSeconds, 30);
      for (var i = 0; i < 30; i++) {
        u.tickOnce();
      }
      expect(u.bedtime, isTrue);
      u.resetToday();
      expect(u.bedtime, isFalse);
      expect(u.usedSeconds, 0);
      u.dispose();
    });

    test('tirar o limite nos ajustes tira a hora de dormir', () async {
      final s = await _settings();
      await s.setLimitMinutes(1);
      final u = UsageService(settings: s);
      for (var i = 0; i < 60; i++) {
        u.tickOnce();
      }
      expect(u.bedtime, isTrue);
      await s.setLimitMinutes(0);
      expect(u.bedtime, isFalse);
      u.dispose();
    });

    test('o limite e o modo de fim ficam guardados', () async {
      final s = await _settings();
      await s.setLimitMinutes(20);
      await s.setEndMode(EndMode.closeApp);
      final again = SettingsService(await SharedPreferences.getInstance());
      expect(again.limitMinutes, 20);
      expect(again.endMode, EndMode.closeApp);
    });
  });

  group('SkyPalette', () {
    test('começa de dia com sol e termina de noite com lua', () {
      expect(SkyPalette.sun(0), isNotNull);
      expect(SkyPalette.moon(0), isNull);
      expect(SkyPalette.nightness(0), 0);
      expect(SkyPalette.sun(1), isNull);
      expect(SkyPalette.moon(1), isNotNull);
      expect(SkyPalette.nightness(1), closeTo(1, 1e-9));
    });

    test('anoitece sempre (nunca clareia) e o sol desce', () {
      var last = -1.0;
      var lastSunY = -1.0;
      for (var i = 0; i <= 100; i++) {
        final p = i / 100;
        final n = SkyPalette.nightness(p);
        expect(n, greaterThanOrEqualTo(last));
        last = n;
        final sun = SkyPalette.sun(p);
        if (sun != null) {
          expect(sun.dy, greaterThanOrEqualTo(lastSunY));
          lastSunY = sun.dy;
        }
      }
    });
  });
}
