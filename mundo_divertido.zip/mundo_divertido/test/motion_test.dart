import 'package:flutter_test/flutter_test.dart';
import 'package:mundo_divertido/widgets/motion_profile.dart';

void main() {
  test('cada animal tem um jeito de se mexer', () {
    expect(motionFor('rabbit'), MotionKind.hop);
    expect(motionFor('elephant'), MotionKind.sway);
    expect(motionFor('horse'), MotionKind.trot);
    expect(motionFor('duck'), MotionKind.waddle);
    expect(motionFor('lion'), MotionKind.prowl);
    expect(motionFor('apple'), MotionKind.bounce);
  });

  test('o ciclo recomeça sem emenda e nunca gera números inválidos', () {
    for (final kind in MotionKind.values) {
      final a = poseFor(kind, 0, 200);
      final b = poseFor(kind, 1, 200);
      expect((a.dx - b.dx).abs(), lessThan(1e-6), reason: '$kind dx');
      expect((a.dy - b.dy).abs(), lessThan(1e-6), reason: '$kind dy');
      expect((a.angle - b.angle).abs(), lessThan(1e-6), reason: '$kind ângulo');
      for (var i = 0; i <= 100; i++) {
        final p = poseFor(kind, i / 100, 200);
        for (final n in [p.dx, p.dy, p.angle, p.scaleX, p.scaleY]) {
          expect(n.isFinite, isTrue, reason: '$kind');
        }
        expect(p.scaleX, greaterThan(.8));
        expect(p.scaleY, greaterThan(.8));
      }
    }
  });
}
