import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mundo_divertido/games/game_widgets.dart';
import 'package:mundo_divertido/services/settings_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:mundo_divertido/widgets/app_route.dart';

void main() {
  testWidgets('AppRoute: a tela nova aparece e a antiga sai de cena ao terminar', (tester) async {
    late BuildContext ctx;
    await tester.pumpWidget(MaterialApp(
      home: Builder(builder: (c) {
        ctx = c;
        return const Scaffold(body: Text('antiga'));
      }),
    ));
    Navigator.of(ctx).push(AppRoute<void>(builder: (_) => const Scaffold(body: Text('nova'))));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 100));
    expect(find.text('nova'), findsOneWidget);
    await tester.pump(const Duration(seconds: 1));
    expect(find.text('antiga'), findsNothing); // offstage
    expect(find.text('nova'), findsOneWidget);

    Navigator.of(ctx).pop();
    await tester.pump();
    await tester.pump(const Duration(seconds: 1));
    expect(find.text('antiga'), findsOneWidget);
    expect(find.text('nova'), findsNothing);
  });

  testWidgets('StarBurst e HintPulse rodam sem erro e terminam', (tester) async {
    final active = ValueNotifier<bool>(false);
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: Center(
          child: SizedBox(
            width: 120,
            height: 120,
            child: Stack(children: [
              ValueListenableBuilder<bool>(
                valueListenable: active,
                builder: (_, a, __) => HintPulse(active: a, child: const SizedBox.expand()),
              ),
              const Positioned.fill(child: StarBurst()),
            ]),
          ),
        ),
      ),
    ));
    active.value = true;
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 400));
    expect(tester.takeException(), isNull);
    await tester.pumpAndSettle(); // as duas animações são finitas
    expect(tester.takeException(), isNull);
  });

  test('ajustes: fala da letra ao abrir começa ligada e é guardada', () async {
    SharedPreferences.setMockInitialValues({});
    final prefs = await SharedPreferences.getInstance();
    final s = SettingsService(prefs);
    expect(s.autoSpeakLetters, isTrue);
    await s.setAutoSpeakLetters(false);
    expect(SettingsService(prefs).autoSpeakLetters, isFalse);
  });
}
