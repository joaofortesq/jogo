import 'dart:math';

import 'package:flutter/painting.dart' show Color;
import 'package:flutter_test/flutter_test.dart';
import 'package:mundo_divertido/games/game_logic.dart';
import 'package:mundo_divertido/models/learning_item.dart';

List<LearningItem> _pool(int n) => [
      for (var i = 0; i < n; i++)
        LearningItem(id: 'item$i', pt: 'Item $i', en: 'Item $i', color: const Color(0xFF000000)),
    ];

void main() {
  group('buildChoiceRounds', () {
    test('gera rodadas com 3 opções distintas contendo o alvo', () {
      final rounds = buildChoiceRounds(_pool(10), random: Random(1));
      expect(rounds.length, 6);
      for (final r in rounds) {
        expect(r.options.length, 3);
        expect(r.options.map((o) => o.id).toSet().length, 3);
        expect(r.options.any((o) => o.id == r.target.id), isTrue);
      }
    });

    test('alvos não se repetem quando o grupo é grande o bastante', () {
      for (var seed = 0; seed < 20; seed++) {
        final rounds = buildChoiceRounds(_pool(10), random: Random(seed));
        expect(rounds.map((r) => r.target.id).toSet().length, 6, reason: 'seed $seed');
      }
    });

    test('targetPool limita os alvos, mas as opções vêm do grupo todo', () {
      final pool = _pool(10);
      final onlyThese = pool.take(4).toList();
      for (var seed = 0; seed < 10; seed++) {
        final rounds = buildChoiceRounds(pool, targetPool: onlyThese, random: Random(seed));
        for (final r in rounds) {
          expect(onlyThese.any((t) => t.id == r.target.id), isTrue, reason: 'seed $seed');
          expect(r.options.length, 3);
          expect(r.options.any((o) => o.id == r.target.id), isTrue);
        }
      }
    });

    test('grupo pequeno reaproveita alvos sem falhar', () {
      final rounds = buildChoiceRounds(_pool(3), rounds: 6, random: Random(2));
      expect(rounds.length, 6);
      expect(rounds.every((r) => r.options.length == 3), isTrue);
    });
  });

  group('MemoryGame', () {
    late MemoryGame game;
    setUp(() => game = MemoryGame(_pool(10), pairs: 4, random: Random(3)));

    List<int> indexesOf(String id) => [
          for (var i = 0; i < game.cards.length; i++)
            if (game.cards[i].item.id == id) i,
        ];

    test('distribui 4 pares (8 cartas), cada item exatamente duas vezes', () {
      expect(game.cards.length, 8);
      final counts = <String, int>{};
      for (final c in game.cards) {
        counts[c.item.id] = (counts[c.item.id] ?? 0) + 1;
      }
      expect(counts.length, 4);
      expect(counts.values.every((v) => v == 2), isTrue);
    });

    test('virar um par igual marca as duas cartas', () {
      final id = game.cards.first.item.id;
      final pair = indexesOf(id);
      expect(game.flip(pair[0]), FlipResult.first);
      expect(game.flip(pair[1]), FlipResult.match);
      expect(game.cards[pair[0]].matched, isTrue);
      expect(game.cards[pair[1]].matched, isTrue);
      expect(game.moves, 1);
      expect(game.locked, isFalse);
    });

    test('par diferente trava o jogo até resolveMismatch', () {
      final a = 0;
      final b = game.cards.indexWhere((c) => c.item.id != game.cards[a].item.id);
      expect(game.flip(a), FlipResult.first);
      expect(game.flip(b), FlipResult.mismatch);
      expect(game.locked, isTrue);
      final other = [for (var i = 0; i < 8; i++) if (i != a && i != b) i].first;
      expect(game.flip(other), FlipResult.ignored);
      game.resolveMismatch();
      expect(game.locked, isFalse);
      expect(game.cards[a].faceUp, isFalse);
      expect(game.cards[b].faceUp, isFalse);
      expect(game.flip(other), FlipResult.first);
    });

    test('tocar na mesma carta duas vezes é ignorado', () {
      expect(game.flip(0), FlipResult.first);
      expect(game.flip(0), FlipResult.ignored);
    });

    test('achar todos os pares vence', () {
      expect(game.won, isFalse);
      final ids = game.cards.map((c) => c.item.id).toSet();
      for (final id in ids) {
        final p = indexesOf(id);
        game.flip(p[0]);
        game.flip(p[1]);
      }
      expect(game.won, isTrue);
      expect(game.moves, 4);
    });
  });
}
