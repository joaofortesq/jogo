import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:mundo_divertido/data/content_repository.dart';
import 'package:mundo_divertido/models/learning_item.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late ContentRepository repo;
  setUpAll(() async => repo = await ContentRepository.load());

  test('carrega 4 categorias com a quantidade esperada de itens', () {
    expect(repo.categories.map((c) => c.id), ['farm', 'safari', 'fruits', 'colors']);
    const expected = {'farm': 12, 'safari': 13, 'fruits': 10, 'colors': 10};
    for (final c in repo.categories) {
      expect(c.items.length, expected[c.id], reason: c.id);
    }
  });

  test('gato e cachorro na fazenda; sapo, papagaio e coruja no safári', () {
    final farm = repo.byId('farm').items.map((i) => i.id);
    final safari = repo.byId('safari').items.map((i) => i.id);
    expect(farm, containsAll(['cat', 'dog']));
    expect(safari, containsAll(['frog', 'parrot', 'owl']));
  });

  test('animais têm corpo inteiro em camadas que existem', () {
    for (final id in ['farm', 'safari']) {
      for (final i in repo.byId(id).items) {
        final rig = i.rig;
        expect(rig, isNotNull, reason: i.id);
        expect(rig!.eyes.length, 2, reason: i.id);
        final roles = rig.layers.map((l) => l.role).toSet();
        for (final r in ['legL', 'legR', 'body', 'armL', 'armR', 'head']) {
          expect(roles.contains(r), isTrue, reason: '${i.id} sem $r');
        }
        for (final l in rig.layers) {
          expect(File(l.asset).existsSync(), isTrue, reason: l.asset);
          expect(l.pivot.dx, inInclusiveRange(0, 200), reason: l.asset);
          expect(l.pivot.dy, inInclusiveRange(0, 200), reason: l.asset);
        }
      }
    }
    expect(repo.byId('fruits').items.any((i) => i.rig != null), isFalse);
  });

  test('cada objeto de cor tem id único para o arquivo de áudio', () {
    final ids = [
      for (final i in repo.byId('colors').items)
        for (final e in i.examples) e.id,
    ];
    expect(ids.toSet().length, ids.length);
  });

  test('ids são únicos e nomes pt/en existem', () {
    for (final c in repo.categories) {
      final ids = c.items.map((i) => i.id).toSet();
      expect(ids.length, c.items.length, reason: c.id);
      for (final i in c.items) {
        expect(i.pt.trim(), isNotEmpty);
        expect(i.en.trim(), isNotEmpty);
      }
    }
  });

  test('animais têm som; frutas e cores não', () {
    for (final id in ['farm', 'safari']) {
      expect(repo.byId(id).items.every((i) => i.hasAnimalSound), isTrue);
    }
    expect(repo.byId('fruits').items.any((i) => i.hasAnimalSound), isFalse);
    expect(repo.byId('colors').items.any((i) => i.hasAnimalSound), isFalse);
  });

  test('caminhos de áudio seguem a convenção', () {
    final cow = repo.byId('farm').items.first;
    expect(cow.id, 'cow');
    expect(cow.ptAudioPath, 'assets/audio/pt_br/cow.mp3');
    expect(cow.enAudioPath, 'assets/audio/en_us/cow.mp3');
    expect(cow.soundAudioPath, 'assets/audio/animal_sounds/cow.mp3');
  });

  test('todo animal tem onomatopeia falada com tom e velocidade válidos', () {
    for (final id in ['farm', 'safari']) {
      for (final i in repo.byId(id).items) {
        final s = i.sound;
        expect(s, isNotNull, reason: i.id);
        expect(s!.text.trim(), isNotEmpty, reason: i.id);
        expect(s.pitch, inInclusiveRange(0.5, 2.0), reason: i.id);
        expect(s.rate, inInclusiveRange(0.1, 1.0), reason: i.id);
      }
    }
    expect(repo.byId('fruits').items.any((i) => i.sound != null), isFalse);
  });

  test('cores têm exemplos e a categoria é do tipo colors', () {
    final colors = repo.byId('colors');
    expect(colors.kind, CategoryKind.colors);
    expect(colors.items.every((i) => i.examples.isNotEmpty), isTrue);
  });

  test('colorFromHex converte corretamente', () {
    expect(colorFromHex('#FF0000').value, 0xFFFF0000);
  });

  test('animais e frutas têm arte SVG existente com dois olhos', () {
    for (final id in ['farm', 'safari', 'fruits']) {
      for (final i in repo.byId(id).items) {
        expect(i.art, isNotNull, reason: i.id);
        expect(File(i.art!.asset).existsSync(), isTrue, reason: i.art!.asset);
        expect(i.art!.eyes.length, 2, reason: i.id);
      }
    }
  });

  test('cenários existem e cores não têm cenário', () {
    for (final id in ['farm', 'safari', 'fruits']) {
      expect(File(repo.byId(id).scene!).existsSync(), isTrue, reason: id);
    }
    expect(repo.byId('colors').scene, isNull);
  });
}
