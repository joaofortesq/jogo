import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mundo_divertido/app.dart';
import 'package:mundo_divertido/data/content_repository.dart';
import 'package:mundo_divertido/services/audio_service.dart';
import 'package:mundo_divertido/services/settings_service.dart';
import 'package:mundo_divertido/widgets/art_config.dart';
import 'package:shared_preferences/shared_preferences.dart';

class _SilentBackend implements AudioBackend {
  _SilentBackend({this.voice = true});

  final bool voice;

  @override
  Future<void> playAsset(String assetPath, double volume) async {}
  @override
  Future<bool> speak(
    String text, {
    required String lang,
    required double volume,
    required double pitch,
    required double rate,
  }) async =>
      voice;
  @override
  Future<void> stop() async {}
  @override
  Future<void> dispose() async {}
}

Future<void> _pumpApp(WidgetTester tester, {bool voice = true}) async {
  SharedPreferences.setMockInitialValues({});
  // E/S real (assets, prefs) precisa de runAsync: o relógio do teste é falso.
  final loaded = await tester.runAsync(() async => (
        await SharedPreferences.getInstance(),
        await ContentRepository.load(),
      ));
  final settings = SettingsService(loaded!.$1);
  final repo = loaded.$2;
  final audio = AudioService(
    settings: settings,
    backend: _SilentBackend(voice: voice),
    assetExists: (_) async => false,
    clipGap: Duration.zero,
  );
  tester.view.physicalSize = const Size(1080, 2340);
  tester.view.devicePixelRatio = 2.75;
  addTearDown(tester.view.reset);
  await tester.pumpWidget(MundoDivertidoApp(repository: repo, settings: settings, audio: audio));
  await tester.pump();
}

void main() {
  setUpAll(() => ArtConfig.renderSvg = false);
  tearDownAll(() => ArtConfig.renderSvg = true);

  testWidgets('tela inicial mostra título e as 4 categorias', (tester) async {
    await _pumpApp(tester);
    expect(find.text('Mundo Divertido'), findsOneWidget);
    expect(find.text('Aprenda brincando!'), findsOneWidget);
    for (final t in ['Animais da Fazenda', 'Animais do Safári', 'Frutas', 'Cores']) {
      expect(find.text(t), findsOneWidget);
    }
  });

  testWidgets('Frutas -> detalhe da maçã -> início', (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Frutas'));
    await tester.pumpAndSettle(const Duration(milliseconds: 100));
    expect(find.text('Maçã'), findsOneWidget);

    await tester.tap(find.text('Maçã'));
    await tester.pump(const Duration(milliseconds: 500));
    expect(find.text('MAÇÃ'), findsOneWidget);
    expect(find.text('APPLE'), findsOneWidget);
    expect(find.text('Falar'), findsOneWidget);
    expect(find.text('Som'), findsNothing); // frutas não têm som de animal

    await tester.tap(find.byIcon(Icons.home_rounded).first);
    await tester.pump(const Duration(milliseconds: 500));
    expect(find.text('Mundo Divertido'), findsOneWidget);
  });

  testWidgets('Fazenda -> Vaca mostra botão de som; voz ausente avisa o adulto', (tester) async {
    await _pumpApp(tester, voice: false);
    await tester.tap(find.text('Animais da Fazenda'));
    await tester.pumpAndSettle(const Duration(milliseconds: 100));
    await tester.tap(find.text('Vaca'));
    await tester.pump(const Duration(milliseconds: 500));
    expect(find.text('VACA'), findsOneWidget);
    expect(find.text('Som'), findsOneWidget);

    await tester.tap(find.text('Falar'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.textContaining('Falta a voz do aparelho'), findsOneWidget);
  });

  testWidgets('Com voz instalada, Falar não mostra aviso', (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Frutas'));
    await tester.pumpAndSettle(const Duration(milliseconds: 100));
    await tester.tap(find.text('Maçã'));
    await tester.pump(const Duration(milliseconds: 500));
    await tester.tap(find.text('Falar'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.textContaining('Falta a voz'), findsNothing);
  });

  testWidgets('Brincadeiras: menu mostra as 4 e cada uma abre', (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Brincadeiras'));
    await tester.pump(const Duration(milliseconds: 500));
    for (final t in ['Cadê?', 'Memória', 'Qual é a cor?', 'Quem sou eu?']) {
      expect(find.text(t), findsOneWidget, reason: t);
    }

    for (final t in ['Cadê?', 'Memória', 'Qual é a cor?', 'Quem sou eu?']) {
      await tester.tap(find.text(t));
      await tester.pump(const Duration(milliseconds: 600));
      // título da brincadeira na barra superior
      expect(find.text(t), findsOneWidget, reason: 'abriu $t');
      await tester.tap(find.byIcon(Icons.arrow_back_rounded).first);
      await tester.pump(const Duration(milliseconds: 600));
      expect(find.text('Brincadeiras'), findsWidgets);
    }
  });

  testWidgets('Cadê?: completar as 6 rodadas mostra os parabéns', (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Brincadeiras'));
    await tester.pump(const Duration(milliseconds: 500));
    await tester.tap(find.text('Cadê?'));
    await tester.pump(const Duration(milliseconds: 600));

    final options = find.byWidgetPredicate((w) =>
        w.key is ValueKey<String> && (w.key! as ValueKey<String>).value.startsWith('option-'));
    for (var round = 0; round < 6; round++) {
      expect(options, findsNWidgets(3), reason: 'rodada $round');
      // Toca em todas: as erradas só balançam; a certa avança a rodada.
      for (var i = 0; i < 3; i++) {
        await tester.tap(options.at(i), warnIfMissed: false);
        await tester.pump(const Duration(milliseconds: 50));
      }
      await tester.pump(const Duration(milliseconds: 1000));
    }
    expect(find.text('Parabéns!'), findsOneWidget);
    expect(find.text('Jogar de novo'), findsOneWidget);

    await tester.tap(find.text('Jogar de novo'));
    await tester.pump(const Duration(milliseconds: 600));
    expect(find.text('Parabéns!'), findsNothing);
    expect(options, findsNWidgets(3));
  });

  testWidgets('Memória: toca numa carta sem erro e mostra o nome', (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Brincadeiras'));
    await tester.pump(const Duration(milliseconds: 500));
    await tester.tap(find.text('Memória'));
    await tester.pump(const Duration(milliseconds: 600));
    await tester.tap(find.byKey(const ValueKey('card-0')));
    await tester.pump(const Duration(milliseconds: 500));
    expect(tester.takeException(), isNull);
  });

  testWidgets('Cores abre tela com nome nos dois idiomas', (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Cores'));
    await tester.pumpAndSettle(const Duration(milliseconds: 100));
    await tester.tap(find.text('VERMELHO'));
    await tester.pump(const Duration(milliseconds: 500));
    expect(find.text('VERMELHO'), findsOneWidget);
    expect(find.text('RED'), findsOneWidget);
    expect(find.text('Coração'), findsOneWidget);
  });
}
