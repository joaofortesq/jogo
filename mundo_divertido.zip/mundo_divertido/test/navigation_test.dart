import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mundo_divertido/app.dart';
import 'package:mundo_divertido/data/content_repository.dart';
import 'package:mundo_divertido/services/audio_service.dart';
import 'package:mundo_divertido/services/settings_service.dart';
import 'package:mundo_divertido/widgets/art_config.dart';
import 'package:mundo_divertido/widgets/body_figure.dart';
import 'package:shared_preferences/shared_preferences.dart';

class _SilentBackend implements AudioBackend {
  _SilentBackend({this.voice = true});

  final bool voice;

  @override
  Future<void> playAsset(String assetPath, double volume) async {}
  @override
  Future<bool> speak(
    String text, {
    required String lang,
    required double volume,
    required double pitch,
    required double rate,
  }) async =>
      voice;
  @override
  Future<void> stop() async {}
  @override
  Future<void> dispose() async {}
}

Future<void> _pumpApp(WidgetTester tester, {bool voice = true}) async {
  SharedPreferences.setMockInitialValues({});
  // E/S real (assets, prefs) precisa de runAsync: o relógio do teste é falso.
  final loaded = await tester.runAsync(() async => (
        await SharedPreferences.getInstance(),
        await ContentRepository.load(),
      ));
  final settings = SettingsService(loaded!.$1);
  final repo = loaded.$2;
  final audio = AudioService(
    settings: settings,
    backend: _SilentBackend(voice: voice),
    assetExists: (_) async => false,
    clipGap: Duration.zero,
  );
  tester.view.physicalSize = const Size(1080, 2340);
  tester.view.devicePixelRatio = 2.75;
  addTearDown(tester.view.reset);
  await tester.pumpWidget(
      MundoDivertidoApp(repository: repo, settings: settings, audio: audio));
  await tester.pump();
}

/// Deixa a transição de tela terminar (um quadro para começar e 1 s para andar).
/// Não usa pumpAndSettle: personagens têm animação contínua.
Future<void> _go(WidgetTester tester) async {
  await tester.pump();
  await tester.pump(const Duration(seconds: 1));
}

void main() {
  setUpAll(() {
    ArtConfig.renderSvg = false;
    ArtConfig.animateSky = false;
  });
  tearDownAll(() {
    ArtConfig.renderSvg = true;
    ArtConfig.animateSky = true;
  });

  testWidgets('tela inicial mostra título e as 7 categorias', (tester) async {
    await _pumpApp(tester);
    expect(find.text('Mundo Divertido'), findsOneWidget);
    expect(find.text('Aprenda brincando!'), findsOneWidget);
    for (final t in [
      'Animais da Fazenda',
      'Animais do Safári',
      'Frutas',
      'Cores',
      'Letras',
      'Números',
      'Corpo',
    ]) {
      expect(find.text(t), findsOneWidget);
    }
  });

  testWidgets('Frutas -> detalhe da maçã -> início', (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Frutas'));
    await _go(tester);
    expect(find.text('Maçã'), findsOneWidget);

    await tester.tap(find.text('Maçã'));
    await _go(tester);
    expect(find.text('MAÇÃ'), findsOneWidget);
    expect(find.text('APPLE'), findsOneWidget);
    expect(find.text('Falar'), findsOneWidget);
    expect(find.text('Som'), findsNothing); // frutas não têm som de animal

    await tester.tap(find.byIcon(Icons.home_rounded).first);
    await _go(tester);
    expect(find.text('Mundo Divertido'), findsOneWidget);
  });

  testWidgets('Fazenda -> Vaca mostra botão de som; voz ausente avisa o adulto',
      (tester) async {
    await _pumpApp(tester, voice: false);
    await tester.tap(find.text('Animais da Fazenda'));
    await _go(tester);
    await tester.tap(find.text('Vaca'));
    await _go(tester);
    expect(find.text('VACA'), findsOneWidget);
    expect(find.text('Som'), findsOneWidget);

    await tester.tap(find.text('Falar'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.textContaining('Falta a voz do aparelho'), findsOneWidget);
  });

  testWidgets('Com voz instalada, Falar não mostra aviso', (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Frutas'));
    await _go(tester);
    await tester.tap(find.text('Maçã'));
    await _go(tester);
    await tester.tap(find.text('Falar'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.textContaining('Falta a voz'), findsNothing);
  });

  testWidgets('Brincadeiras: menu mostra as 8 e cada uma abre', (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Brincadeiras'));
    await _go(tester);
    const games = [
      'Cadê?',
      'Memória',
      'Qual é a cor?',
      'Pintar',
      'Onde está?',
      'Quem faz esse som?',
      'Descubra a letra',
      'Descubra o número',
    ];
    for (final t in games) {
      expect(find.text(t), findsOneWidget, reason: t);
    }

    for (final t in games) {
      await tester.tap(find.text(t));
      await _go(tester);
      // título da brincadeira na barra superior
      expect(find.text(t), findsOneWidget, reason: 'abriu $t');
      await tester.tap(find.byIcon(Icons.arrow_back_rounded).first);
      await _go(tester);
      expect(find.text('Brincadeiras'), findsWidgets);
    }
  });

  testWidgets('Cadê?: completar as 6 rodadas mostra os parabéns',
      (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Brincadeiras'));
    await _go(tester);
    await tester.tap(find.text('Cadê?'));
    await _go(tester);

    final options = find.byWidgetPredicate((w) =>
        w.key is ValueKey<String> &&
        (w.key! as ValueKey<String>).value.startsWith('option-'));
    for (var round = 0; round < 6; round++) {
      expect(options, findsNWidgets(3), reason: 'rodada $round');
      // Toca em todas: as erradas só balançam; a certa avança a rodada.
      for (var i = 0; i < 3; i++) {
        await tester.tap(options.at(i), warnIfMissed: false);
        await tester.pump(const Duration(milliseconds: 50));
      }
      await tester.pump(const Duration(milliseconds: 1000));
    }
    expect(find.text('Parabéns!'), findsOneWidget);
    expect(find.text('Jogar de novo'), findsOneWidget);

    await tester.tap(find.text('Jogar de novo'));
    await _go(tester);
    expect(find.text('Parabéns!'), findsNothing);
    expect(options, findsNWidgets(3));
  });

  testWidgets('Memória: toca numa carta sem erro e mostra o nome',
      (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Brincadeiras'));
    await _go(tester);
    await tester.tap(find.text('Memória'));
    await _go(tester);
    await tester.tap(find.byKey(const ValueKey('card-0')));
    await _go(tester);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Cores abre tela com nome nos dois idiomas', (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Cores'));
    await _go(tester);
    await tester.tap(find.text('VERMELHO'));
    await _go(tester);
    expect(find.text('VERMELHO'), findsOneWidget);
    expect(find.text('RED'), findsOneWidget);
    expect(find.text('Coração'), findsOneWidget);

    // Tocar no objeto fala o nome dele (sem erro).
    await tester.tap(find.text('Coração'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 300));
    expect(tester.takeException(), isNull);
  });

  testWidgets('Arrastar para o lado troca de animal (e a seta também)',
      (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Frutas'));
    await _go(tester);
    await tester.tap(find.text('Maçã'));
    await _go(tester);
    expect(find.text('MAÇÃ'), findsOneWidget);

    await tester.drag(find.byType(PageView), const Offset(-300, 0));
    await tester.pump();
    await _go(tester);
    // "Banana" é igual em português e inglês: aparece duas vezes.
    expect(find.text('BANANA'), findsNWidgets(2));
    expect(find.text('MAÇÃ'), findsNothing);

    await tester.tap(find.byIcon(Icons.chevron_left_rounded).first,
        warnIfMissed: false);
    await _go(tester);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Festa dos Bichos mostra os animais juntos e toca no som',
      (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Festa dos Bichos'));
    await _go(tester);
    expect(find.text('Festa dos Bichos'), findsOneWidget);
    expect(find.text('Vaca'), findsOneWidget);
    expect(find.text('Leão'), findsOneWidget);

    await tester.tap(find.text('Vaca'));
    await tester.pump(const Duration(milliseconds: 300));
    expect(tester.takeException(), isNull);
  });

  testWidgets('Quem faz esse som?: completar as 6 rodadas mostra os parabéns',
      (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Brincadeiras'));
    await _go(tester);
    await tester.tap(find.text('Quem faz esse som?'));
    await _go(tester);

    final options = find.byWidgetPredicate((w) =>
        w.key is ValueKey<String> &&
        (w.key! as ValueKey<String>).value.startsWith('option-'));
    for (var round = 0; round < 6; round++) {
      expect(options, findsNWidgets(3), reason: 'rodada $round');
      for (var i = 0; i < 3; i++) {
        await tester.tap(options.at(i), warnIfMissed: false);
        await tester.pump(const Duration(milliseconds: 50));
      }
      await tester.pump(const Duration(milliseconds: 1000));
    }
    expect(find.text('Parabéns!'), findsOneWidget);
  });

  testWidgets('Área dos responsáveis: define o tempo de uso por dia',
      (tester) async {
    await _pumpApp(tester);
    await tester.longPress(find.byIcon(Icons.settings_rounded));
    await _go(tester);
    expect(find.text('Tempo de uso por dia'), findsOneWidget);
    expect(find.text('Quando o tempo acabar'), findsOneWidget);
    expect(find.text('Sem limite de tempo.'), findsOneWidget);

    await tester.tap(find.text('30 min'));
    await tester.pump(const Duration(milliseconds: 100));
    expect(find.textContaining('de 30 min'), findsOneWidget);

    // Volta para "sem limite" para não deixar o relógio rodando.
    await tester.tap(find.text('Sem limite'));
    await tester.pump(const Duration(milliseconds: 100));
    expect(find.text('Sem limite de tempo.'), findsOneWidget);
  });

  testWidgets('Letras: só maiúsculas na lista (A-Z), sem "Aa"', (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Letras'));
    await _go(tester);
    for (final l in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('')) {
      // A lista é rolável: as últimas letras só existem depois de rolar.
      await tester.scrollUntilVisible(find.text(l), 200,
          scrollable: find.byType(Scrollable).last);
      expect(find.text(l), findsOneWidget, reason: l);
      expect(find.text('$l${l.toLowerCase()}'), findsNothing,
          reason: 'Aa/Bb não deve existir');
    }
  });

  testWidgets(
      'Letras: detalhe da B mostra PT e EN, botões por idioma e palavras',
      (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Letras'));
    await _go(tester);
    await tester.tap(find.text('B'));
    await _go(tester);
    // nome da letra nos dois idiomas, palavras de exemplo e botões
    expect(find.text('BÊ'), findsOneWidget);
    expect(find.text('BEE'), findsOneWidget);
    expect(find.text('PT-BR'), findsOneWidget);
    expect(find.text('EN-US'), findsOneWidget);
    expect(find.text('Bola'), findsOneWidget);
    expect(find.text('Barco'), findsOneWidget);
    expect(find.text('Português'), findsOneWidget);
    expect(find.text('English'), findsOneWidget);
    expect(find.text('Palavras'), findsOneWidget);
    expect(find.text('Bb'), findsNothing);

    // cada idioma sozinho, uma palavra, as palavras e o bloquinho: sem erros
    await tester.tap(find.text('Português'));
    await tester.pump(const Duration(milliseconds: 300));
    await tester.tap(find.text('English'));
    await tester.pump(const Duration(milliseconds: 300));
    await tester.tap(find.text('Bola'));
    await tester.pump(const Duration(milliseconds: 300));
    await tester.tap(find.text('Palavras'));
    await tester.pump(const Duration(milliseconds: 300));
    expect(tester.takeException(), isNull);

    // arrastar para o lado vai para a letra C
    await tester.drag(find.byType(PageView), const Offset(-300, 0));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 800));
    expect(find.text('CÊ'), findsOneWidget);
    expect(find.text('SEE'), findsOneWidget);
    expect(find.text('Carro'), findsOneWidget);
  });

  testWidgets('Números: lista 0-10, detalhe do 3 e contagem animada',
      (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Números'));
    await _go(tester);
    expect(find.text('Três'), findsOneWidget);

    await tester.tap(find.text('Três'));
    await _go(tester);
    expect(find.text('TRÊS'), findsOneWidget);
    expect(find.text('THREE'), findsOneWidget);
    expect(find.text('Falar'), findsOneWidget);
    expect(find.text('Contar'), findsOneWidget);
    // três objetos para contar
    expect(find.byKey(const ValueKey('count-1')), findsOneWidget);
    expect(find.byKey(const ValueKey('count-3')), findsOneWidget);
    expect(find.byKey(const ValueKey('count-4')), findsNothing);

    await tester.tap(find.text('Contar'));
    await tester.pump(const Duration(milliseconds: 100));
    await tester.pump(const Duration(milliseconds: 400));
    // deixa a contagem terminar (o bloquinho tem animação contínua: sem pumpAndSettle)
    await tester.pump(const Duration(seconds: 1));
    expect(tester.takeException(), isNull);

    // vai para o 4: aparecem quatro objetos
    await tester.drag(find.byType(PageView), const Offset(-300, 0));
    await tester.pump();
    await _go(tester);
    expect(find.byKey(const ValueKey('count-4')), findsOneWidget);
  });

  for (final entry in {
    'Descubra a letra': 'letras',
    'Descubra o número': 'números',
  }.entries) {
    testWidgets('${entry.key}: completar as 6 rodadas mostra os parabéns',
        (tester) async {
      await _pumpApp(tester);
      await tester.tap(find.text('Brincadeiras'));
      await _go(tester);
      await tester.tap(find.text(entry.key));
      await _go(tester);

      final options = find.byWidgetPredicate((w) =>
          w.key is ValueKey<String> &&
          (w.key! as ValueKey<String>).value.startsWith('option-'));
      for (var round = 0; round < 6; round++) {
        expect(options, findsNWidgets(3),
            reason: '${entry.value} rodada $round');
        for (var i = 0; i < 3; i++) {
          await tester.tap(options.at(i), warnIfMissed: false);
          await tester.pump(const Duration(milliseconds: 50));
        }
        await tester.pump(const Duration(milliseconds: 1000));
      }
      expect(find.text('Parabéns!'), findsOneWidget);
      expect(find.text('Jogar de novo'), findsOneWidget);

      await tester.tap(find.text('Jogar de novo'));
      await _go(tester);
      expect(find.text('Parabéns!'), findsNothing);
      expect(options, findsNWidgets(3));
      expect(tester.takeException(), isNull);
    });
  }

  testWidgets('Cores: a cor fala o nome ao abrir e mostra coisas daquela cor',
      (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Cores'));
    await _go(tester);
    await tester.scrollUntilVisible(find.text('CINZA'), 200,
        scrollable: find.byType(Scrollable).last);
    expect(find.text('CINZA'), findsOneWidget);
    await tester.scrollUntilVisible(find.text('AZUL'), -200,
        scrollable: find.byType(Scrollable).last);
    await tester.tap(find.text('AZUL'));
    await _go(tester);
    expect(find.text('BLUE'), findsOneWidget);
    expect(find.text('Baleia'), findsOneWidget);
    expect(find.text('Whale'), findsOneWidget);
    // próxima cor pela seta
    await tester.tap(find.byIcon(Icons.chevron_right_rounded).first);
    await _go(tester);
    expect(find.text('AMARELO'), findsOneWidget);
    expect(find.text('YELLOW'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Pintar: escolhe a cor, pinta o desenho e troca de desenho',
      (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Cores'));
    await _go(tester);
    await tester.tap(find.text('Pintar · Paint'));
    await _go(tester);
    expect(find.text('Casinha'), findsOneWidget);
    expect(find.text('House'), findsOneWidget);
    expect(find.text('Vermelho · Red'), findsOneWidget);

    await tester.tap(find.byKey(const ValueKey('pot-blue')));
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.text('Azul · Blue'), findsOneWidget);

    // Pinta o meio do desenho (a parede) e deixa a tinta se espalhar.
    await tester.tap(find.byKey(const ValueKey('paint-canvas')));
    await tester.pump(const Duration(milliseconds: 600));
    expect(tester.takeException(), isNull);

    await tester.tap(find.byIcon(Icons.chevron_right_rounded).first);
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.text('Flor'), findsOneWidget);
    expect(find.text('Flower'), findsOneWidget);
  });

  testWidgets('Corpo: tocar numa parte mostra o nome nos dois idiomas',
      (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Corpo'));
    await _go(tester);
    expect(find.text('Toque no corpo!'), findsOneWidget);
    expect(find.text('Touch the body!'), findsOneWidget);

    // Toca no meio do rosto, um pouco abaixo dos olhos: o nariz.
    final box = tester.getRect(find.byKey(const ValueKey('body-figure')));
    final k = (box.width / 200) < (box.height / 300)
        ? box.width / 200
        : box.height / 300;
    final origin = box.topLeft +
        Offset((box.width - 200 * k) / 2, (box.height - 300 * k) / 2);
    await tester.tapAt(origin + const Offset(100, 91) * k);
    await tester.pump(const Duration(milliseconds: 400));
    expect(find.text('NARIZ'), findsOneWidget);
    expect(find.text('NOSE'), findsOneWidget);

    // Pela fileira de nomes também.
    await tester.scrollUntilVisible(find.text('Barriga'), 120,
        scrollable: find.descendant(
            of: find.byType(ListView), matching: find.byType(Scrollable)));
    await tester.drag(find.text('Barriga'), const Offset(-200, 0));
    await tester.pump(const Duration(milliseconds: 300));
    await tester.tap(find.text('Barriga'));
    await tester.pump(const Duration(milliseconds: 400));
    expect(find.text('BARRIGA'), findsOneWidget);
    expect(find.text('BELLY'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Onde está?: tocar sempre na parte certa termina com parabéns',
      (tester) async {
    await _pumpApp(tester);
    await tester.tap(find.text('Corpo'));
    await _go(tester);
    await tester.tap(find.text('Onde está?'));
    await _go(tester);
    for (var round = 0; round < 6; round++) {
      // A pergunta diz qual é a parte: acha pelo texto e toca no centro dela.
      final ask = tester
          .widgetList<Text>(find.byType(Text))
          .map((t) => t.data ?? '')
          .firstWhere((t) =>
              t.startsWith('Onde est') && t.endsWith('?') && t != 'Onde está?');
      final repo = await tester.runAsync(ContentRepository.load);
      final part = repo!.byId('body').items.firstWhere((i) => i.askPt == ask);
      final box = tester.getRect(find.byKey(const ValueKey('body-figure')));
      final k = (box.width / 200) < (box.height / 300)
          ? box.width / 200
          : box.height / 300;
      final origin = box.topLeft +
          Offset((box.width - 200 * k) / 2, (box.height - 300 * k) / 2);
      await tester.tapAt(origin + BodyMap.tapPoint(part.id) * k);
      await tester.pump(const Duration(milliseconds: 50));
      await tester.pump(const Duration(milliseconds: 1000));
    }
    expect(find.text('Parabéns!'), findsOneWidget);
  });
}
