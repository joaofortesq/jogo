import 'dart:async';

import 'package:flutter/painting.dart' show Color;
import 'package:flutter_test/flutter_test.dart';
import 'package:mundo_divertido/models/learning_item.dart';
import 'package:mundo_divertido/services/audio_service.dart';
import 'package:mundo_divertido/services/settings_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Registra o que foi tocado: "file:<caminho>" ou "say:<lang>:<texto>".
class FakeBackend implements AudioBackend {
  final events = <String>[];
  final List<Completer<void>> gates = [];
  bool useGates = false;
  bool voiceAvailable = true;

  Future<void> _wait() {
    if (!useGates) return Future.value();
    final c = Completer<void>();
    gates.add(c);
    return c.future;
  }

  @override
  Future<void> playAsset(String assetPath, double volume) {
    events.add('file:$assetPath');
    return _wait();
  }

  @override
  Future<bool> speak(
    String text, {
    required String lang,
    required double volume,
    required double pitch,
    required double rate,
  }) async {
    if (!voiceAvailable) return false;
    events.add('say:$lang:$text');
    await _wait();
    return true;
  }

  @override
  Future<void> stop() async {
    for (final g in gates) {
      if (!g.isCompleted) g.complete();
    }
  }

  @override
  Future<void> dispose() async {}
}

const cow = LearningItem(
  id: 'cow',
  pt: 'Vaca',
  en: 'Cow',
  color: Color(0xFFFFFFFF),
  hasAnimalSound: true,
  sound: SoundSpec(text: 'Muuuu!', pitch: .6, rate: .3),
);

void main() {
  late FakeBackend backend;
  late SettingsService settings;
  late AudioService audio;
  var existing = <String>{};

  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    settings = SettingsService(await SharedPreferences.getInstance());
    backend = FakeBackend();
    existing = {};
    audio = AudioService(
      settings: settings,
      backend: backend,
      assetExists: (p) async => existing.contains(p),
      clipGap: Duration.zero,
    );
  });

  test('sem arquivos, playAll fala o som, o português e o inglês', () async {
    final r = await audio.playAll(cow);
    expect(r, AudioOutcome.played);
    expect(backend.events, ['say:pt-BR:Muuuu!', 'say:pt-BR:Vaca', 'say:en-US:Cow']);
    expect(audio.playingTag.value, isNull);
  });

  test('playWords fala português e depois inglês', () async {
    await audio.playWords(cow);
    expect(backend.events, ['say:pt-BR:Vaca', 'say:en-US:Cow']);
  });

  test('arquivo gravado tem prioridade sobre a voz', () async {
    existing = {cow.soundAudioPath, cow.ptAudioPath};
    await audio.playAll(cow);
    expect(backend.events, [
      'file:${cow.soundAudioPath}',
      'file:${cow.ptAudioPath}',
      'say:en-US:Cow',
    ]);
  });

  test('silenciar efeitos pula só o som do animal', () async {
    await settings.setEffectsMuted(true);
    await audio.playAll(cow);
    expect(backend.events, ['say:pt-BR:Vaca', 'say:en-US:Cow']);
  });

  test('voz não instalada retorna voiceMissing sem lançar erro', () async {
    backend.voiceAvailable = false;
    final r = await audio.playEn(cow);
    expect(r, AudioOutcome.voiceMissing);
    expect(backend.events, isEmpty);
    expect(audio.playingTag.value, isNull);
  });

  test('novo pedido interrompe a sequência anterior', () async {
    backend.useGates = true;
    final first = audio.playAll(cow);
    await Future<void>.delayed(Duration.zero);
    await Future<void>.delayed(Duration.zero);
    expect(backend.events, ['say:pt-BR:Muuuu!']);
    final second = audio.playPt(cow);
    expect(await first, AudioOutcome.interrupted);
    await Future<void>.delayed(Duration.zero);
    await Future<void>.delayed(Duration.zero);
    backend.gates.last.complete();
    expect(await second, AudioOutcome.played);
    // o inglês da primeira sequência nunca chegou a tocar
    expect(backend.events, ['say:pt-BR:Muuuu!', 'say:pt-BR:Vaca']);
  });

  test('say e praise falam frases soltas', () async {
    await audio.say('Quem sou eu?');
    await audio.praise();
    expect(backend.events, [
      'say:pt-BR:Quem sou eu?',
      'say:pt-BR:Muito bem!',
      'say:en-US:Great job!',
    ]);
  });

  test('volume é limitado entre 0 e 1', () async {
    await settings.setVolume(3);
    expect(settings.volume, 1.0);
  });
}
