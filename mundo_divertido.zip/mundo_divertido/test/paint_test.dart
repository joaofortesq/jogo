import 'dart:ui';

import 'package:flutter_test/flutter_test.dart';
import 'package:mundo_divertido/data/paint_pictures.dart';

void main() {
  test('há 6 desenhos, com nome nos dois idiomas e partes de id único', () {
    expect(paintPictures.length, 6);
    for (final p in paintPictures) {
      expect(p.pt.trim(), isNotEmpty);
      expect(p.en.trim(), isNotEmpty);
      final ids = p.regions.map((r) => r.id).toList();
      expect(ids.toSet().length, ids.length, reason: p.id);
      expect(p.regions.length, greaterThanOrEqualTo(5), reason: p.id);
    }
  });

  test('cada parte cabe no quadro 200x200 e pode ser tocada', () {
    const frame = Rect.fromLTWH(-1, -1, 202, 202);
    for (final p in paintPictures) {
      for (var i = 0; i < p.regions.length; i++) {
        final b = p.regions[i].path.getBounds();
        expect(b.isEmpty, isFalse, reason: '${p.id}/${p.regions[i].id}');
        expect(
            frame.contains(b.topLeft) && frame.contains(b.bottomRight), isTrue,
            reason: '${p.id}/${p.regions[i].id} fora do quadro: $b');
        // Algum ponto da parte acerta ela mesma (não fica escondida por baixo).
        var reachable = false;
        for (var y = b.top; y <= b.bottom && !reachable; y += 1) {
          for (var x = b.left; x <= b.right && !reachable; x += 1) {
            if (p.hitTest(Offset(x, y)) == i) reachable = true;
          }
        }
        expect(reachable, isTrue,
            reason: '${p.id}/${p.regions[i].id} escondida');
      }
    }
  });

  test('tocar fora do desenho não pinta nada', () {
    final house = paintPictures.first;
    expect(house.hitTest(const Offset(5, 120)), -1);
    expect(house.hitTest(const Offset(100, 130)), isNot(-1));
  });
}
