import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'data/content_repository.dart';
import 'screens/home_screen.dart';
import 'services/audio_service.dart';
import 'services/settings_service.dart';
import 'theme/app_theme.dart';

class MundoDivertidoApp extends StatefulWidget {
  const MundoDivertidoApp({
    super.key,
    required this.repository,
    required this.settings,
    this.audio,
  });

  final ContentRepository repository;
  final SettingsService settings;

  /// Permite injetar um AudioService (testes). Se nulo, o app cria o seu.
  final AudioService? audio;

  @override
  State<MundoDivertidoApp> createState() => _MundoDivertidoAppState();
}

class _MundoDivertidoAppState extends State<MundoDivertidoApp> with WidgetsBindingObserver {
  late final AudioService _audio = widget.audio ?? AudioService(settings: widget.settings);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Para o áudio quando o app sai de cena.
    if (state != AppLifecycleState.resumed) _audio.stop();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    if (widget.audio == null) _audio.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider<ContentRepository>.value(value: widget.repository),
        ChangeNotifierProvider<SettingsService>.value(value: widget.settings),
        Provider<AudioService>.value(value: _audio),
      ],
      child: MaterialApp(
        title: 'Mundo Divertido',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        home: const HomeScreen(),
      ),
    );
  }
}
