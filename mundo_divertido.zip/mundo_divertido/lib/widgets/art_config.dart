/// Configuração de desenho. Nos testes de widget os SVGs (flutter_svg) usam
/// isolates/E-S reais, que não completam dentro do relógio falso do teste e
/// deixam tudo pendurado até o timeout de 10 min. Os testes de navegação
/// desligam o SVG e usam o personagem provisório.
class ArtConfig {
  ArtConfig._();

  static bool renderSvg = true;
}
