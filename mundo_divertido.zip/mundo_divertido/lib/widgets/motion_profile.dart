import 'dart:math' as math;

/// Jeito de se mexer de cada bicho (e das frutas).
enum MotionKind { hop, sway, trot, waddle, prowl, bounce }

MotionKind motionFor(String id) => switch (id) {
      'rabbit' || 'monkey' || 'goat' || 'sheep' => MotionKind.hop,
      'elephant' || 'giraffe' || 'cow' || 'hippopotamus' => MotionKind.sway,
      'horse' || 'donkey' || 'zebra' || 'cheetah' => MotionKind.trot,
      'duck' || 'hen' || 'rooster' || 'ostrich' || 'pig' => MotionKind.waddle,
      'lion' || 'crocodile' || 'rhinoceros' => MotionKind.prowl,
      _ => MotionKind.bounce,
    };

/// Posição do personagem em um instante do ciclo.
class MotionPose {
  const MotionPose({
    this.dx = 0,
    this.dy = 0,
    this.angle = 0,
    this.scaleX = 1,
    this.scaleY = 1,
  });

  final double dx;
  final double dy;
  final double angle;
  final double scaleX;
  final double scaleY;
}

/// [v] vai de 0 a 1 em cada ciclo (o ciclo se repete sem emenda: só usamos
/// múltiplos inteiros de 2π). [size] é o tamanho do desenho em pixels.
MotionPose poseFor(MotionKind kind, double v, double size) {
  final p = v * 2 * math.pi;
  switch (kind) {
    case MotionKind.hop:
      // Dois pulinhos por ciclo, com achatadinha ao pousar.
      final u = (v * 2) % 1.0;
      final h = u < .45 ? math.sin(u / .45 * math.pi) : 0.0;
      final land = (u >= .45 && u < .6) ? math.sin((u - .45) / .15 * math.pi) : 0.0;
      return MotionPose(
        dy: -h * size * .09,
        scaleY: 1 + h * .05 - land * .06,
        scaleX: 1 - h * .03 + land * .04,
      );
    case MotionKind.sway:
      return MotionPose(
        dx: math.sin(p) * size * .02,
        angle: math.sin(p) * .05,
        scaleY: 1 + math.sin(p * 2) * .015,
      );
    case MotionKind.trot:
      final trotS = math.sin(p * 4);
      return MotionPose(
        dy: -trotS.abs() * size * .03,
        angle: trotS * .03,
        dx: math.sin(p) * size * .015,
      );
    case MotionKind.waddle:
      final waddleS = math.sin(p * 3);
      return MotionPose(
        dx: waddleS * size * .02,
        dy: -waddleS.abs() * size * .015,
        angle: waddleS * .09,
      );
    case MotionKind.prowl:
      final prowlS = math.sin(p);
      return MotionPose(
        dx: prowlS * size * .035,
        angle: prowlS * .025,
        scaleY: 1 + math.sin(p * 2) * .025,
        scaleX: 1 - math.sin(p * 2) * .015,
      );
    case MotionKind.bounce:
      final bounceS = math.sin(p * 2);
      return MotionPose(
        dy: -bounceS.abs() * size * .04,
        scaleY: 1 + math.sin(p * 4) * .03,
        scaleX: 1 - math.sin(p * 4) * .02,
      );
  }
}

/// Movimento extra enquanto o personagem "fala" ou faz o som.
MotionPose talkingBoost(double v, double size) {
  final s = math.sin(v * 2 * math.pi * 8);
  return MotionPose(
    dy: -s.abs() * size * .035,
    scaleX: 1 - s * .02,
    scaleY: 1 + s * .035,
  );
}
