import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../models/learning_item.dart';
import 'character_face.dart';

/// Ilustração do item: SVG + olhos desenhados por cima (para poder piscar).
/// Sem arte cadastrada, cai no personagem provisório.
class ItemArt extends StatelessWidget {
  const ItemArt({
    super.key,
    required this.item,
    required this.size,
    this.blink = 0,
    this.blinkListenable,
  });

  final LearningItem item;
  final double size;

  /// 0 = olhos abertos, 1 = fechados.
  final double blink;

  /// Se informado, só os olhos são redesenhados quando o valor muda
  /// (o SVG fica em cache), em vez de reconstruir o desenho a cada quadro.
  final ValueListenable<double>? blinkListenable;

  @override
  Widget build(BuildContext context) {
    final art = item.art;
    if (art == null) {
      final l = blinkListenable;
      if (l == null) return CharacterFace(color: item.color, blink: blink, size: size);
      return ValueListenableBuilder<double>(
        valueListenable: l,
        builder: (_, v, __) => CharacterFace(color: item.color, blink: v, size: size),
      );
    }
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        fit: StackFit.expand,
        children: [
          SvgPicture.asset(art.asset, width: size, height: size),
          CustomPaint(painter: _EyesPainter(art, blink, blinkListenable)),
        ],
      ),
    );
  }
}

class _EyesPainter extends CustomPainter {
  _EyesPainter(this.art, this.blink, this.listenable) : super(repaint: listenable);
  final ArtSpec art;
  final double blink;
  final ValueListenable<double>? listenable;

  @override
  void paint(Canvas canvas, Size size) {
    final k = size.width / 200;
    final open = (1 - (listenable?.value ?? blink)).clamp(0.08, 1.0);
    final r = art.eyeRadius * k;
    final line = Paint()
      ..color = const Color(0xFF4B2E43)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5 * k;
    for (final e in art.eyes) {
      canvas.save();
      canvas.translate(e.dx * k, e.dy * k);
      canvas.scale(1, open);
      canvas.drawCircle(Offset.zero, r, Paint()..color = Colors.white);
      canvas.drawCircle(Offset.zero, r, line);
      canvas.drawCircle(Offset(r * .08, r * .05), r * .62, Paint()..color = const Color(0xFF1E1B3A));
      canvas.drawCircle(Offset(r * .3, -r * .2), r * .2, Paint()..color = Colors.white);
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(_EyesPainter old) =>
      old.blink != blink || old.art != art || old.listenable != listenable;
}
