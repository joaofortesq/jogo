import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../models/learning_item.dart';
import 'item_art.dart' show EyesPainter;

/// Bicho de corpo inteiro: cauda, pernas, corpo, braços e cabeça se mexem
/// separados. Tudo é calculado a partir de [clock] (um ciclo de 4 s), com
/// frequências inteiras, então o movimento recomeça sem emenda.
///
/// [dance] vai de 0 (parado, só respirando) a 1 (dançando de verdade).
class RigAnimal extends StatefulWidget {
  const RigAnimal({
    super.key,
    required this.rig,
    required this.size,
    required this.clock,
    this.phase = 0,
    this.dance = 0,
    this.talking,
  });

  final RigSpec rig;
  final double size;

  /// Valor de 0 a 1 que se repete (um ciclo de 4 s).
  final Animation<double> clock;

  /// Desloca o ciclo (0 a 1) para cada bicho dançar num tempo diferente.
  final double phase;
  final double dance;

  /// Verdadeiro enquanto o bicho "fala" (som ou nome tocando).
  final ValueListenable<bool>? talking;

  @override
  State<RigAnimal> createState() => _RigAnimalState();
}

class _RigAnimalState extends State<RigAnimal> {
  late Map<String, Widget> _svgs;

  @override
  void initState() {
    super.initState();
    _svgs = _buildSvgs();
  }

  @override
  void didUpdateWidget(RigAnimal old) {
    super.didUpdateWidget(old);
    if (old.rig != widget.rig || old.size != widget.size) _svgs = _buildSvgs();
  }

  /// Os SVGs são criados uma vez só; a cada quadro só se aplicam transformações.
  Map<String, Widget> _buildSvgs() => {
        for (final l in widget.rig.layers)
          l.role: RepaintBoundary(
            child: SvgPicture.asset(l.asset, width: widget.size, height: widget.size),
          ),
      };

  static double _s(double v, int k, [double ph = 0]) => math.sin((v * k + ph) * 2 * math.pi);

  static Alignment _al(Offset p) => Alignment((p.dx - 100) / 100, (p.dy - 100) / 100);

  @override
  Widget build(BuildContext context) {
    final size = widget.size;
    return SizedBox(
      width: size,
      height: size,
      child: AnimatedBuilder(
        animation: Listenable.merge([widget.clock, widget.talking]),
        builder: (context, _) {
          final v = (widget.clock.value + widget.phase) % 1.0;
          final d = widget.dance.clamp(0.0, 1.0);
          final talk = widget.talking?.value ?? false;
          double lerp(double idle, double dance) => idle + (dance - idle) * d;

          final rootAngle = lerp(.012 * _s(v, 1), .10 * _s(v, 3));
          final bounce = -d * _s(v, 6).abs() * size * .03;
          final bodySy = 1 + lerp(.012 * _s(v, 2), .03 * _s(v, 6)) + (talk ? .015 * _s(v, 8) : 0);
          final bodySx = 1 - (bodySy - 1) * .6;
          final headAngle =
              lerp(.035 * _s(v, 1, .2), -.09 * _s(v, 3, .08)) + (talk ? .05 * _s(v, 8) : 0);
          final headDy = (talk ? -_s(v, 8).abs() * size * .012 : 0.0) - d * _s(v, 6, .25) * size * .008;
          final tailAngle = lerp(.10 * _s(v, 2), .30 * _s(v, 6));
          final flap = widget.rig.flap;
          final armL = flap
              ? lerp(.05 * _s(v, 1), .25 + .6 * (.5 + .5 * _s(v, 6)))
              : lerp(.06 * _s(v, 1, .1), .55 + .5 * _s(v, 3));
          final armR = flap
              ? -armL
              : -lerp(.06 * _s(v, 1, .6), .55 + .5 * _s(v, 3, .5));
          final liftL = math.max(0.0, _s(v, 3));
          final liftR = math.max(0.0, -_s(v, 3));

          final blinkPhase = (v + .5) % 1.0;
          final blink = (blinkPhase > .9 && blinkPhase < .96)
              ? math.sin((blinkPhase - .9) / .06 * math.pi)
              : 0.0;

          final children = <Widget>[];
          for (final l in widget.rig.layers) {
            final svg = _svgs[l.role]!;
            final al = _al(l.pivot);
            switch (l.role) {
              case 'tail':
                children.add(Transform.rotate(angle: tailAngle, alignment: al, child: svg));
              case 'legL':
                children.add(Transform.translate(
                  offset: Offset(0, -d * liftL * size * .04),
                  child: Transform.rotate(angle: -d * .10 * liftL, alignment: al, child: svg),
                ));
              case 'legR':
                children.add(Transform.translate(
                  offset: Offset(0, -d * liftR * size * .04),
                  child: Transform.rotate(angle: d * .10 * liftR, alignment: al, child: svg),
                ));
              case 'armL':
                children.add(Transform.rotate(angle: armL, alignment: al, child: svg));
              case 'armR':
                children.add(Transform.rotate(angle: armR, alignment: al, child: svg));
              case 'body':
                children.add(Transform.scale(scaleX: bodySx, scaleY: bodySy, alignment: al, child: svg));
              case 'head':
                children.add(Transform.translate(
                  offset: Offset(0, headDy),
                  child: Transform.rotate(
                    angle: headAngle,
                    alignment: al,
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        svg,
                        CustomPaint(
                            painter: EyesPainter(widget.rig.eyes, widget.rig.eyeRadius, blink)),
                      ],
                    ),
                  ),
                ));
              default:
                children.add(svg);
            }
          }
          return Transform.translate(
            offset: Offset(0, bounce),
            child: Transform.rotate(
              angle: rootAngle,
              alignment: const Alignment(0, .9),
              child: Stack(clipBehavior: Clip.none, fit: StackFit.expand, children: children),
            ),
          );
        },
      ),
    );
  }
}
