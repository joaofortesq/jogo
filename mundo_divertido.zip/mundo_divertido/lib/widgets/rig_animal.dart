import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../models/learning_item.dart';
import 'item_art.dart' show EyesPainter;

/// Bicho de corpo inteiro, em pé: rabo, pernas, corpo, braços (ou asas) e
/// cabeça se mexem separados; os olhos piscam e, quando o desenho tem boca,
/// ela abre quando o bicho fala. Tudo é calculado a partir de [clock] (um
/// ciclo de 4 s) com frequências inteiras, então o movimento recomeça sem emenda.
///
/// [dance] vai de 0 (parado, só respirando) a 1 (dançando de verdade).
class RigAnimal extends StatefulWidget {
  const RigAnimal({
    super.key,
    required this.rig,
    required this.size,
    required this.clock,
    this.phase = 0,
    this.dance = 0,
    this.talking,
  });

  final RigSpec rig;
  final double size;

  /// Valor de 0 a 1 que se repete (um ciclo de 4 s).
  final Animation<double> clock;

  /// Desloca o ciclo (0 a 1) para cada bicho se mexer num tempo diferente.
  final double phase;
  final double dance;

  /// Verdadeiro enquanto o bicho "fala" (som ou nome tocando).
  final ValueListenable<bool>? talking;

  @override
  State<RigAnimal> createState() => _RigAnimalState();
}

class _RigAnimalState extends State<RigAnimal> {
  late Map<String, Widget> _svgs;

  @override
  void initState() {
    super.initState();
    _svgs = _buildSvgs();
  }

  @override
  void didUpdateWidget(RigAnimal old) {
    super.didUpdateWidget(old);
    if (old.rig != widget.rig || old.size != widget.size) _svgs = _buildSvgs();
  }

  /// Os SVGs são criados uma vez só; a cada quadro só se aplicam transformações.
  Map<String, Widget> _buildSvgs() => {
        for (final l in widget.rig.layers)
          l.role: RepaintBoundary(
            child: SvgPicture.asset(l.asset, width: widget.size, height: widget.size),
          ),
      };

  static double _s(double v, int k, [double ph = 0]) => math.sin((v * k + ph) * 2 * math.pi);

  static Alignment _al(Offset p) => Alignment((p.dx - 100) / 100, (p.dy - 100) / 100);

  @override
  Widget build(BuildContext context) {
    final size = widget.size;
    final rig = widget.rig;
    return SizedBox(
      width: size,
      height: size,
      child: AnimatedBuilder(
        animation: Listenable.merge([widget.clock, widget.talking]),
        builder: (context, _) {
          final v = (widget.clock.value + widget.phase) % 1.0;
          final d = widget.dance.clamp(0.0, 1.0);
          final talk = widget.talking?.value ?? false;
          double lerp(double idle, double dance) => idle + (dance - idle) * d;

          final step = _s(v, 3);
          final rootAngle = lerp(.010 * _s(v, 1), .08 * step);
          final bounce = -d * step.abs() * size * .028;
          final bodySy = 1 + lerp(.014 * _s(v, 2), .02 * _s(v, 6)) + (talk ? .014 * _s(v, 8) : 0);
          final bodySx = 1 - (bodySy - 1) * .6;
          final headAngle = lerp(.035 * _s(v, 1, .2), -.10 * step) + (talk ? .05 * _s(v, 8) : 0);
          final headDy = (talk ? -_s(v, 8).abs() * size * .012 : 0.0) - d * _s(v, 6, .25) * size * .008;
          final tailAngle = lerp(.08 * _s(v, 2), .30 * _s(v, 6));
          final earL = lerp(.09 * _s(v, 2, .3), .20 * _s(v, 6)) + (talk ? .05 * _s(v, 8) : 0);
          final earR = -lerp(.09 * _s(v, 2, .55), .20 * _s(v, 6, .25)) - (talk ? .05 * _s(v, 8) : 0);
          final wing = rig.flap ? .25 + .6 * (.5 + .5 * _s(v, 6)) : .55 + .5 * _s(v, 3);
          final armL = lerp(.05 * _s(v, 1), wing);
          final armR = -lerp(.05 * _s(v, 1, .5), rig.flap ? wing : .55 + .5 * _s(v, 3, .5));
          final liftL = math.max(0.0, step);
          final liftR = math.max(0.0, -step);
          final mouthOpen = talk ? (.5 + .5 * _s(v, 8)) : 0.0;

          final blinkPhase = (v + .5) % 1.0;
          final blink = (blinkPhase > .9 && blinkPhase < .96)
              ? math.sin((blinkPhase - .9) / .06 * math.pi)
              : 0.0;

          final children = <Widget>[];
          for (final l in rig.layers) {
            final svg = _svgs[l.role]!;
            final al = _al(l.pivot);
            switch (l.role) {
              case 'tail':
                children.add(Transform.rotate(angle: tailAngle, alignment: al, child: svg));
              case 'hindL':
                children.add(Transform.rotate(angle: d * .05 * step, alignment: al, child: svg));
              case 'hindR':
                children.add(Transform.rotate(angle: -d * .05 * step, alignment: al, child: svg));
              case 'legL':
                children.add(Transform.translate(
                  offset: Offset(0, -d * liftL * size * .04),
                  child: Transform.rotate(angle: -d * .07 * liftL, alignment: al, child: svg),
                ));
              case 'legR':
                children.add(Transform.translate(
                  offset: Offset(0, -d * liftR * size * .04),
                  child: Transform.rotate(angle: d * .07 * liftR, alignment: al, child: svg),
                ));
              case 'armL':
                children.add(Transform.rotate(angle: armL, alignment: al, child: svg));
              case 'armR':
                children.add(Transform.rotate(angle: armR, alignment: al, child: svg));
              case 'body':
                children.add(Transform.scale(scaleX: bodySx, scaleY: bodySy, alignment: al, child: svg));
              case 'earL':
              case 'earR':
                break; // entram no grupo da cabeça, logo abaixo
              case 'head':
                // Orelhas (se houver), cabeça, boca e olhos giram juntos em volta do pescoço.
                final pieces = <Widget>[];
                for (final e in rig.layers) {
                  if (e.role == 'earL') {
                    pieces.add(Transform.rotate(
                        angle: earL, alignment: _al(e.pivot), child: _svgs[e.role]!));
                  } else if (e.role == 'earR') {
                    pieces.add(Transform.rotate(
                        angle: earR, alignment: _al(e.pivot), child: _svgs[e.role]!));
                  }
                }
                pieces.add(svg);
                final m = rig.mouth;
                if (m != null && mouthOpen > .05) {
                  pieces.add(CustomPaint(painter: _MouthPainter(m, mouthOpen)));
                }
                pieces.add(CustomPaint(painter: EyesPainter(rig.eyes, rig.eyeRadius, blink)));
                children.add(Transform.translate(
                  offset: Offset(0, headDy),
                  child: Transform.rotate(
                    angle: headAngle,
                    alignment: al,
                    child: Stack(fit: StackFit.expand, children: pieces),
                  ),
                ));
              default:
                children.add(svg); // sombra no chão
            }
          }
          return Transform.rotate(
            angle: rootAngle,
            alignment: const Alignment(0, .9),
            child: Transform.translate(
              offset: Offset(0, bounce),
              child: Stack(clipBehavior: Clip.none, fit: StackFit.expand, children: children),
            ),
          );
        },
      ),
    );
  }
}

/// Boca aberta (com a língua) por cima do sorriso, para quando o bicho fala.
class _MouthPainter extends CustomPainter {
  _MouthPainter(this.mouth, this.open);

  final RigMouth mouth;
  final double open;

  @override
  void paint(Canvas canvas, Size size) {
    final k = size.width / 200;
    final c = Offset(mouth.x * k, mouth.y * k);
    final rx = mouth.width * .5 * k;
    final ry = mouth.width * .36 * k * open;
    canvas.drawOval(
        Rect.fromCenter(center: c.translate(0, ry * .5), width: rx * 2, height: ry * 2),
        Paint()..color = const Color(0xFF4B2E43));
    canvas.drawOval(
        Rect.fromCenter(center: c.translate(0, ry * 1.1), width: rx * 1.2, height: ry * .9),
        Paint()..color = const Color(0xFFF27A9B));
  }

  @override
  bool shouldRepaint(_MouthPainter old) => old.open != open || old.mouth != mouth;
}
