import 'package:flutter/material.dart';

/// Transição única do app: surge (fade), cresce um pouquinho (scale) e desliza
/// de leve. Duração fixa (não depende da versão do Flutter), o que também
/// deixa os testes previsíveis. A rota é opaca: a tela de baixo sai de cena
/// quando a transição termina.
class AppRoute<T> extends PageRouteBuilder<T> {
  AppRoute({required WidgetBuilder builder, super.settings})
      : super(
          opaque: true,
          transitionDuration: const Duration(milliseconds: 320),
          reverseTransitionDuration: const Duration(milliseconds: 260),
          pageBuilder: (context, animation, secondary) => builder(context),
          transitionsBuilder: (context, animation, secondary, child) {
            final reduce = MediaQuery.maybeOf(context)?.disableAnimations ?? false;
            if (reduce) return child;
            final curved = CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
            return FadeTransition(
              opacity: curved,
              child: SlideTransition(
                position: Tween<Offset>(begin: const Offset(.05, 0), end: Offset.zero)
                    .animate(curved),
                child: ScaleTransition(
                  scale: Tween<double>(begin: .96, end: 1).animate(curved),
                  child: child,
                ),
              ),
            );
          },
        );
}
