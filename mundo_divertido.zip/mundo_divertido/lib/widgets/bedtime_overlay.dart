import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../data/content_repository.dart';
import '../models/learning_item.dart';
import '../services/audio_service.dart';
import '../services/settings_service.dart';
import '../services/usage_service.dart';
import 'item_art.dart';
import 'parents_sheet.dart';
import 'sky_backdrop.dart';

/// Hora de dormir: noite estrelada, o gatinho (ou o cachorrinho) dorme, deseja
/// boa noite e o app fecha ou fica escuro, conforme o ajuste dos responsáveis.
class BedtimeOverlay extends StatefulWidget {
  const BedtimeOverlay({super.key, required this.navigatorKey});

  final GlobalKey<NavigatorState> navigatorKey;

  @override
  State<BedtimeOverlay> createState() => _BedtimeOverlayState();
}

class _BedtimeOverlayState extends State<BedtimeOverlay> with TickerProviderStateMixin {
  late final AnimationController _fade =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..forward();
  late final AnimationController _loop =
      AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat();
  late final AnimationController _dim =
      AnimationController(vsync: this, duration: const Duration(seconds: 6));
  late final LearningItem _animal;
  late final AudioService _audio;
  late final SettingsService _settings;
  late final UsageService _usage;
  bool _closing = false;

  @override
  void initState() {
    super.initState();
    _audio = context.read<AudioService>();
    _settings = context.read<SettingsService>();
    _usage = context.read<UsageService>();
    final farm = context.read<ContentRepository>().byId('farm').items;
    final wanted = DateTime.now().day.isEven ? 'dog' : 'cat';
    _animal = farm.firstWhere((i) => i.id == wanted, orElse: () => farm.first);
    WidgetsBinding.instance.addPostFrameCallback((_) => unawaited(_run()));
  }

  Future<void> _run() async {
    await Future<void>.delayed(const Duration(milliseconds: 1200));
    if (!mounted) return;
    try {
      await _audio.playBedtime(_animal);
    } catch (_) {
      // sem áudio: segue assim mesmo
    }
    if (!mounted || !_usage.bedtime) return;
    if (_settings.endMode == EndMode.closeApp) {
      _closing = true;
      // Dá um tempinho para o responsável poder dar mais tempo (toque longo na lua).
      await Future<void>.delayed(const Duration(seconds: 8));
      if (mounted && _usage.bedtime) await SystemNavigator.pop();
    } else {
      unawaited(_dim.forward());
    }
  }

  void _openParents() {
    final ctx = widget.navigatorKey.currentState?.overlay?.context;
    if (ctx == null) return;
    showModalBottomSheet<void>(
      context: ctx,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (_) => const ParentsSheet(),
    );
  }

  @override
  void dispose() {
    _fade.dispose();
    _loop.dispose();
    _dim.dispose();
    _audio.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.sizeOf(context).width;
    final size = math.min(w * .58, 270.0);
    return Positioned.fill(
      child: FadeTransition(
        opacity: _fade,
        child: Material(
          type: MaterialType.transparency,
          child: Stack(
            fit: StackFit.expand,
            children: [
              const SkyBackdrop(progress: 1),
              SafeArea(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    AnimatedBuilder(
                      animation: _loop,
                      builder: (context, _) {
                        final breathe = math.sin(_loop.value * 2 * math.pi);
                        return SizedBox(
                          width: size + 70,
                          height: size + 30,
                          child: Stack(
                            alignment: Alignment.center,
                            clipBehavior: Clip.none,
                            children: [
                              Transform.scale(
                                scaleY: 1 + breathe * .02,
                                scaleX: 1 - breathe * .01,
                                alignment: Alignment.bottomCenter,
                                child: ItemArt(item: _animal, size: size, blink: 1),
                              ),
                              for (var i = 0; i < 3; i++) _zzz(i),
                            ],
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 12),
                    const Text('Boa noite!',
                        style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900, color: Colors.white)),
                    const SizedBox(height: 6),
                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 32),
                      child: Text('Os bichinhos foram dormir.\nAté amanhã!',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: Colors.white70)),
                    ),
                  ],
                ),
              ),
              // tela escura (modo "tela de dormir")
              AnimatedBuilder(
                animation: _dim,
                builder: (context, _) => IgnorePointer(
                  child: ColoredBox(color: Colors.black.withOpacity(.9 * _dim.value)),
                ),
              ),
              // lua discreta: toque longo abre a área dos responsáveis
              SafeArea(
                child: Align(
                  alignment: Alignment.topRight,
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onLongPress: _openParents,
                    child: const SizedBox(
                      width: 64,
                      height: 64,
                      child: Icon(Icons.nightlight_round, color: Colors.white24, size: 28),
                    ),
                  ),
                ),
              ),
              if (_closing)
                const Positioned(
                  left: 0,
                  right: 0,
                  bottom: 28,
                  child: Text('Fechando o aplicativo…',
                      textAlign: TextAlign.center, style: TextStyle(color: Colors.white38, fontSize: 16)),
                ),
            ],
          ),
        ),
      ),
    );
  }

  /// "Z z z" subindo e sumindo ao lado do bichinho.
  Widget _zzz(int i) {
    final t = (_loop.value + i / 3) % 1.0;
    return Positioned(
      right: 6 + i * 8.0,
      top: 40 - t * 50 - i * 14.0,
      child: Opacity(
        opacity: (math.sin(t * math.pi)).clamp(0.0, 1.0).toDouble(),
        child: Text('Z',
            style: TextStyle(
                fontSize: 26.0 + i * 8, fontWeight: FontWeight.w900, color: Colors.white.withOpacity(.9))),
      ),
    );
  }
}
