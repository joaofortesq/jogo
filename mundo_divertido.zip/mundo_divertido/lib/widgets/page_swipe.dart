import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Faz o PageView acompanhar o dedo ao arrastar para o lado e, ao soltar,
/// vai para a página vizinha (ou volta). Usado junto das setas.
/// O PageView que fica dentro deve usar [NeverScrollableScrollPhysics], assim
/// só este gesto controla a rolagem.
class PageSwipe extends StatelessWidget {
  const PageSwipe({super.key, required this.controller, required this.child});

  final PageController controller;
  final Widget child;

  void _update(DragUpdateDetails d) {
    if (!controller.hasClients) return;
    final p = controller.position;
    final next = (p.pixels - d.delta.dx).clamp(p.minScrollExtent, p.maxScrollExtent);
    p.jumpTo(next.toDouble());
  }

  void _end(DragEndDetails d) {
    if (!controller.hasClients) return;
    final p = controller.position;
    final page = controller.page ?? 0;
    final v = d.primaryVelocity ?? 0;
    var target = page.round();
    if (v < -300) {
      target = page.floor() + 1;
    } else if (v > 300) {
      target = page.ceil() - 1;
    }
    final last = (p.maxScrollExtent / p.viewportDimension).round();
    target = math.max(0, math.min(last, target));
    controller.animateToPage(target,
        duration: const Duration(milliseconds: 280), curve: Curves.easeOutCubic);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onHorizontalDragUpdate: _update,
      onHorizontalDragEnd: _end,
      child: child,
    );
  }
}
