import 'package:flutter/material.dart';

/// Resposta de toque "de brinquedo": ao encostar o dedo o botão afunda um
/// pouquinho e, ao soltar, volta com um quique. Não bloqueia o toque do filho
/// (InkWell, GestureDetector...): só observa o ponteiro.
class Bouncy extends StatefulWidget {
  const Bouncy({super.key, required this.child, this.pressedScale = .93});

  final Widget child;
  final double pressedScale;

  @override
  State<Bouncy> createState() => _BouncyState();
}

class _BouncyState extends State<Bouncy> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 90),
    reverseDuration: const Duration(milliseconds: 420),
  );

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _down(PointerDownEvent _) {
    if (MediaQuery.maybeOf(context)?.disableAnimations ?? false) return;
    _c.forward();
  }

  void _up([PointerEvent? _]) {
    if (_c.value > 0) _c.reverse();
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: _down,
      onPointerUp: _up,
      onPointerCancel: _up,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, child) {
          // Afunda rápido; ao voltar usa elasticOut (passa um pouco e volta).
          final curve = _c.status == AnimationStatus.reverse
              ? Curves.elasticIn
              : Curves.easeOut;
          final k = curve.transform(_c.value);
          return Transform.scale(
              scale: 1 - (1 - widget.pressedScale) * k, child: child);
        },
        child: widget.child,
      ),
    );
  }
}

/// Leve flutuação contínua (sobe e desce devagar), para dar vida a cartões e
/// botões parados. [phase] desencontra os elementos de uma mesma tela.
class Floaty extends StatefulWidget {
  const Floaty(
      {super.key, required this.child, this.phase = 0, this.amplitude = 4});

  final Widget child;
  final double phase;
  final double amplitude;

  @override
  State<Floaty> createState() => _FloatyState();
}

class _FloatyState extends State<Floaty> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 3200));
  bool _started = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_started) return;
    _started = true;
    if (!(MediaQuery.maybeOf(context)?.disableAnimations ?? false)) _c.repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (context, child) {
        final v = Curves.easeInOut.transform(
            ((_c.value + widget.phase) % 1.0) < .5
                ? ((_c.value + widget.phase) % 1.0) * 2
                : 2 - ((_c.value + widget.phase) % 1.0) * 2);
        return Transform.translate(
            offset: Offset(0, (v - .5) * 2 * widget.amplitude), child: child);
      },
      child: widget.child,
    );
  }
}
