import 'package:flutter/material.dart';

import '../models/learning_item.dart';
import 'item_art.dart';

/// Cartão de animal/fruta na lista da categoria.
class LearningCard extends StatelessWidget {
  const LearningCard({super.key, required this.item, required this.accent, required this.onTap});

  final LearningItem item;
  final Color accent;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: '${item.pt}, ${item.en}',
      child: Material(
        color: Colors.white,
        elevation: 3,
        borderRadius: BorderRadius.circular(28),
        child: InkWell(
          borderRadius: BorderRadius.circular(28),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(8, 12, 8, 10),
            child: Column(
              children: [
                Expanded(
                  child: LayoutBuilder(
                    builder: (context, c) => ItemArt(
                      item: item,
                      size: c.biggest.shortestSide,
                    ),
                  ),
                ),
                const SizedBox(height: 6),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(item.pt,
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                ),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(item.en,
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: accent)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Faixa de cor cheia, para a lista do módulo de cores.
class ColorSwatchTile extends StatelessWidget {
  const ColorSwatchTile({super.key, required this.item, required this.onTap});

  final LearningItem item;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final fg = onColor(item.color);
    return Semantics(
      button: true,
      label: '${item.pt}, ${item.en}',
      child: Material(
        color: item.color,
        elevation: 3,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(28),
          side: BorderSide(color: fg.withOpacity(.25), width: 3),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(28),
          onTap: onTap,
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(item.pt.toUpperCase(),
                      style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: fg)),
                ),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(item.en.toUpperCase(),
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: fg)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Cor de texto com bom contraste sobre [background].
Color onColor(Color background) =>
    ThemeData.estimateBrightnessForColor(background) == Brightness.dark
        ? Colors.white
        : const Color(0xFF1E1B3A);
