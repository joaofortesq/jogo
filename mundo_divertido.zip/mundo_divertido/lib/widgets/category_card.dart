import 'package:flutter/material.dart';

import '../models/learning_item.dart';
import 'item_art.dart';

/// Opção grande da tela inicial.
class CategoryCard extends StatelessWidget {
  const CategoryCard({super.key, required this.category, required this.onTap});

  final Category category;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: category.titlePt,
      child: Material(
        color: category.accent,
        elevation: 4,
        borderRadius: BorderRadius.circular(32),
        child: InkWell(
          borderRadius: BorderRadius.circular(32),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(10, 12, 10, 12),
            child: Column(
              children: [
                Expanded(child: _Preview(category: category)),
                const SizedBox(height: 6),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(category.titlePt,
                      style: const TextStyle(
                          fontSize: 22, fontWeight: FontWeight.w900, color: Colors.white)),
                ),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(category.titleEn,
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white70)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Preview extends StatelessWidget {
  const _Preview({required this.category});
  final Category category;

  @override
  Widget build(BuildContext context) {
    final items = category.items;
    return LayoutBuilder(builder: (context, c) {
      final s = c.biggest.shortestSide;
      if (category.kind == CategoryKind.colors) {
        final dots = items.take(6).toList();
        return Center(
          child: Wrap(
            spacing: s * .06,
            runSpacing: s * .06,
            alignment: WrapAlignment.center,
            children: [
              for (final i in dots)
                Container(
                  width: s * .26,
                  height: s * .26,
                  decoration: BoxDecoration(
                    color: i.color,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 3),
                  ),
                ),
            ],
          ),
        );
      }
      return Stack(
        alignment: Alignment.center,
        children: [
          Positioned(left: s * .02, child: ItemArt(item: items[1], size: s * .62)),
          Positioned(right: s * .02, child: ItemArt(item: items[2], size: s * .62)),
          ItemArt(item: items[0], size: s * .78),
        ],
      );
    });
  }
}
