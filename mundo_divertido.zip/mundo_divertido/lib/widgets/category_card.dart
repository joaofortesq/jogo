import 'package:flutter/material.dart';

import '../models/learning_item.dart';
import 'bouncy.dart';
import 'glyph_character.dart';
import 'item_art.dart';
import 'paint_blob.dart';

/// Opção grande da tela inicial.
class CategoryCard extends StatelessWidget {
  const CategoryCard({super.key, required this.category, required this.onTap});

  final Category category;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final hsl = HSLColor.fromColor(category.accent);
    final top =
        hsl.withLightness((hsl.lightness + .12).clamp(0.0, 1.0)).toColor();
    final bottom =
        hsl.withLightness((hsl.lightness - .06).clamp(0.0, 1.0)).toColor();
    return Semantics(
      button: true,
      label: category.titlePt,
      child: Bouncy(
        child: DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(32),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [top, bottom],
            ),
            border: Border.all(color: Colors.white, width: 3),
            boxShadow: [
              BoxShadow(
                  color: bottom.withValues(alpha: .45),
                  blurRadius: 12,
                  offset: const Offset(0, 6)),
            ],
          ),
          child: Material(
            type: MaterialType.transparency,
            child: InkWell(
              borderRadius: BorderRadius.circular(30),
              onTap: onTap,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 12, 10, 12),
                child: Column(
                  children: [
                    Expanded(
                      child: Floaty(
                        phase: category.id.length * .21 % 1.0,
                        child: _Preview(category: category),
                      ),
                    ),
                    const SizedBox(height: 6),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(category.titlePt,
                          style: const TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                              color: Colors.white,
                              shadows: [
                                Shadow(
                                    color: Color(0x40000000),
                                    blurRadius: 3,
                                    offset: Offset(0, 2))
                              ])),
                    ),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(category.titleEn,
                          style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w800,
                              color: Color(0xE6FFFFFF))),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Preview extends StatelessWidget {
  const _Preview({required this.category});
  final Category category;

  @override
  Widget build(BuildContext context) {
    final items = category.items;
    return LayoutBuilder(builder: (context, c) {
      final s = c.biggest.shortestSide;
      if (category.kind == CategoryKind.colors) {
        final dots = items.take(3).toList();
        return Center(
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (var k = 0; k < dots.length; k++)
                  Transform.translate(
                    offset: Offset(0, k == 1 ? -s * .08 : 0),
                    child: PaintBlob(
                        color: dots[k].color,
                        size: s * (k == 1 ? .5 : .4),
                        phase: k * .3),
                  ),
              ],
            ),
          ),
        );
      }
      if (category.kind == CategoryKind.letters ||
          category.kind == CategoryKind.numbers) {
        // Letras: A B C. Números: 1 2 3.
        final shown = items
            .skip(category.kind == CategoryKind.numbers ? 1 : 0)
            .take(3)
            .toList();
        return Center(
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                for (final i in shown)
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: s * .03),
                    child: GlyphBlock(item: i, size: s * .46),
                  ),
              ],
            ),
          ),
        );
      }
      return Stack(
        alignment: Alignment.center,
        children: [
          Positioned(
              left: s * .02, child: ItemArt(item: items[1], size: s * .62)),
          Positioned(
              right: s * .02, child: ItemArt(item: items[2], size: s * .62)),
          ItemArt(item: items[0], size: s * .78),
        ],
      );
    });
  }
}
