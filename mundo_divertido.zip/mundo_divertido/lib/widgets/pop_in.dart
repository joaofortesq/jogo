import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Entrada animada (surge e cresce um pouquinho) com atraso proporcional ao
/// [index], para as listas "aparecerem" em sequência. Sem timers: usa um
/// único controlador com intervalos.
class PopIn extends StatefulWidget {
  const PopIn({super.key, required this.index, required this.child});

  final int index;
  final Widget child;

  @override
  State<PopIn> createState() => _PopInState();
}

class _PopInState extends State<PopIn> with SingleTickerProviderStateMixin {
  static const _durationMs = 450;

  late final AnimationController _c;
  late final Animation<double> _fade;
  late final Animation<double> _scale;
  bool _started = false;

  @override
  void initState() {
    super.initState();
    final delay = math.min(widget.index, 10) * 70;
    final total = _durationMs + delay;
    _c = AnimationController(vsync: this, duration: Duration(milliseconds: total));
    final begin = delay / total;
    _fade = CurvedAnimation(parent: _c, curve: Interval(begin, 1, curve: Curves.easeOut));
    // Começa em 85% (nunca em zero), então o toque funciona desde o início.
    _scale = Tween<double>(begin: .85, end: 1).animate(
      CurvedAnimation(parent: _c, curve: Interval(begin, 1, curve: Curves.easeOutBack)),
    );
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_started) return;
    _started = true;
    if (MediaQuery.of(context).disableAnimations) {
      _c.value = 1;
    } else {
      _c.forward();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: ScaleTransition(scale: _scale, child: widget.child),
    );
  }
}
