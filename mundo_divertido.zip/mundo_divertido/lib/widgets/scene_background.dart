import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../models/learning_item.dart';
import 'art_config.dart';

/// Cenário da categoria atrás do conteúdo; sem cenário, usa a cor de fundo.
class SceneBackground extends StatelessWidget {
  const SceneBackground({super.key, required this.category, required this.child});

  final Category category;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final scene = category.scene;
    return ColoredBox(
      color: category.background,
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (scene != null && ArtConfig.renderSvg)
            // Em cache: não é redesenhado a cada quadro das animações por cima.
            RepaintBoundary(
              child: ExcludeSemantics(
                child: SvgPicture.asset(scene, fit: BoxFit.cover, alignment: Alignment.bottomCenter),
              ),
            ),
          child,
        ],
      ),
    );
  }
}
