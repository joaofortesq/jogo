import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Gotinha de tinta com carinha: o "personagem" de cada cor. A borda ondula
/// devagar, os olhos piscam e a boca abre quando a cor está sendo falada.
class PaintBlob extends StatefulWidget {
  const PaintBlob({
    super.key,
    required this.color,
    required this.size,
    this.talking = false,
    this.face = true,
    this.phase = 0,
  });

  final Color color;
  final double size;
  final bool talking;
  final bool face;

  /// Desencontra o movimento de várias gotinhas na mesma tela (0 a 1).
  final double phase;

  @override
  State<PaintBlob> createState() => _PaintBlobState();
}

class _PaintBlobState extends State<PaintBlob>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 4));
  bool _started = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_started) return;
    _started = true;
    if (!(MediaQuery.maybeOf(context)?.disableAnimations ?? false)) _c.repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: SizedBox.square(
        dimension: widget.size,
        child: AnimatedBuilder(
          animation: _c,
          builder: (context, _) => CustomPaint(
            painter: PaintBlobPainter(
              color: widget.color,
              t: (_c.value + widget.phase) % 1.0,
              talking: widget.talking,
              face: widget.face,
            ),
          ),
        ),
      ),
    );
  }
}

class PaintBlobPainter extends CustomPainter {
  PaintBlobPainter({
    required this.color,
    required this.t,
    this.talking = false,
    this.face = true,
  });

  final Color color;
  final double t;
  final bool talking;
  final bool face;

  static double _s(double v, int k, [double ph = 0]) =>
      math.sin((v * k + ph) * 2 * math.pi);

  Path _blob(Size size) {
    final c = Offset(size.width / 2, size.height * .5);
    final r = size.shortestSide * .40;
    final path = Path();
    const n = 64;
    for (var i = 0; i <= n; i++) {
      final a = i / n * 2 * math.pi;
      // Ondulação lenta da borda (frequências inteiras: loop sem emenda).
      final wobble = 1 +
          .035 * math.sin(a * 3 + t * 2 * math.pi) +
          .025 * math.sin(a * 5 - t * 4 * math.pi) +
          (talking ? .03 * math.sin(a * 2 + t * 16 * math.pi) : 0);
      // Achatado embaixo, como uma gota pousada.
      final squash = math.sin(a) > 0 ? 1 - .10 * math.sin(a) : 1.0;
      final p = c +
          Offset(math.cos(a) * r * wobble * (1 + .04 * _s(t, 2)),
              math.sin(a) * r * wobble * squash * (1 - .04 * _s(t, 2)));
      if (i == 0) {
        path.moveTo(p.dx, p.dy);
      } else {
        path.lineTo(p.dx, p.dy);
      }
    }
    path.close();
    return path;
  }

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.shortestSide;
    final hsl = HSLColor.fromColor(color);
    final dark =
        hsl.withLightness((hsl.lightness * .72).clamp(0.0, 1.0)).toColor();
    final light = hsl
        .withLightness(
            (hsl.lightness + (1 - hsl.lightness) * .45).clamp(0.0, 1.0))
        .toColor();
    final isWhite = color.computeLuminance() > .85;

    // Sombra no chão
    canvas.drawOval(
      Rect.fromCenter(
          center: Offset(size.width / 2, size.height * .9),
          width: w * .62 * (1 - .05 * _s(t, 2)),
          height: w * .08),
      Paint()..color = const Color(0x22000000),
    );

    final blob = _blob(size);
    final bounds = blob.getBounds();
    canvas.drawPath(
      blob,
      Paint()
        ..shader = RadialGradient(
          center: const Alignment(-.35, -.45),
          radius: 1.0,
          colors: [light, color, dark],
          stops: const [0, .55, 1],
        ).createShader(bounds),
    );
    // Contorno suave (o branco precisa de borda para aparecer no fundo claro).
    canvas.drawPath(
      blob,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = w * (isWhite ? .025 : .015)
        ..color =
            isWhite ? const Color(0xFFB0BEC5) : dark.withValues(alpha: .6),
    );
    // Brilho
    canvas.drawOval(
      Rect.fromCenter(
          center: Offset(size.width * .37, size.height * .30),
          width: w * .16,
          height: w * .09),
      Paint()..color = Colors.white.withValues(alpha: .7),
    );
    canvas.drawCircle(Offset(size.width * .29, size.height * .37), w * .025,
        Paint()..color = Colors.white.withValues(alpha: .6));

    if (!face) return;
    final eyeY = size.height * .47;
    final eyeDx = w * .12;
    final cx = size.width / 2 + w * .01 * _s(t, 1);
    final blinkPhase = (t * 2) % 1.0;
    final blink = (blinkPhase > .92 && blinkPhase < .98)
        ? math.sin((blinkPhase - .92) / .06 * math.pi)
        : 0.0;
    final ink =
        color.computeLuminance() < .05 ? Colors.white : const Color(0xFF2B2A4C);
    for (final dx in [-eyeDx, eyeDx]) {
      final center = Offset(cx + dx, eyeY);
      final eyeH = w * .085 * (1 - blink * .9);
      canvas.drawOval(
          Rect.fromCenter(center: center, width: w * .085, height: eyeH),
          Paint()..color = Colors.white);
      canvas.drawOval(
          Rect.fromCenter(
              center: center.translate(w * .006, w * .008),
              width: w * .05,
              height: eyeH * .6),
          Paint()..color = const Color(0xFF2B2A4C));
      if (blink < .5) {
        canvas.drawCircle(center.translate(-w * .006, -w * .012), w * .012,
            Paint()..color = Colors.white);
      }
    }
    // Bochechas
    final cheek = Paint()
      ..color = const Color(0xFFFF7FA3).withValues(alpha: .45);
    canvas.drawOval(
        Rect.fromCenter(
            center: Offset(cx - w * .2, eyeY + w * .08),
            width: w * .08,
            height: w * .045),
        cheek);
    canvas.drawOval(
        Rect.fromCenter(
            center: Offset(cx + w * .2, eyeY + w * .08),
            width: w * .08,
            height: w * .045),
        cheek);
    // Boca
    final mouthC = Offset(cx, eyeY + w * .10);
    if (talking) {
      final open = .5 + .5 * _s(t, 16);
      canvas.drawOval(
          Rect.fromCenter(
              center: mouthC, width: w * .10, height: w * (.03 + .06 * open)),
          Paint()..color = const Color(0xFF4B2E43));
    } else {
      final smile = Path()
        ..moveTo(mouthC.dx - w * .06, mouthC.dy - w * .01)
        ..quadraticBezierTo(mouthC.dx, mouthC.dy + w * .05, mouthC.dx + w * .06,
            mouthC.dy - w * .01);
      canvas.drawPath(
          smile,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeCap = StrokeCap.round
            ..strokeWidth = w * .018
            ..color = ink);
    }
  }

  @override
  bool shouldRepaint(PaintBlobPainter old) =>
      old.t != t ||
      old.color != color ||
      old.talking != talking ||
      old.face != face;
}
