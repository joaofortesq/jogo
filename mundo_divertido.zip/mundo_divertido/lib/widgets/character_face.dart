import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Personagem provisório desenhado em código (corpo arredondado com rosto).
/// Será substituído pelas ilustrações SVG na Etapa 3, mantendo a mesma API.
class CharacterFace extends StatelessWidget {
  const CharacterFace({super.key, required this.color, this.blink = 0, this.size = 160});

  final Color color;

  /// 0 = olhos abertos, 1 = fechados.
  final double blink;
  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(painter: _FacePainter(color, blink)),
    );
  }
}

class _FacePainter extends CustomPainter {
  _FacePainter(this.color, this.blink);
  final Color color;
  final double blink;

  @override
  void paint(Canvas canvas, Size s) {
    final w = s.width, h = s.height;
    final hsl = HSLColor.fromColor(color);
    final outline = hsl
        .withLightness((hsl.lightness * 0.55).clamp(0.12, 0.6))
        .withSaturation((hsl.saturation + 0.1).clamp(0.0, 1.0))
        .toColor();
    final fill = Paint()..color = color;
    final stroke = Paint()
      ..color = outline
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.03
      ..strokeJoin = StrokeJoin.round;

    canvas.drawOval(Rect.fromLTWH(w * .18, h * .9, w * .64, h * .07),
        Paint()..color = Colors.black12);

    for (final cx in [.26, .74]) {
      final c = Offset(w * cx, h * .2);
      canvas.drawCircle(c, w * .11, fill);
      canvas.drawCircle(c, w * .11, stroke);
    }
    final body = RRect.fromRectAndRadius(
        Rect.fromLTWH(w * .08, h * .14, w * .84, h * .78), Radius.circular(w * .4));
    canvas.drawRRect(body, fill);
    canvas.drawRRect(body, stroke);

    final open = math.max(0.08, 1 - blink);
    for (final dx in [-1, 1]) {
      final c = Offset(w * .5 + dx * w * .17, h * .46);
      canvas.save();
      canvas.translate(c.dx, c.dy);
      canvas.scale(1, open);
      canvas.drawCircle(Offset.zero, w * .1, Paint()..color = Colors.white);
      canvas.drawCircle(Offset(dx * w * .012, 0), w * .06, Paint()..color = const Color(0xFF1E1B3A));
      canvas.drawCircle(Offset(dx * w * .012 + w * .02, -w * .02), w * .02, Paint()..color = Colors.white);
      canvas.restore();
    }
    final cheek = Paint()..color = const Color(0xFFFF7A9A).withOpacity(.45);
    canvas.drawCircle(Offset(w * .26, h * .6), w * .06, cheek);
    canvas.drawCircle(Offset(w * .74, h * .6), w * .06, cheek);

    final smile = Path()
      ..moveTo(w * .4, h * .62)
      ..quadraticBezierTo(w * .5, h * .74, w * .6, h * .62);
    canvas.drawPath(smile, stroke..strokeCap = StrokeCap.round);
  }

  @override
  bool shouldRepaint(_FacePainter old) => old.color != color || old.blink != blink;
}
