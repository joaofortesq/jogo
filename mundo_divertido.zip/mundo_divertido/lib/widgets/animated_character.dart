import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../models/learning_item.dart';
import 'art_config.dart';
import 'item_art.dart';
import 'motion_profile.dart';
import 'rig_animal.dart';

/// Personagem com respiração leve, piscar e reação ao toque.
/// Um único AnimationController cuida de respiração e piscar (leve para
/// celulares modestos); outro cuida da reação ao toque.
class AnimatedCharacter extends StatefulWidget {
  const AnimatedCharacter({
    super.key,
    required this.item,
    required this.reaction,
    required this.size,
    this.onTap,
    this.playingTag,
  });

  final LearningItem item;
  final ReactionStyle reaction;
  final double size;
  final VoidCallback? onTap;

  /// Tag do áudio em reprodução (AudioService.playingTag). Quando começa com
  /// o id do item, o personagem se anima como se estivesse falando.
  final ValueListenable<String?>? playingTag;

  @override
  State<AnimatedCharacter> createState() => _AnimatedCharacterState();
}

class _AnimatedCharacterState extends State<AnimatedCharacter>
    with TickerProviderStateMixin {
  late final AnimationController _idle =
      AnimationController(vsync: this, duration: const Duration(seconds: 4));
  late final AnimationController _react =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
  late final AnimationController _enter =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 550));
  bool _started = false;

  /// Verdadeiro enquanto o áudio deste item está tocando.
  final ValueNotifier<bool> _talking = ValueNotifier<bool>(false);

  /// Piscar (0 a 1). Só os olhos reagem a ele; o SVG fica em cache.
  final ValueNotifier<double> _blink = ValueNotifier<double>(0);

  @override
  void initState() {
    super.initState();
    _enter.forward();
    _idle.addListener(_updateBlink);
    widget.playingTag?.addListener(_syncTalking);
  }

  void _syncTalking() {
    final tag = widget.playingTag?.value;
    final t = tag != null && tag.startsWith('${widget.item.id}:');
    if (t != _talking.value) _talking.value = t;
  }

  /// Piscar rápido perto do fim de cada ciclo de 4 s.
  void _updateBlink() {
    final v = _idle.value;
    final b = (v > .9 && v < .96) ? math.sin((v - .9) / .06 * math.pi) : 0.0;
    if (b != _blink.value) _blink.value = b;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final reduce = MediaQuery.of(context).disableAnimations;
    if (reduce) {
      _idle.stop();
    } else if (!_started || !_idle.isAnimating) {
      _idle.repeat();
      _started = true;
    }
  }

  @override
  void dispose() {
    widget.playingTag?.removeListener(_syncTalking);
    _talking.dispose();
    _idle.removeListener(_updateBlink);
    _blink.dispose();
    _idle.dispose();
    _react.dispose();
    _enter.dispose();
    super.dispose();
  }

  void _handleTap() {
    _react.forward(from: 0);
    widget.onTap?.call();
  }

  @override
  Widget build(BuildContext context) {
    final rig = widget.item.rig;
    final useRig = rig != null && ArtConfig.renderSvg;
    return Semantics(
      button: true,
      label: '${widget.item.pt}. Toque para ouvir.',
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _handleTap,
        child: AnimatedBuilder(
          animation: Listenable.merge([_idle, _react, _enter, widget.playingTag]),
          // O desenho não é reconstruído a cada quadro: só transformado.
          child: useRig
              ? null
              : RepaintBoundary(
                  child: ItemArt(
                    item: widget.item,
                    size: widget.size,
                    blinkListenable: _blink,
                  ),
                ),
          builder: (context, child) {
            final t = _react.value;
            final enter = Curves.easeOutBack.transform(_enter.value);
            var dy = 0.0;
            var dx = 0.0;
            var scale = enter;
            var angle = 0.0;
            var sx = 1.0;
            var sy = 1.0;
            Widget body;
            if (useRig) {
              // Corpo inteiro: ao tocar o bicho dança um pouquinho.
              final pulse = math.sin(t * math.pi);
              body = RigAnimal(
                rig: rig!,
                size: widget.size,
                clock: _idle,
                talking: _talking,
                dance: _talking.value ? math.max(.55, pulse) : pulse,
              );
              switch (widget.reaction) {
                case ReactionStyle.wobble:
                  angle += math.sin(t * math.pi * 4) * .06 * (1 - t);
                case ReactionStyle.jump:
                  dy -= pulse * widget.size * .12;
                case ReactionStyle.spin:
                  angle += Curves.easeInOut.transform(t) * 2 * math.pi;
              }
            } else {
              final pose = poseFor(motionFor(widget.item.id), _idle.value, widget.size);
              final tag = widget.playingTag?.value;
              final talking = tag != null && tag.startsWith('${widget.item.id}:');
              final boost = talking ? talkingBoost(_idle.value, widget.size) : const MotionPose();
              dy = pose.dy + boost.dy;
              dx = pose.dx;
              angle = pose.angle;
              sx = pose.scaleX * boost.scaleX;
              sy = pose.scaleY * boost.scaleY;
              switch (widget.reaction) {
                case ReactionStyle.wobble:
                  angle += math.sin(t * math.pi * 4) * .14 * (1 - t);
                case ReactionStyle.jump:
                  dy -= math.sin(t * math.pi) * widget.size * .18;
                  scale += math.sin(t * math.pi) * .06;
                case ReactionStyle.spin:
                  angle += Curves.easeInOut.transform(t) * 2 * math.pi;
                  scale += math.sin(t * math.pi) * .08;
              }
              body = child!;
            }
            return Transform.translate(
              offset: Offset(dx, dy),
              child: Transform.rotate(
                angle: angle,
                child: Transform.scale(
                  scale: scale,
                  child: Transform.scale(
                    alignment: Alignment.bottomCenter,
                    scaleX: sx,
                    scaleY: sy,
                    child: body,
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
