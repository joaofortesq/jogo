import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'art_config.dart';

/// Cores e posições do céu ao longo do dia. [p] vai de 0 (dia limpo, sol alto)
/// a 1 (noite, lua alta).
class SkyPalette {
  SkyPalette._();

  static const _stops = <double>[0, .45, .62, .78, 1];
  static const _tops = <Color>[
    Color(0xFF5EC1FF),
    Color(0xFF72B7F2),
    Color(0xFFFF8F6B),
    Color(0xFF4B3F86),
    Color(0xFF111A45),
  ];
  static const _bottoms = <Color>[
    Color(0xFFDDF5FF),
    Color(0xFFFFE6B8),
    Color(0xFFFFCB8A),
    Color(0xFF9B5DA8),
    Color(0xFF2D3A7A),
  ];

  static Color _at(List<Color> colors, double p) {
    final x = p.clamp(0.0, 1.0).toDouble();
    for (var i = 0; i < _stops.length - 1; i++) {
      if (x <= _stops[i + 1]) {
        final t = (x - _stops[i]) / (_stops[i + 1] - _stops[i]);
        return Color.lerp(colors[i], colors[i + 1], t)!;
      }
    }
    return colors.last;
  }

  static Color top(double p) => _at(_tops, p);
  static Color bottom(double p) => _at(_bottoms, p);

  /// 0 de dia, 1 de noite: usado para trocar a cor dos textos e escurecer o app.
  static double nightness(double p) {
    final t = ((p - .55) / .4).clamp(0.0, 1.0).toDouble();
    return t * t * (3 - 2 * t);
  }

  /// Posição do sol (0 a 1 em x e y da tela) ou null quando já se pôs.
  static Offset? sun(double p) {
    final u = p / .68;
    if (u >= 1.08) return null;
    final x = .2 + .6 * u;
    final y = .17 + .55 * math.pow(u.clamp(0.0, 1.2), 1.7).toDouble();
    return Offset(x, y);
  }

  /// Posição da lua ou null enquanto ainda não nasceu.
  static Offset? moon(double p) {
    if (p < .58) return null;
    final v = ((p - .58) / .42).clamp(0.0, 1.0).toDouble();
    final x = .82 - .55 * v;
    final y = .74 - .58 * math.sin(v * math.pi / 2);
    return Offset(x, y);
  }
}

/// Céu que vai anoitecendo: sol, nuvens, pôr do sol, lua e estrelas.
class SkyBackdrop extends StatefulWidget {
  const SkyBackdrop({super.key, required this.progress});

  final double progress;

  @override
  State<SkyBackdrop> createState() => _SkyBackdropState();
}

class _SkyBackdropState extends State<SkyBackdrop> with SingleTickerProviderStateMixin {
  late final AnimationController _t =
      AnimationController(vsync: this, duration: const Duration(seconds: 90));
  bool _started = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_started) return;
    _started = true;
    if (ArtConfig.animateSky && !MediaQuery.of(context).disableAnimations) _t.repeat();
  }

  @override
  void dispose() {
    _t.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: AnimatedBuilder(
        animation: _t,
        builder: (context, _) => CustomPaint(
          painter: _SkyPainter(widget.progress, _t.value),
          size: Size.infinite,
        ),
      ),
    );
  }
}

class _SkyPainter extends CustomPainter {
  _SkyPainter(this.p, this.t);

  final double p;
  final double t;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final night = SkyPalette.nightness(p);

    // céu
    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [SkyPalette.top(p), SkyPalette.bottom(p)],
        ).createShader(Offset.zero & size),
    );

    // estrelas
    final starAlpha = ((p - .64) / .22).clamp(0.0, 1.0).toDouble();
    if (starAlpha > 0) {
      final rng = math.Random(11);
      for (var i = 0; i < 46; i++) {
        final x = rng.nextDouble() * w;
        final y = rng.nextDouble() * h * .62;
        final r = .9 + rng.nextDouble() * 1.8;
        final tw = .6 + .4 * math.sin((t * 90 / 3 + i) * 2 * math.pi / 4 + i);
        canvas.drawCircle(Offset(x, y), r,
            Paint()..color = Colors.white.withOpacity((starAlpha * tw).clamp(0.0, 1.0).toDouble()));
      }
    }

    // sol
    final sun = SkyPalette.sun(p);
    if (sun != null) {
      final c = Offset(sun.dx * w, sun.dy * h);
      final r = math.min(w, h) * .075;
      final warm = ((p - .35) / .3).clamp(0.0, 1.0).toDouble();
      final core = Color.lerp(const Color(0xFFFFD84A), const Color(0xFFFF8A3D), warm)!;
      canvas.drawCircle(
        c,
        r * 2.6,
        Paint()
          ..shader = RadialGradient(colors: [core.withOpacity(.45), core.withOpacity(0)])
              .createShader(Rect.fromCircle(center: c, radius: r * 2.6)),
      );
      // raios girando devagar
      final rays = Paint()
        ..color = core.withOpacity(.55)
        ..strokeWidth = 4
        ..strokeCap = StrokeCap.round;
      for (var i = 0; i < 12; i++) {
        final a = i * math.pi / 6 + t * 2 * math.pi;
        canvas.drawLine(c + Offset(math.cos(a), math.sin(a)) * (r * 1.3),
            c + Offset(math.cos(a), math.sin(a)) * (r * 1.65), rays);
      }
      canvas.drawCircle(c, r, Paint()..color = core);
    }

    // lua
    final moon = SkyPalette.moon(p);
    if (moon != null) {
      final c = Offset(moon.dx * w, moon.dy * h);
      final r = math.min(w, h) * .07;
      canvas.drawCircle(
        c,
        r * 2.4,
        Paint()
          ..shader = RadialGradient(
                  colors: [const Color(0xFFFFF6C8).withOpacity(.4 * night), const Color(0x00FFF6C8)])
              .createShader(Rect.fromCircle(center: c, radius: r * 2.4)),
      );
      canvas.drawCircle(c, r, Paint()..color = const Color(0xFFFFF3C4));
      final crater = Paint()..color = const Color(0xFFEBDCA0);
      canvas.drawCircle(c + Offset(-r * .3, -r * .25), r * .22, crater);
      canvas.drawCircle(c + Offset(r * .35, r * .1), r * .16, crater);
      canvas.drawCircle(c + Offset(-r * .1, r * .5), r * .12, crater);
    }

    // nuvens (somem de noite)
    final cloudAlpha = (1 - night * .85).clamp(0.0, 1.0).toDouble();
    const clouds = [
      [.10, .12, 1.0, 1.0],
      [.55, .24, .8, 1.6],
      [.80, .08, .9, 1.2],
      [.32, .36, .7, 2.0],
    ];
    for (final c in clouds) {
      final span = w + 220;
      final x = ((c[0] * span + t * c[3] * span * .9) % span) - 110;
      final y = c[1] * h;
      _cloud(canvas, Offset(x, y), 38 * c[2], Colors.white.withOpacity(.85 * cloudAlpha));
    }

    // morrinhos
    final hillA = Color.lerp(const Color(0xFF8FD694), const Color(0xFF1B3A4B), night)!;
    final hillB = Color.lerp(const Color(0xFF6CC47E), const Color(0xFF14303F), night)!;
    canvas.drawOval(Rect.fromCenter(center: Offset(w * .25, h * 1.0), width: w * 1.1, height: h * .26), Paint()..color = hillA);
    canvas.drawOval(Rect.fromCenter(center: Offset(w * .8, h * 1.02), width: w * 1.2, height: h * .24), Paint()..color = hillB);
  }

  void _cloud(Canvas canvas, Offset c, double s, Color color) {
    final paint = Paint()..color = color;
    canvas.drawCircle(c, s * .55, paint);
    canvas.drawCircle(c + Offset(s * .55, s * .12), s * .45, paint);
    canvas.drawCircle(c + Offset(-s * .55, s * .16), s * .4, paint);
    canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromCenter(center: c + Offset(0, s * .3), width: s * 2, height: s * .55), Radius.circular(s * .3)),
        paint);
  }

  @override
  bool shouldRepaint(_SkyPainter old) => old.p != p || old.t != t;
}

/// Escurece de leve todo o app conforme a noite chega.
class NightTint extends StatelessWidget {
  const NightTint({super.key, required this.progress});

  final double progress;

  @override
  Widget build(BuildContext context) {
    final a = SkyPalette.nightness(progress) * .26;
    if (a <= 0.001) return const SizedBox.shrink();
    return IgnorePointer(
      child: SizedBox.expand(child: ColoredBox(color: const Color(0xFF0B1240).withOpacity(a))),
    );
  }
}
