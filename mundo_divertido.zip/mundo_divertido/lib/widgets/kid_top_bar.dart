import 'package:flutter/material.dart';

class RoundIconButton extends StatelessWidget {
  const RoundIconButton({
    super.key,
    required this.icon,
    required this.label,
    required this.onPressed,
    this.background = Colors.white,
    this.foreground = const Color(0xFF2B2A4C),
  });

  final IconData icon;
  final String label;
  final VoidCallback onPressed;
  final Color background;
  final Color foreground;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: label,
      child: Material(
        color: background,
        shape: const CircleBorder(),
        elevation: 3,
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onPressed,
          child: SizedBox(
            width: 64,
            height: 64,
            child: Icon(icon, size: 36, color: foreground),
          ),
        ),
      ),
    );
  }
}

/// Barra superior: botão grande de voltar (opcional), título e botão de início.
class KidTopBar extends StatelessWidget {
  const KidTopBar({
    super.key,
    this.title,
    this.onBack,
    this.backIcon = Icons.arrow_back_rounded,
    this.backLabel = 'Voltar',
    this.foreground = const Color(0xFF2B2A4C),
  });

  final String? title;
  final VoidCallback? onBack;
  final IconData backIcon;
  final String backLabel;
  final Color foreground;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      child: Row(
        children: [
          if (onBack != null)
            RoundIconButton(icon: backIcon, label: backLabel, onPressed: onBack!),
          Expanded(
            child: Text(
              title ?? '',
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.w900,
                color: foreground,
              ),
            ),
          ),
          RoundIconButton(
            icon: Icons.home_rounded,
            label: 'Início',
            onPressed: () => Navigator.of(context).popUntil((r) => r.isFirst),
          ),
        ],
      ),
    );
  }
}
