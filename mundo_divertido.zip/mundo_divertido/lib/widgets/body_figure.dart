import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Quadro do desenho: 200 de largura por 300 de altura.
const Size kBodyFrame = Size(200, 300);

/// Criança de corpo inteiro (desenho próprio) com as partes que podem ser
/// tocadas. Cada parte tem uma área de toque; as pequenas (olhos, nariz,
/// boca) têm prioridade sobre as grandes (cabeça).
class BodyMap {
  BodyMap._();

  static Path _circle(double x, double y, double r) =>
      Path()..addOval(Rect.fromCircle(center: Offset(x, y), radius: r));

  static Path _oval(double cx, double cy, double w, double h) => Path()
    ..addOval(Rect.fromCenter(center: Offset(cx, cy), width: w, height: h));

  static Path _rrect(double l, double t, double w, double h, double r) => Path()
    ..addRRect(
        RRect.fromRectAndRadius(Rect.fromLTWH(l, t, w, h), Radius.circular(r)));

  static Path _union(List<Path> ps) =>
      ps.reduce((a, b) => Path.combine(PathOperation.union, a, b));

  /// Braço: retângulo arredondado inclinado, do ombro até o pulso.
  static Path _limb(Offset from, Offset to, double width) {
    final d = to - from;
    final len = d.distance;
    final angle = math.atan2(d.dy, d.dx) - math.pi / 2;
    final p = Path()
      ..addRRect(RRect.fromRectAndRadius(
          Rect.fromLTWH(-width / 2, 0, width, len),
          Radius.circular(width / 2)));
    final m = Matrix4.identity()
      ..translate(from.dx, from.dy)
      ..rotateZ(angle);
    return p.transform(m.storage);
  }

  // ---- desenho ----
  static final Path hairBack = _union([
    _oval(100, 66, 96, 92),
    _rrect(56, 66, 88, 40, 18),
  ]);
  static final Path earL = _circle(57, 78, 10);
  static final Path earR = _circle(143, 78, 10);
  static final Path face = _oval(100, 76, 82, 84);
  static final Path fringe = Path()
    ..moveTo(58, 66)
    ..quadraticBezierTo(62, 26, 100, 24)
    ..quadraticBezierTo(140, 24, 142, 66)
    ..quadraticBezierTo(128, 48, 112, 52)
    ..quadraticBezierTo(102, 40, 90, 52)
    ..quadraticBezierTo(74, 44, 58, 66)
    ..close();
  static final Path eyeL = _oval(85, 78, 11, 14);
  static final Path eyeR = _oval(115, 78, 11, 14);
  static final Path nose = _oval(100, 91, 9, 7);
  static final Path mouth = Path()
    ..moveTo(88, 101)
    ..quadraticBezierTo(100, 116, 112, 101)
    ..quadraticBezierTo(100, 105, 88, 101)
    ..close();
  static final Path neck = _rrect(91, 114, 18, 14, 4);
  static final Path armL =
      _limb(const Offset(70, 134), const Offset(44, 196), 17);
  static final Path armR =
      _limb(const Offset(130, 134), const Offset(156, 196), 17);
  static final Path handL = _circle(42, 202, 11);
  static final Path handR = _circle(158, 202, 11);
  static final Path shirt = _rrect(64, 124, 72, 78, 22);
  static final Path shorts = _rrect(68, 194, 64, 28, 8);
  static final Path legL = _rrect(75, 214, 20, 62, 9);
  static final Path legR = _rrect(105, 214, 20, 62, 9);
  static final Path footL = _oval(81, 281, 32, 15);
  static final Path footR = _oval(119, 281, 32, 15);

  // ---- áreas de toque (de cima para baixo na prioridade) ----
  static final Map<String, Path> hit = {
    'eyes': _union([_oval(85, 78, 20, 22), _oval(115, 78, 20, 22)]),
    'nose': _oval(100, 91, 16, 13),
    'mouth': _oval(100, 106, 30, 14),
    'ears': _union([_circle(55, 78, 13), _circle(145, 78, 13)]),
    'hair': _union(
        [fringe, Path.combine(PathOperation.difference, hairBack, face)]),
    'head': face,
    'neck': _rrect(88, 112, 24, 16, 4),
    'hands': _union([_circle(42, 202, 15), _circle(158, 202, 15)]),
    'shoulders': _union([_circle(72, 134, 13), _circle(128, 134, 13)]),
    'arms': _union([armL, armR]),
    'belly': _oval(100, 170, 56, 52),
    'knees': _union([_circle(85, 246, 12), _circle(115, 246, 12)]),
    'feet': _union([_oval(81, 281, 38, 20), _oval(119, 281, 38, 20)]),
    'legs': _union([legL, legR, shorts]),
  };

  /// Centro aproximado de cada parte (para o balão com o nome).
  static Offset anchor(String id) =>
      hit[id]?.getBounds().center ?? const Offset(100, 150);

  /// Um ponto que, tocado, cai nessa parte (procura dentro da área de toque).
  static Offset tapPoint(String id) {
    final b = hit[id]!.getBounds();
    final c = b.center;
    if (partAt(c) == id) return c;
    for (var y = b.top; y <= b.bottom; y += 1) {
      for (var x = b.left; x <= b.right; x += 1) {
        if (partAt(Offset(x, y)) == id) return Offset(x, y);
      }
    }
    return c;
  }

  /// Parte tocada no ponto [p] (coordenadas do quadro 200x300), ou null.
  static String? partAt(Offset p) {
    for (final e in hit.entries) {
      if (e.value.contains(p)) return e.key;
    }
    return null;
  }
}

/// Desenha a criança. [highlight] acende uma parte (brilho amarelo pulsando,
/// [pulse] de 0 a 1). [t] é o relógio da respiração/piscar (0 a 1).
class BodyPainter extends CustomPainter {
  BodyPainter({this.highlight, this.pulse = 0, this.t = 0, this.hint});

  final String? highlight;
  final double pulse;
  final double t;

  /// Parte que pisca de leve como dica (jogo, depois de dois erros).
  final String? hint;

  static const skin = Color(0xFFF2C29B);
  static const skinDark = Color(0xFFE0A47C);
  static const hairColor = Color(0xFF5B3A29);
  static const shirtColor = Color(0xFFFF7A59);
  static const shortsColor = Color(0xFF3F7CDB);
  static const shoeColor = Color(0xFF2E3A59);
  static const ink = Color(0xFF2B2A4C);

  @override
  void paint(Canvas canvas, Size size) {
    final k = math.min(
        size.width / kBodyFrame.width, size.height / kBodyFrame.height);
    canvas.save();
    canvas.translate((size.width - kBodyFrame.width * k) / 2,
        (size.height - kBodyFrame.height * k) / 2);
    canvas.scale(k);

    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2
      ..strokeJoin = StrokeJoin.round
      ..strokeCap = StrokeCap.round
      ..color = ink;
    void fill(Path p, Color c, {bool outline = true}) {
      canvas.drawPath(p, Paint()..color = c);
      if (outline) canvas.drawPath(p, line);
    }

    // sombra no chão
    canvas.drawOval(
        Rect.fromCenter(center: const Offset(100, 292), width: 110, height: 10),
        Paint()..color = const Color(0x22000000));

    // respiração: o tronco sobe e desce um pouquinho
    final breath = math.sin(t * 2 * math.pi) * 1.2;

    fill(BodyMap.legL, skin);
    fill(BodyMap.legR, skin);
    // joelhos (risquinho)
    for (final x in [85.0, 115.0]) {
      canvas.drawArc(
          Rect.fromCenter(center: Offset(x, 246), width: 10, height: 6),
          .3,
          2.5,
          false,
          line..strokeWidth = 1.6);
    }
    line.strokeWidth = 2.2;
    fill(BodyMap.footL, shoeColor);
    fill(BodyMap.footR, shoeColor);
    fill(BodyMap.shorts, shortsColor);

    canvas.save();
    canvas.translate(0, -breath);
    fill(BodyMap.armL, skin);
    fill(BodyMap.armR, skin);
    fill(BodyMap.handL, skin);
    fill(BodyMap.handR, skin);
    fill(BodyMap.shirt, shirtColor);
    // mangas
    fill(
        Path()
          ..addOval(Rect.fromCircle(center: const Offset(72, 136), radius: 13)),
        shirtColor);
    fill(
        Path()
          ..addOval(
              Rect.fromCircle(center: const Offset(128, 136), radius: 13)),
        shirtColor);
    canvas.drawPath(BodyMap.shirt, Paint()..color = shirtColor);
    // estrela na camiseta e umbigo
    _star(canvas, const Offset(100, 152), 10, const Color(0xFFFFD54F));
    canvas.drawCircle(
        const Offset(100, 182), 1.8, Paint()..color = const Color(0x55000000));
    fill(BodyMap.neck, skin);
    // gola
    canvas.drawArc(
        Rect.fromCenter(center: const Offset(100, 126), width: 26, height: 12),
        0,
        math.pi,
        false,
        line);

    // cabeça
    fill(BodyMap.hairBack, hairColor);
    fill(BodyMap.earL, skin);
    fill(BodyMap.earR, skin);
    fill(BodyMap.face, skin);
    fill(BodyMap.fringe, hairColor);
    // bochechas
    final cheek = Paint()..color = const Color(0x55FF6F91);
    canvas.drawOval(
        Rect.fromCenter(center: const Offset(76, 96), width: 14, height: 8),
        cheek);
    canvas.drawOval(
        Rect.fromCenter(center: const Offset(124, 96), width: 14, height: 8),
        cheek);
    // olhos (piscam)
    final blinkPhase = (t * 2) % 1.0;
    final blink = (blinkPhase > .93 && blinkPhase < .99)
        ? math.sin((blinkPhase - .93) / .06 * math.pi)
        : 0.0;
    for (final x in [85.0, 115.0]) {
      final r = Rect.fromCenter(
          center: Offset(x, 78), width: 11, height: 14 * (1 - blink * .9));
      canvas.drawOval(r, Paint()..color = ink);
      if (blink < .5)
        canvas.drawCircle(
            Offset(x - 2, 74), 2.2, Paint()..color = Colors.white);
    }
    canvas.drawPath(BodyMap.nose, Paint()..color = skinDark);
    fill(BodyMap.mouth, const Color(0xFFD94C6A));
    canvas.restore();

    // ---- destaque ----
    for (final (id, strength) in [(hint, .5), (highlight, 1.0)]) {
      if (id == null) continue;
      final path = BodyMap.hit[id];
      if (path == null) continue;
      final p = Curves.easeInOut.transform(pulse);
      canvas.drawPath(
          path,
          Paint()
            ..color = const Color(0xFFFFEB3B)
                .withValues(alpha: (.25 + .25 * p) * strength)
            ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3));
      canvas.drawPath(
          path,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 3 + 2 * p
            ..color = const Color(0xFFFFC107).withValues(alpha: strength));
    }
    canvas.restore();
  }

  void _star(Canvas canvas, Offset c, double r, Color color) {
    final p = Path();
    for (var i = 0; i < 10; i++) {
      final a = -math.pi / 2 + i * math.pi / 5;
      final rr = i.isEven ? r : r * .45;
      final pt = c + Offset(math.cos(a) * rr, math.sin(a) * rr);
      if (i == 0) {
        p.moveTo(pt.dx, pt.dy);
      } else {
        p.lineTo(pt.dx, pt.dy);
      }
    }
    p.close();
    canvas.drawPath(p, Paint()..color = color);
  }

  @override
  bool shouldRepaint(BodyPainter old) =>
      old.highlight != highlight ||
      old.pulse != pulse ||
      old.t != t ||
      old.hint != hint;
}

/// Converte um ponto tocado no widget de tamanho [size] para o quadro 200x300.
Offset toBodyFrame(Offset local, Size size) {
  final k =
      math.min(size.width / kBodyFrame.width, size.height / kBodyFrame.height);
  final ox = (size.width - kBodyFrame.width * k) / 2;
  final oy = (size.height - kBodyFrame.height * k) / 2;
  return Offset((local.dx - ox) / k, (local.dy - oy) / k);
}

/// Converte um ponto do quadro 200x300 para o widget de tamanho [size].
Offset fromBodyFrame(Offset p, Size size) {
  final k =
      math.min(size.width / kBodyFrame.width, size.height / kBodyFrame.height);
  final ox = (size.width - kBodyFrame.width * k) / 2;
  final oy = (size.height - kBodyFrame.height * k) / 2;
  return Offset(ox + p.dx * k, oy + p.dy * k);
}

/// A criança animada (respira e pisca) com uma parte acesa opcional.
class BodyFigure extends StatefulWidget {
  const BodyFigure({super.key, this.highlight, this.hint, this.onPart});

  final String? highlight;
  final String? hint;
  final ValueChanged<String>? onPart;

  @override
  State<BodyFigure> createState() => _BodyFigureState();
}

class _BodyFigureState extends State<BodyFigure> with TickerProviderStateMixin {
  late final AnimationController _clock =
      AnimationController(vsync: this, duration: const Duration(seconds: 4));
  late final AnimationController _pulse = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 650));
  bool _started = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_started) return;
    _started = true;
    if (!(MediaQuery.maybeOf(context)?.disableAnimations ?? false)) {
      _clock.repeat();
      _pulse.repeat(reverse: true);
    }
  }

  @override
  void dispose() {
    _clock.dispose();
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final size = c.biggest;
      return GestureDetector(
        key: const ValueKey('body-figure'),
        behavior: HitTestBehavior.opaque,
        onTapDown: widget.onPart == null
            ? null
            : (d) {
                final part = BodyMap.partAt(toBodyFrame(d.localPosition, size));
                if (part != null) widget.onPart!(part);
              },
        child: RepaintBoundary(
          child: AnimatedBuilder(
            animation: Listenable.merge([_clock, _pulse]),
            builder: (context, _) => CustomPaint(
              size: size,
              painter: BodyPainter(
                highlight: widget.highlight,
                hint: widget.hint,
                pulse: _pulse.value,
                t: _clock.value,
              ),
            ),
          ),
        ),
      );
    });
  }
}
