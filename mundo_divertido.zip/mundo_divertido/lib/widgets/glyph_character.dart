import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../models/learning_item.dart';

/// Versão mais escura de [c] (contorno do bloquinho).
Color glyphOutline(Color c) {
  final hsl = HSLColor.fromColor(c);
  return hsl.withLightness((hsl.lightness * 0.55).clamp(0.1, 0.6)).toColor();
}

/// Cor do símbolo sobre o bloquinho: branco, ou escuro se o bloco for claro.
Color glyphOnBlock(Color c) =>
    c.computeLuminance() > .5 ? const Color(0xFF1E1B3A) : Colors.white;

/// Cor do símbolo sobre fundo branco (botões de resposta dos jogos).
Color glyphInk(Color c) {
  if (c.computeLuminance() <= .35) return c;
  final hsl = HSLColor.fromColor(c);
  return hsl.withLightness((hsl.lightness * 0.62).clamp(0.1, 0.5)).toColor();
}

/// Bloquinho simples (sem rosto e sem animação) com a letra ou o número.
/// Usado nas listas, nos cartões da tela inicial e nas opções dos jogos.
class GlyphBlock extends StatelessWidget {
  const GlyphBlock({super.key, required this.item, required this.size});

  final LearningItem item;
  final double size;

  @override
  Widget build(BuildContext context) {
    final glyph = item.glyph ?? item.pt;
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      padding: EdgeInsets.all(size * .08),
      decoration: BoxDecoration(
        color: item.color,
        borderRadius: BorderRadius.circular(size * .24),
        border: Border.all(color: glyphOutline(item.color), width: math.max(2.0, size * .03)),
      ),
      child: FittedBox(
        fit: BoxFit.scaleDown,
        child: Text(
          glyph,
          style: TextStyle(
            fontSize: size * .55,
            fontWeight: FontWeight.w900,
            color: glyphOnBlock(item.color),
            height: 1.0,
          ),
        ),
      ),
    );
  }
}

/// Bloquinho com rosto: respira, pisca, pula ao toque e mexe a boca quando
/// a letra ou o número está sendo falado (tag do áudio começa com o id).
class GlyphCharacter extends StatefulWidget {
  const GlyphCharacter({
    super.key,
    required this.item,
    required this.reaction,
    required this.size,
    this.onTap,
    this.playingTag,
  });

  final LearningItem item;
  final ReactionStyle reaction;
  final double size;
  final VoidCallback? onTap;

  /// AudioService.playingTag: quando começa com "<id>:", o bloquinho fala.
  final ValueListenable<String?>? playingTag;

  @override
  State<GlyphCharacter> createState() => _GlyphCharacterState();
}

class _GlyphCharacterState extends State<GlyphCharacter> with TickerProviderStateMixin {
  late final AnimationController _idle =
      AnimationController(vsync: this, duration: const Duration(seconds: 4));
  late final AnimationController _react =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
  late final AnimationController _enter =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 900));

  final ValueNotifier<double> _blink = ValueNotifier<double>(0);
  final ValueNotifier<bool> _talking = ValueNotifier<bool>(false);
  bool _started = false;

  @override
  void initState() {
    super.initState();
    _enter.forward();
    _idle.addListener(_updateBlink);
    widget.playingTag?.addListener(_syncTalking);
  }

  void _syncTalking() {
    final tag = widget.playingTag?.value;
    final t = tag != null && tag.startsWith('${widget.item.id}:');
    if (t != _talking.value) _talking.value = t;
  }

  void _updateBlink() {
    final v = _idle.value;
    final b = (v > .9 && v < .96) ? math.sin((v - .9) / .06 * math.pi) : 0.0;
    if (b != _blink.value) _blink.value = b;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final reduce = MediaQuery.of(context).disableAnimations;
    if (reduce) {
      _idle.stop();
    } else if (!_started || !_idle.isAnimating) {
      _idle.repeat();
      _started = true;
    }
  }

  @override
  void dispose() {
    widget.playingTag?.removeListener(_syncTalking);
    _idle.removeListener(_updateBlink);
    _talking.dispose();
    _blink.dispose();
    _idle.dispose();
    _react.dispose();
    _enter.dispose();
    super.dispose();
  }

  void _handleTap() {
    _react.forward(from: 0);
    widget.onTap?.call();
  }

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    final size = widget.size;
    final glyph = item.glyph ?? item.pt;
    final outline = glyphOutline(item.color);
    final fg = glyphOnBlock(item.color);
    return Semantics(
      button: true,
      label: '${item.pt}. Toque para ouvir.',
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _handleTap,
        child: AnimatedBuilder(
          animation: Listenable.merge([_idle, _react, _enter, _talking]),
          builder: (context, child) {
            final t = _react.value;
            // Entrada com elasticidade (mola) ao abrir a letra ou o número.
            final enter = Curves.elasticOut.transform(_enter.value);
            final v = _idle.value;
            final p = v * 2 * math.pi;
            // Balanço leve de quem está parado.
            var dy = -math.sin(p * 2).abs() * size * .03;
            var angle = math.sin(p) * .02;
            var sx = 1 - math.sin(p * 4) * .012;
            var sy = 1 + math.sin(p * 4) * .02;
            var scale = enter;
            if (_talking.value) {
              final s = math.sin(p * 8);
              dy -= s.abs() * size * .035;
              sx *= 1 - s * .02;
              sy *= 1 + s * .035;
            }
            switch (widget.reaction) {
              case ReactionStyle.wobble:
                angle += math.sin(t * math.pi * 4) * .16 * (1 - t);
              case ReactionStyle.jump:
                dy -= math.sin(t * math.pi) * size * .18;
                scale += math.sin(t * math.pi) * .06;
              case ReactionStyle.spin:
                angle += Curves.easeInOut.transform(t) * 2 * math.pi;
                scale += math.sin(t * math.pi) * .08;
            }
            return Transform.translate(
              offset: Offset(0, dy),
              child: Transform.rotate(
                angle: angle,
                child: Transform.scale(
                  scale: scale,
                  child: Transform.scale(
                    alignment: Alignment.bottomCenter,
                    scaleX: sx,
                    scaleY: sy,
                    child: child,
                  ),
                ),
              ),
            );
          },
          child: RepaintBoundary(
            child: Container(
              width: size,
              height: size,
              decoration: BoxDecoration(
                color: item.color,
                borderRadius: BorderRadius.circular(size * .22),
                border: Border.all(color: outline, width: size * .03),
                boxShadow: const [
                  BoxShadow(color: Color(0x33000000), blurRadius: 12, offset: Offset(0, 7)),
                ],
              ),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Positioned.fill(
                    child: CustomPaint(
                      painter: _GlyphFacePainter(_blink, _talking, _idle, _react),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: size * .36, left: size * .06, right: size * .06, bottom: size * .04),
                    child: Center(
                      child: FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text(
                          glyph,
                          style: TextStyle(
                            fontSize: size * .5,
                            fontWeight: FontWeight.w900,
                            color: fg,
                            height: 1.0,
                            shadows: [
                              Shadow(color: outline.withOpacity(.55), offset: Offset(0, size * .02)),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Olhos que piscam, bochechas e boca (abre e fecha enquanto fala).
class _GlyphFacePainter extends CustomPainter {
  _GlyphFacePainter(this.blink, this.talking, this.clock, this.react)
      : super(repaint: Listenable.merge([blink, talking, clock, react]));

  final ValueListenable<double> blink;
  final ValueListenable<bool> talking;
  final Animation<double> clock;

  /// Reação ao toque (0 a 1): no começo o bloquinho se surpreende (boca em "O").
  final Animation<double> react;

  @override
  void paint(Canvas canvas, Size s) {
    final w = s.width;
    final h = s.height;
    final open = math.max(0.08, 1 - blink.value);
    final r = react.value;
    final surprised = r > 0 && r < .4;
    // Parado, os olhos passeiam devagar de um lado a outro (espera).
    final look = (talking.value || surprised)
        ? 0.0
        : math.sin(clock.value * 2 * math.pi) * w * .014;
    for (final dx in const [-1.0, 1.0]) {
      canvas.save();
      canvas.translate(w * .5 + dx * w * .17, h * .17);
      canvas.scale(1, open);
      canvas.drawCircle(Offset.zero, w * (surprised ? .085 : .075), Paint()..color = Colors.white);
      canvas.drawCircle(Offset(dx * w * .01 + look, w * .005), w * .045, Paint()..color = const Color(0xFF1E1B3A));
      canvas.drawCircle(Offset(dx * w * .01 + look + w * .016, -w * .012), w * .014, Paint()..color = Colors.white);
      canvas.restore();
    }
    final cheek = Paint()..color = const Color(0xFFFF7A9A).withOpacity(.5);
    canvas.drawCircle(Offset(w * .26, h * .27), w * .045, cheek);
    canvas.drawCircle(Offset(w * .74, h * .27), w * .045, cheek);

    final mouth = Offset(w * .5, h * .285);
    if (surprised) {
      canvas.drawOval(Rect.fromCenter(center: mouth, width: w * .08, height: w * .09),
          Paint()..color = const Color(0xFF5A1E2E));
    } else if (talking.value) {
      final m = (math.sin(clock.value * 2 * math.pi * 12) + 1) / 2;
      final rect = Rect.fromCenter(center: mouth, width: w * .13, height: w * (.03 + .065 * m));
      canvas.drawOval(rect, Paint()..color = const Color(0xFF5A1E2E));
    } else {
      final smile = Path()
        ..moveTo(w * .43, h * .275)
        ..quadraticBezierTo(w * .5, h * .335, w * .57, h * .275);
      canvas.drawPath(
        smile,
        Paint()
          ..color = const Color(0xFF3B1F2B)
          ..style = PaintingStyle.stroke
          ..strokeWidth = w * .022
          ..strokeCap = StrokeCap.round,
      );
    }
  }

  @override
  bool shouldRepaint(_GlyphFacePainter old) =>
      old.blink != blink || old.talking != talking || old.clock != clock || old.react != react;
}
