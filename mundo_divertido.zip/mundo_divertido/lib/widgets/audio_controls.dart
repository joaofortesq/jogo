import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/learning_item.dart';
import '../services/audio_service.dart';

/// Executa um áudio e, se a voz do aparelho não estiver instalada, avisa
/// de forma discreta (a mensagem é para o adulto).
Future<void> runAudio(BuildContext context, Future<AudioOutcome> future) async {
  final messenger = ScaffoldMessenger.of(context);
  final outcome = await future;
  if (outcome == AudioOutcome.voiceMissing) {
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(const SnackBar(
        content: Text('Falta a voz do aparelho. Peça a um adulto: Ajustes > '
            'Texto para voz > instalar português e inglês.'),
        duration: Duration(seconds: 5),
      ));
  }
}

/// Botão "Som" (só animais) e botão "Falar", que diz o nome em português e
/// depois em inglês. Tocar de novo reinicia o áudio sem empilhar reproduções.
class AudioControls extends StatelessWidget {
  const AudioControls({super.key, required this.item, required this.accent});

  final LearningItem item;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    final audio = context.read<AudioService>();
    return ValueListenableBuilder<String?>(
      valueListenable: audio.playingTag,
      builder: (context, tag, _) {
        final speaking = tag == '${item.id}:pt' || tag == '${item.id}:en';
        return Row(
          children: [
            if (item.hasAnimalSound) ...[
              Expanded(
                child: _ControlButton(
                  icon: Icons.volume_up_rounded,
                  label: 'Som',
                  accent: accent,
                  active: tag == '${item.id}:sfx',
                  onTap: () => runAudio(context, audio.playSound(item)),
                ),
              ),
              const SizedBox(width: 12),
            ],
            Expanded(
              child: _ControlButton(
                icon: Icons.record_voice_over_rounded,
                label: 'Falar',
                accent: accent,
                active: speaking,
                onTap: () => runAudio(context, audio.playWords(item)),
              ),
            ),
          ],
        );
      },
    );
  }
}

class _ControlButton extends StatelessWidget {
  const _ControlButton({
    required this.icon,
    required this.label,
    required this.accent,
    required this.active,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final Color accent;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final fg = active ? Colors.white : const Color(0xFF2B2A4C);
    return Semantics(
      button: true,
      label: label,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        decoration: BoxDecoration(
          color: active ? accent : Colors.white,
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: accent, width: 3),
          boxShadow: const [
            BoxShadow(color: Color(0x33000000), blurRadius: 6, offset: Offset(0, 3)),
          ],
        ),
        child: Material(
          type: MaterialType.transparency,
          child: InkWell(
            borderRadius: BorderRadius.circular(26),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 14),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(active ? Icons.graphic_eq_rounded : icon, size: 34, color: fg),
                  const SizedBox(height: 4),
                  FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(label,
                        style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: fg)),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
