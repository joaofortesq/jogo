import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/settings_service.dart';
import '../services/usage_service.dart';
import '../version.dart';

/// Área dos responsáveis: volume, sons e tempo de uso por dia.
class ParentsSheet extends StatelessWidget {
  const ParentsSheet({super.key});

  static const limits = [0, 10, 15, 20, 30, 45, 60];

  static String _min(int seconds) => '${(seconds / 60).ceil()} min';

  String _status(SettingsService s, UsageService u) {
    if (!u.hasLimit) return 'Sem limite de tempo.';
    final used = (u.usedSeconds / 60).floor();
    final left = u.remainingSeconds;
    if (u.bedtime) return 'Hoje já usou os ${s.limitMinutes} min. Está na hora de dormir.';
    return 'Hoje: usou $used de ${s.limitMinutes} min (faltam ${_min(left)}).';
  }

  @override
  Widget build(BuildContext context) {
    return Consumer2<SettingsService, UsageService>(
      builder: (context, s, u, _) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Área dos responsáveis',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 16),
              const Text('Volume', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              Slider(value: s.volume, onChanged: s.setVolume),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Silenciar sons de animais e efeitos',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                subtitle: const Text('As pronúncias continuam tocando.'),
                value: s.effectsMuted,
                onChanged: s.setEffectsMuted,
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Falar a letra ao abrir',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                subtitle: const Text('Português e depois inglês, uma de cada vez.'),
                value: s.autoSpeakLetters,
                onChanged: s.setAutoSpeakLetters,
              ),
              const Divider(height: 28),
              const Text('Tempo de uso por dia',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              const Text('O céu vai anoitecendo e, no fim, o gatinho ou o cachorrinho vai dormir.'),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  for (final m in limits)
                    ChoiceChip(
                      label: Text(m == 0 ? 'Sem limite' : '$m min'),
                      selected: s.limitMinutes == m,
                      onSelected: (_) => s.setLimitMinutes(m),
                    ),
                ],
              ),
              const SizedBox(height: 8),
              Text(_status(s, u), style: const TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 16),
              const Text('Quando o tempo acabar',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              SegmentedButton<EndMode>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(value: EndMode.sleepScreen, label: Text('Tela de dormir')),
                  ButtonSegment(value: EndMode.closeApp, label: Text('Fechar o app')),
                ],
                selected: {s.endMode},
                onSelectionChanged: (v) => s.setEndMode(v.first),
              ),
              const SizedBox(height: 16),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  FilledButton.tonal(
                    onPressed: u.hasLimit ? () => u.addTime(const Duration(minutes: 10)) : null,
                    child: const Text('+10 minutos hoje'),
                  ),
                  FilledButton.tonal(
                    onPressed: u.hasLimit ? u.resetToday : null,
                    child: const Text('Reiniciar o dia'),
                  ),
                  OutlinedButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                      u.startDemo();
                    },
                    child: const Text('Ver o céu mudar (teste)'),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Text('Versão do app: $kBuildVersion',
                  style: TextStyle(color: Colors.black45, fontSize: 13)),
            ],
          ),
        ),
      ),
    );
  }
}
