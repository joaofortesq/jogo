import 'package:flutter/material.dart';

/// Paleta própria: céu, grama, sol, amora e uva sobre um fundo azul-menta.
class AppColors {
  static const sky = Color(0xFF4FB8F0);
  static const grass = Color(0xFF3DAA5C);
  static const sun = Color(0xFFFFC93C);
  static const berry = Color(0xFFE5486B);
  static const grape = Color(0xFF7C5CFF);
  static const ink = Color(0xFF2B2A4C);
  static const mintTop = Color(0xFFD6F1FF);
  static const mintBottom = Color(0xFFE9FFE4);
}

ThemeData buildTheme() {
  final base = ColorScheme.fromSeed(
    seedColor: AppColors.sky,
    brightness: Brightness.light,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: base,
    scaffoldBackgroundColor: AppColors.mintTop,
    textTheme: ThemeData.light().textTheme.apply(
          bodyColor: AppColors.ink,
          displayColor: AppColors.ink,
        ),
    snackBarTheme: const SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: AppColors.ink,
      contentTextStyle: TextStyle(fontSize: 18, color: Colors.white),
    ),
  );
}
