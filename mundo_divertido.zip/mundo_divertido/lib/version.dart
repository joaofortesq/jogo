/// Versão do código (mesma de VERSION.txt). Aparece na área dos responsáveis
/// para conferir qual zip foi usado para gerar o APK.
const String kBuildVersion = '20261013-2210';
