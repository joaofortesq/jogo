import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui';

/// Uma parte do desenho que pode ser pintada (coordenadas num quadro 200x200).
class PaintRegion {
  const PaintRegion(this.id, this.path);

  final String id;
  final Path path;
}

/// Desenho para colorir: partes pintáveis (de baixo para cima) e detalhes
/// fixos (olhos, antenas...) desenhados por cima.
class PaintPicture {
  const PaintPicture({
    required this.id,
    required this.pt,
    required this.en,
    required this.regions,
    this.details,
  });

  final String id;
  final String pt;
  final String en;
  final List<PaintRegion> regions;

  /// Desenha os detalhes; recebe o canvas já na escala do quadro 200x200.
  final void Function(Canvas canvas, Paint ink)? details;

  /// Parte de cima que contém o ponto (ou -1).
  int hitTest(Offset p) {
    for (var i = regions.length - 1; i >= 0; i--) {
      if (regions[i].path.contains(p)) return i;
    }
    return -1;
  }
}

Path _circle(double x, double y, double r) =>
    Path()..addOval(Rect.fromCircle(center: Offset(x, y), radius: r));

Path _oval(double cx, double cy, double w, double h, [double angle = 0]) {
  final p = Path()
    ..addOval(Rect.fromCenter(center: Offset(cx, cy), width: w, height: h));
  if (angle == 0) return p;
  final c = math.cos(angle), s = math.sin(angle);
  // gira em volta do centro
  final m = Float64List.fromList([
    c, s, 0, 0, //
    -s, c, 0, 0, //
    0, 0, 1, 0, //
    cx - c * cx + s * cy, cy - s * cx - c * cy, 0, 1,
  ]);
  return p.transform(m);
}

Path _rect(double l, double t, double w, double h, [double r = 0]) => Path()
  ..addRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(l, t, w, h), Radius.circular(r)));

Path _poly(List<double> xy) {
  final p = Path()..moveTo(xy[0], xy[1]);
  for (var i = 2; i < xy.length; i += 2) {
    p.lineTo(xy[i], xy[i + 1]);
  }
  return p..close();
}

Path _union(List<Path> paths) =>
    paths.reduce((a, b) => Path.combine(PathOperation.union, a, b));

Path _cloud(double x, double y, double s) => _union([
      _circle(x - 12 * s, y + 2 * s, 10 * s),
      _circle(x, y - 4 * s, 13 * s),
      _circle(x + 13 * s, y + 2 * s, 10 * s),
      _rect(x - 20 * s, y + 2 * s, 42 * s, 10 * s, 5 * s),
    ]);

List<PaintPicture>? _cache;

/// Os desenhos (criados uma vez só).
List<PaintPicture> get paintPictures => _cache ??= _build();

List<PaintPicture> _build() {
  final house = PaintPicture(
    id: 'house',
    pt: 'Casinha',
    en: 'House',
    regions: [
      PaintRegion('grass', _rect(0, 165, 200, 35, 6)),
      PaintRegion('sun', _circle(165, 34, 18)),
      PaintRegion('cloud', _cloud(48, 34, 1.1)),
      PaintRegion('chimney', _rect(128, 50, 18, 34)),
      PaintRegion('roof', _poly([28, 94, 100, 40, 172, 94])),
      PaintRegion('wall', _rect(42, 94, 116, 71)),
      PaintRegion('door', _rect(88, 118, 26, 47, 6)),
      PaintRegion('window1', _rect(54, 106, 26, 22, 4)),
      PaintRegion('window2', _rect(122, 106, 26, 22, 4)),
    ],
    details: (canvas, ink) {
      canvas.drawCircle(
          const Offset(108, 143), 2.4, Paint()..color = ink.color);
      canvas.drawLine(const Offset(67, 106), const Offset(67, 128), ink);
      canvas.drawLine(const Offset(54, 117), const Offset(80, 117), ink);
      canvas.drawLine(const Offset(135, 106), const Offset(135, 128), ink);
      canvas.drawLine(const Offset(122, 117), const Offset(148, 117), ink);
    },
  );

  final flower = PaintPicture(
    id: 'flower',
    pt: 'Flor',
    en: 'Flower',
    regions: [
      PaintRegion('stem', _rect(97, 88, 6, 58, 3)),
      PaintRegion('leafL', _oval(80, 120, 34, 15, -.45)),
      PaintRegion('leafR', _oval(120, 110, 34, 15, .45)),
      for (var i = 0; i < 6; i++)
        PaintRegion(
          'petal$i',
          _circle(100 + 23 * math.cos(i * math.pi / 3 - math.pi / 2),
              66 + 23 * math.sin(i * math.pi / 3 - math.pi / 2), 16),
        ),
      PaintRegion('center', _circle(100, 66, 14)),
      PaintRegion('pot', _poly([72, 152, 128, 152, 120, 194, 80, 194])),
      PaintRegion('rim', _rect(64, 142, 72, 13, 4)),
    ],
    details: (canvas, ink) {
      final dot = Paint()..color = ink.color;
      canvas.drawCircle(const Offset(95, 63), 2.2, dot);
      canvas.drawCircle(const Offset(105, 63), 2.2, dot);
      canvas.drawArc(
          Rect.fromCenter(center: const Offset(100, 68), width: 10, height: 8),
          .3,
          2.5,
          false,
          ink);
    },
  );

  final fish = PaintPicture(
    id: 'fish',
    pt: 'Peixinho',
    en: 'Fish',
    regions: [
      PaintRegion('bubble1', _circle(162, 44, 7)),
      PaintRegion('bubble2', _circle(174, 24, 5)),
      PaintRegion('bubble3', _circle(152, 20, 4)),
      PaintRegion('tail', _poly([46, 100, 12, 68, 20, 100, 12, 132])),
      PaintRegion('finTop', _poly([84, 70, 106, 40, 126, 70])),
      PaintRegion('finBottom', _poly([90, 130, 104, 154, 118, 130])),
      PaintRegion('body', _oval(100, 100, 124, 74)),
      PaintRegion(
          'stripe1',
          Path.combine(PathOperation.intersect, _oval(100, 100, 124, 74),
              _rect(74, 60, 13, 80))),
      PaintRegion(
          'stripe2',
          Path.combine(PathOperation.intersect, _oval(100, 100, 124, 74),
              _rect(100, 60, 13, 80))),
    ],
    details: (canvas, ink) {
      canvas.drawCircle(
          const Offset(136, 92), 8, Paint()..color = const Color(0xFFFFFFFF));
      canvas.drawCircle(const Offset(136, 92), 8, ink);
      canvas.drawCircle(const Offset(138, 93), 4, Paint()..color = ink.color);
      canvas.drawArc(
          Rect.fromCenter(
              center: const Offset(150, 108), width: 14, height: 10),
          .2,
          1.8,
          false,
          ink);
    },
  );

  final rainbow = PaintPicture(
    id: 'rainbow',
    pt: 'Arco-íris',
    en: 'Rainbow',
    regions: [
      PaintRegion('sun', _circle(30, 30, 16)),
      for (var i = 0; i < 5; i++)
        PaintRegion(
          'band$i',
          Path.combine(
            PathOperation.intersect,
            Path.combine(
                PathOperation.difference,
                _circle(100, 150, 88.0 - i * 13),
                _circle(100, 150, 75.0 - i * 13)),
            _rect(0, 0, 200, 150),
          ),
        ),
      PaintRegion('cloudL', _cloud(32, 146, 1.25)),
      PaintRegion('cloudR', _cloud(168, 146, 1.25)),
    ],
  );

  final butterfly = PaintPicture(
    id: 'butterfly',
    pt: 'Borboleta',
    en: 'Butterfly',
    regions: [
      PaintRegion('wingUL', _oval(66, 76, 72, 60, -.35)),
      PaintRegion('wingUR', _oval(134, 76, 72, 60, .35)),
      PaintRegion('wingLL', _oval(76, 130, 52, 44, .4)),
      PaintRegion('wingLR', _oval(124, 130, 52, 44, -.4)),
      PaintRegion('spotL', _circle(62, 74, 11)),
      PaintRegion('spotR', _circle(138, 74, 11)),
      PaintRegion('body', _rect(93, 62, 14, 92, 7)),
      PaintRegion('head', _circle(100, 52, 13)),
    ],
    details: (canvas, ink) {
      final p = Path()
        ..moveTo(95, 42)
        ..quadraticBezierTo(86, 24, 76, 20)
        ..moveTo(105, 42)
        ..quadraticBezierTo(114, 24, 124, 20);
      canvas.drawPath(p, ink);
      final dot = Paint()..color = ink.color;
      canvas.drawCircle(const Offset(76, 20), 3.5, dot);
      canvas.drawCircle(const Offset(124, 20), 3.5, dot);
      canvas.drawCircle(const Offset(95, 50), 2.2, dot);
      canvas.drawCircle(const Offset(105, 50), 2.2, dot);
      canvas.drawArc(
          Rect.fromCenter(center: const Offset(100, 55), width: 9, height: 6),
          .3,
          2.5,
          false,
          ink);
    },
  );

  final car = PaintPicture(
    id: 'car',
    pt: 'Carrinho',
    en: 'Car',
    regions: [
      PaintRegion('road', _rect(0, 168, 200, 32, 6)),
      PaintRegion('cabin', _poly([52, 108, 74, 72, 134, 72, 158, 108])),
      PaintRegion('body', _rect(18, 104, 164, 46, 14)),
      PaintRegion('window1', _poly([68, 104, 82, 80, 101, 80, 101, 104])),
      PaintRegion('window2', _poly([107, 104, 107, 80, 128, 80, 143, 104])),
      PaintRegion('wheel1', _circle(56, 152, 19)),
      PaintRegion('wheel2', _circle(144, 152, 19)),
      PaintRegion('hub1', _circle(56, 152, 7)),
      PaintRegion('hub2', _circle(144, 152, 7)),
      PaintRegion('light', _circle(172, 118, 6)),
    ],
    details: (canvas, ink) {
      canvas.drawLine(const Offset(104, 108), const Offset(104, 146), ink);
      canvas.drawLine(const Offset(110, 116), const Offset(120, 116), ink);
    },
  );

  return [house, flower, fish, rainbow, butterfly, car];
}
