/// Origem de cada gravação em assets/audio/animal_sounds/. Todas são
/// gravações reais com licença livre (CC0 ou Creative Commons com crédito).
/// As licenças CC BY / CC BY-SA pedem que o crédito apareça: ele fica na área
/// dos responsáveis. Os arquivos foram recortados e tiveram o volume nivelado.
class SoundCredit {
  const SoundCredit(
      this.id, this.animal, this.title, this.author, this.license, this.source);

  /// Nome do arquivo (sem .mp3).
  final String id;
  final String animal;
  final String title;
  final String author;
  final String license;
  final String source;
}

const _bsbAuthor = 'Joseph Sardin (BigSoundBank.com)';
const _bsbLicense = 'CC0 (domínio público)';

const soundCredits = <SoundCredit>[
  SoundCredit('cow', 'Vaca', 'Cow moos #4', _bsbAuthor, _bsbLicense,
      'BigSoundBank.com, som nº 2384'),
  SoundCredit('horse', 'Cavalo', 'Horse Neighing #3', _bsbAuthor, _bsbLicense,
      'BigSoundBank.com, som nº 0863'),
  SoundCredit('hen', 'Galinha', 'Hen lays #2', _bsbAuthor, _bsbLicense,
      'BigSoundBank.com, som nº 0976'),
  SoundCredit('rooster', 'Galo', 'Cock Song #1', _bsbAuthor, _bsbLicense,
      'BigSoundBank.com, som nº 0440'),
  SoundCredit('sheep', 'Ovelha', 'Sheep #2', _bsbAuthor, _bsbLicense,
      'BigSoundBank.com, som nº 2344'),
  SoundCredit('goat', 'Cabra', 'Goat #2', _bsbAuthor, _bsbLicense,
      'BigSoundBank.com, som nº 1381'),
  SoundCredit('donkey', 'Burro', 'Donkey, braying #2', _bsbAuthor, _bsbLicense,
      'BigSoundBank.com, som nº 1550'),
  SoundCredit('cat', 'Gato', 'Meow cat #3', _bsbAuthor, _bsbLicense,
      'BigSoundBank.com, som nº 1891'),
  SoundCredit('dog', 'Cachorro', 'Barking Dog #2', _bsbAuthor, _bsbLicense,
      'BigSoundBank.com, som nº 2954'),
  SoundCredit('frog', 'Sapo', 'Frogs #1', _bsbAuthor, _bsbLicense,
      'BigSoundBank.com, som nº 0997'),
  SoundCredit('owl', 'Coruja', 'Tawny Owl #3', _bsbAuthor, _bsbLicense,
      'BigSoundBank.com, som nº 3459'),
  SoundCredit('rabbit', 'Coelho (comendo cenoura)', 'Raw carrot crunched #1',
      _bsbAuthor, _bsbLicense, 'BigSoundBank.com, som nº 1594'),
  SoundCredit(
      'elephant',
      'Elefante',
      'Elephant voice - trumpeting',
      'தகவலுழவன் (Wikimedia Commons)',
      'CC0',
      'commons.wikimedia.org/wiki/File:Elephant_voice_-_trumpeting.ogg'),
  SoundCredit(
      'monkey',
      'Macaco (chimpanzé)',
      'Pant-hoot call made by a male chimpanzee',
      'Pawel Fedurek et al.',
      'CC BY 4.0',
      'commons.wikimedia.org/wiki/File:Pant-hoot_call_made_by_a_male_chimpanzee.ogg'),
];
