import 'dart:async';

import 'package:flutter/foundation.dart';

import 'settings_service.dart';

/// Controla o tempo de uso do dia: conta enquanto o app está aberto, guarda no
/// aparelho (fechar e abrir de novo não zera) e avisa quando acaba.
///
/// [progress] vai de 0 (começo do dia) a 1 (hora de dormir) e move o céu.
class UsageService extends ChangeNotifier {
  UsageService({
    required this.settings,
    DateTime Function()? now,
    this.tickInterval = const Duration(seconds: 1),
  })  : _now = now ?? DateTime.now,
        _day = '',
        _used = 0 {
    _loadToday();
    settings.addListener(_onSettings);
  }

  final SettingsService settings;
  final DateTime Function() _now;
  final Duration tickInterval;

  Timer? _timer;
  Timer? _demoTimer;
  bool _running = false;
  bool _bedtime = false;
  String _day;
  int _used;
  int _sinceSave = 0;
  double? _demo;

  /// Hora de dormir: o tempo do dia acabou.
  bool get bedtime => _bedtime;

  int get limitSeconds => settings.limitMinutes * 60;
  bool get hasLimit => settings.limitMinutes > 0;
  int get usedSeconds => _used;
  int get remainingSeconds => hasLimit ? (limitSeconds - _used).clamp(0, limitSeconds).toInt() : 0;

  /// 0 = dia começando, 1 = noite (hora de dormir).
  double get progress {
    final demo = _demo;
    if (demo != null) return demo;
    if (!hasLimit) return 0;
    return (_used / limitSeconds).clamp(0.0, 1.0).toDouble();
  }

  static String dayKey(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  void _loadToday() {
    final today = dayKey(_now());
    if (settings.usedDay == today) {
      _day = today;
      _used = settings.usedSeconds;
    } else {
      _day = today;
      _used = 0;
      unawaited(settings.saveUsage(_day, 0));
    }
    _bedtime = hasLimit && _used >= limitSeconds;
  }

  void _onSettings() {
    // Mudou o limite: reavalia (ex.: sem limite tira a hora de dormir).
    _bedtime = hasLimit && _used >= limitSeconds;
    if (_running) _syncTimer();
    notifyListeners();
  }

  /// O app está na frente: começa a contar.
  void start() {
    _running = true;
    _rollDay();
    _syncTimer();
    notifyListeners();
  }

  /// O app saiu de cena: para de contar e guarda.
  void pause() {
    _running = false;
    _timer?.cancel();
    _timer = null;
    unawaited(settings.saveUsage(_day, _used));
  }

  void _syncTimer() {
    final should = _running && hasLimit && !_bedtime;
    if (should && _timer == null) {
      _timer = Timer.periodic(tickInterval, (_) => tickOnce());
    } else if (!should) {
      _timer?.cancel();
      _timer = null;
    }
  }

  void _rollDay() {
    final today = dayKey(_now());
    if (today != _day) {
      _day = today;
      _used = 0;
      _bedtime = false;
      unawaited(settings.saveUsage(_day, 0));
    }
  }

  /// Um segundo de uso (público para os testes).
  @visibleForTesting
  void tickOnce() {
    _rollDay();
    if (!hasLimit || _bedtime) {
      _syncTimer();
      return;
    }
    _used += 1;
    _sinceSave += 1;
    if (_used >= limitSeconds) {
      _used = limitSeconds;
      _bedtime = true;
      _syncTimer();
      unawaited(settings.saveUsage(_day, _used));
    } else if (_sinceSave >= 15) {
      _sinceSave = 0;
      unawaited(settings.saveUsage(_day, _used));
    }
    notifyListeners();
  }

  /// Dá mais tempo hoje (volta o relógio) e tira a hora de dormir.
  void addTime(Duration extra) {
    _used = (_used - extra.inSeconds).clamp(0, 1 << 30).toInt();
    _bedtime = hasLimit && _used >= limitSeconds;
    unawaited(settings.saveUsage(_day, _used));
    if (_running) _syncTimer();
    notifyListeners();
  }

  /// Zera o tempo usado hoje.
  void resetToday() {
    _used = 0;
    _bedtime = false;
    unawaited(settings.saveUsage(_day, 0));
    if (_running) _syncTimer();
    notifyListeners();
  }

  /// Mostra o dia inteiro passando em alguns segundos (para os responsáveis verem).
  void startDemo({Duration length = const Duration(seconds: 20)}) {
    _demoTimer?.cancel();
    const step = Duration(milliseconds: 100);
    var elapsed = Duration.zero;
    _demo = 0;
    notifyListeners();
    _demoTimer = Timer.periodic(step, (t) {
      elapsed += step;
      final p = elapsed.inMilliseconds / length.inMilliseconds;
      if (p >= 1) {
        t.cancel();
        _demo = null;
      } else {
        _demo = p;
      }
      notifyListeners();
    });
  }

  bool get demoRunning => _demo != null;

  @override
  void dispose() {
    _timer?.cancel();
    _demoTimer?.cancel();
    settings.removeListener(_onSettings);
    super.dispose();
  }
}
