import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// O que acontece quando o tempo de uso do dia termina.
enum EndMode {
  /// Fica uma tela de dormir (escura), sem deixar usar mais.
  sleepScreen,

  /// Fecha o aplicativo sozinho.
  closeApp,
}

/// Ajustes dos responsáveis, guardados apenas no aparelho.
class SettingsService extends ChangeNotifier {
  SettingsService(this._prefs)
      : _volume = _prefs.getDouble(_kVolume) ?? 0.8,
        _effectsMuted = _prefs.getBool(_kEffectsMuted) ?? false,
        _autoSpeakLetters = _prefs.getBool(_kAutoSpeakLetters) ?? true,
        _limitMinutes = _prefs.getInt(_kLimit) ?? 0,
        _endMode = EndMode.values[(_prefs.getInt(_kEndMode) ?? 0).clamp(0, EndMode.values.length - 1).toInt()];

  static const _kVolume = 'volume';
  static const _kEffectsMuted = 'effectsMuted';
  static const _kAutoSpeakLetters = 'autoSpeakLetters';
  static const _kLimit = 'limitMinutes';
  static const _kEndMode = 'endMode';
  static const _kUsedDay = 'usedDay';
  static const _kUsedSeconds = 'usedSeconds';

  final SharedPreferences _prefs;
  double _volume;
  bool _effectsMuted;
  bool _autoSpeakLetters;
  int _limitMinutes;
  EndMode _endMode;

  double get volume => _volume;

  /// Silencia só os sons de animais; as pronúncias continuam.
  bool get effectsMuted => _effectsMuted;

  Future<void> setVolume(double v) async {
    _volume = v.clamp(0.0, 1.0);
    notifyListeners();
    await _prefs.setDouble(_kVolume, _volume);
  }

  Future<void> setEffectsMuted(bool v) async {
    _effectsMuted = v;
    notifyListeners();
    await _prefs.setBool(_kEffectsMuted, v);
  }

  /// Ao abrir uma letra, fala o nome em português e depois em inglês.
  bool get autoSpeakLetters => _autoSpeakLetters;

  Future<void> setAutoSpeakLetters(bool v) async {
    _autoSpeakLetters = v;
    notifyListeners();
    await _prefs.setBool(_kAutoSpeakLetters, v);
  }

  /// Minutos de uso por dia. 0 = sem limite.
  int get limitMinutes => _limitMinutes;

  EndMode get endMode => _endMode;

  Future<void> setLimitMinutes(int minutes) async {
    _limitMinutes = minutes < 0 ? 0 : minutes;
    notifyListeners();
    await _prefs.setInt(_kLimit, _limitMinutes);
  }

  Future<void> setEndMode(EndMode mode) async {
    _endMode = mode;
    notifyListeners();
    await _prefs.setInt(_kEndMode, mode.index);
  }

  /// Dia (aaaa-mm-dd) a que se refere o tempo usado guardado.
  String get usedDay => _prefs.getString(_kUsedDay) ?? '';

  int get usedSeconds => _prefs.getInt(_kUsedSeconds) ?? 0;

  /// Guarda o tempo usado hoje (não avisa ouvintes: é chamado a cada poucos segundos).
  Future<void> saveUsage(String day, int seconds) async {
    await _prefs.setString(_kUsedDay, day);
    await _prefs.setInt(_kUsedSeconds, seconds);
  }
}
