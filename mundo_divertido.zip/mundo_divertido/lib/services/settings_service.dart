import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Ajustes dos responsáveis, guardados apenas no aparelho.
class SettingsService extends ChangeNotifier {
  SettingsService(this._prefs)
      : _volume = _prefs.getDouble(_kVolume) ?? 0.8,
        _effectsMuted = _prefs.getBool(_kEffectsMuted) ?? false;

  static const _kVolume = 'volume';
  static const _kEffectsMuted = 'effectsMuted';

  final SharedPreferences _prefs;
  double _volume;
  bool _effectsMuted;

  double get volume => _volume;

  /// Silencia só os sons de animais; as pronúncias continuam.
  bool get effectsMuted => _effectsMuted;

  Future<void> setVolume(double v) async {
    _volume = v.clamp(0.0, 1.0);
    notifyListeners();
    await _prefs.setDouble(_kVolume, _volume);
  }

  Future<void> setEffectsMuted(bool v) async {
    _effectsMuted = v;
    notifyListeners();
    await _prefs.setBool(_kEffectsMuted, v);
  }
}
