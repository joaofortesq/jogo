import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/learning_item.dart';
import '../services/audio_service.dart';
import '../theme/app_theme.dart';
import '../widgets/animated_character.dart';
import '../widgets/audio_controls.dart';
import '../widgets/kid_top_bar.dart';
import '../widgets/scene_background.dart';

/// Tela única para os 30 animais e frutas: desliza para o lado ou usa as setas.
class ItemDetailScreen extends StatefulWidget {
  const ItemDetailScreen({super.key, required this.category, required this.initialIndex});

  final Category category;
  final int initialIndex;

  @override
  State<ItemDetailScreen> createState() => _ItemDetailScreenState();
}

class _ItemDetailScreenState extends State<ItemDetailScreen> {
  late final PageController _pages = PageController(initialPage: widget.initialIndex);
  late int _index = widget.initialIndex;

  List<LearningItem> get _items => widget.category.items;

  @override
  void dispose() {
    _pages.dispose();
    super.dispose();
  }

  void _go(int delta) {
    final next = _index + delta;
    if (next < 0 || next >= _items.length) return;
    _pages.animateToPage(next,
        duration: const Duration(milliseconds: 320), curve: Curves.easeOutCubic);
  }

  @override
  Widget build(BuildContext context) {
    final cat = widget.category;
    final audio = context.read<AudioService>();
    return Scaffold(
      body: SceneBackground(
        category: cat,
        child: SafeArea(
          child: Column(
            children: [
              KidTopBar(
                title: cat.titlePt,
                onBack: () => Navigator.of(context).pop(),
                backIcon: Icons.grid_view_rounded,
                backLabel: 'Voltar à lista',
              ),
              Expanded(
                child: Stack(
                  children: [
                    PageView.builder(
                      controller: _pages,
                      itemCount: _items.length,
                      onPageChanged: (i) {
                        setState(() => _index = i);
                        audio.stop(); // nada toca sozinho ao trocar de figura
                      },
                      itemBuilder: (context, i) => _ItemPage(item: _items[i], category: cat),
                    ),
                    Positioned(
                      left: 4,
                      top: 0,
                      bottom: 0,
                      child: _Arrow(icon: Icons.chevron_left_rounded, label: 'Anterior',
                          enabled: _index > 0, onTap: () => _go(-1)),
                    ),
                    Positioned(
                      right: 4,
                      top: 0,
                      bottom: 0,
                      child: _Arrow(icon: Icons.chevron_right_rounded, label: 'Próximo',
                          enabled: _index < _items.length - 1, onTap: () => _go(1)),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                child: AudioControls(item: _items[_index], accent: cat.accent),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Arrow extends StatelessWidget {
  const _Arrow({required this.icon, required this.label, required this.enabled, required this.onTap});
  final IconData icon;
  final String label;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Opacity(
        opacity: enabled ? 1 : .25,
        child: RoundIconButton(
          icon: icon,
          label: label,
          background: Colors.white70,
          onPressed: enabled ? onTap : () {},
        ),
      ),
    );
  }
}

class _ItemPage extends StatelessWidget {
  const _ItemPage({required this.item, required this.category});
  final LearningItem item;
  final Category category;

  @override
  Widget build(BuildContext context) {
    final audio = context.read<AudioService>();
    return LayoutBuilder(builder: (context, c) {
      final size = (c.maxWidth * .68).clamp(120.0, c.maxHeight * .55);
      return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedCharacter(
            item: item,
            reaction: category.reaction,
            size: size,
            onTap: () => runAudio(context, audio.playAll(item)),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.9),
              borderRadius: BorderRadius.circular(28),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(item.pt.toUpperCase(),
                    style: const TextStyle(fontSize: 44, fontWeight: FontWeight.w900, color: AppColors.ink)),
                Text(item.en.toUpperCase(),
                    style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800, color: category.textAccent)),
              ],
            ),
          ),
        ],
      );
    });
  }
}
