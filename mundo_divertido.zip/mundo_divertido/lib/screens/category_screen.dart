import 'package:flutter/material.dart';

import '../models/learning_item.dart';
import '../widgets/kid_top_bar.dart';
import '../widgets/learning_card.dart';
import '../widgets/scene_background.dart';
import 'color_detail_screen.dart';
import 'item_detail_screen.dart';

class CategoryScreen extends StatelessWidget {
  const CategoryScreen({super.key, required this.category});

  final Category category;

  void _open(BuildContext context, int index) {
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => category.kind == CategoryKind.colors
          ? ColorDetailScreen(category: category, initialIndex: index)
          : ItemDetailScreen(category: category, initialIndex: index),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final isColors = category.kind == CategoryKind.colors;
    return Scaffold(
      backgroundColor: category.background,
      body: SceneBackground(
        category: category,
        child: SafeArea(
        child: Column(
          children: [
            KidTopBar(title: category.titlePt),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 14,
                  crossAxisSpacing: 14,
                  childAspectRatio: isColors ? 1.35 : 0.9,
                ),
                itemCount: category.items.length,
                itemBuilder: (context, i) {
                  final item = category.items[i];
                  return isColors
                      ? ColorSwatchTile(item: item, onTap: () => _open(context, i))
                      : LearningCard(
                          item: item,
                          accent: category.textAccent,
                          onTap: () => _open(context, i),
                        );
                },
              ),
            ),
          ],
        ),
        ),
      ),
    );
  }
}
