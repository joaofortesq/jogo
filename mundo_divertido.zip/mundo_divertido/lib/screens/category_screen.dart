import 'package:flutter/material.dart';

import '../models/learning_item.dart';
import '../widgets/kid_top_bar.dart';
import '../widgets/learning_card.dart';
import '../widgets/pop_in.dart';
import '../widgets/scene_background.dart';
import 'color_detail_screen.dart';
import 'paint_screen.dart';
import 'glyph_detail_screen.dart';
import 'item_detail_screen.dart';
import '../widgets/app_route.dart';

class CategoryScreen extends StatelessWidget {
  const CategoryScreen({super.key, required this.category});

  final Category category;

  void _open(BuildContext context, int index) {
    Navigator.of(context).push(AppRoute<void>(
      builder: (_) => switch (category.kind) {
        CategoryKind.colors =>
          ColorDetailScreen(category: category, initialIndex: index),
        CategoryKind.letters ||
        CategoryKind.numbers =>
          GlyphDetailScreen(category: category, initialIndex: index),
        _ => ItemDetailScreen(category: category, initialIndex: index),
      },
    ));
  }

  @override
  Widget build(BuildContext context) {
    final isColors = category.kind == CategoryKind.colors;
    final isGlyphs = category.kind == CategoryKind.letters ||
        category.kind == CategoryKind.numbers;
    return Scaffold(
      backgroundColor: category.background,
      body: SceneBackground(
        category: category,
        child: SafeArea(
          child: Column(
            children: [
              KidTopBar(title: category.titlePt),
              if (isColors)
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
                  child: PaintButton(
                    height: 70,
                    onTap: () => Navigator.of(context).push(AppRoute<void>(
                      builder: (_) => PaintScreen(colors: category.items),
                    )),
                  ),
                ),
              Expanded(
                child: GridView.builder(
                  padding: const EdgeInsets.all(16),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: isGlyphs ? 3 : 2,
                    mainAxisSpacing: 14,
                    crossAxisSpacing: 14,
                    childAspectRatio: isColors ? 1.0 : (isGlyphs ? 0.95 : 0.9),
                  ),
                  itemCount: category.items.length,
                  itemBuilder: (context, i) {
                    final item = category.items[i];
                    return PopIn(
                      index: i,
                      child: isColors
                          ? ColorSwatchTile(
                              item: item,
                              index: i,
                              onTap: () => _open(context, i))
                          : isGlyphs
                              ? GlyphTile(
                                  item: item,
                                  numbers:
                                      category.kind == CategoryKind.numbers,
                                  onTap: () => _open(context, i),
                                )
                              : LearningCard(
                                  item: item,
                                  accent: category.textAccent,
                                  onTap: () => _open(context, i),
                                ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
