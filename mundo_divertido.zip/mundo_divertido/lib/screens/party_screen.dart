import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/content_repository.dart';
import '../models/learning_item.dart';
import '../services/audio_service.dart';
import '../widgets/art_config.dart';
import '../widgets/audio_controls.dart';
import '../widgets/item_art.dart';
import '../widgets/kid_top_bar.dart';
import '../widgets/pop_in.dart';
import '../widgets/rig_animal.dart';

/// Festa dos Bichos: os animais da fazenda e do safári juntos, dançando.
/// Tocar num bicho faz o som dele.
class PartyScreen extends StatefulWidget {
  const PartyScreen({super.key});

  @override
  State<PartyScreen> createState() => _PartyScreenState();
}

class _PartyScreenState extends State<PartyScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _clock =
      AnimationController(vsync: this, duration: const Duration(seconds: 4));
  late final AudioService _audio;
  late final List<LearningItem> _animals;
  final Map<String, ValueNotifier<bool>> _talking = {};
  bool _dancing = true;
  bool _started = false;

  @override
  void initState() {
    super.initState();
    _audio = context.read<AudioService>();
    final cats = context
        .read<ContentRepository>()
        .categories
        .where((c) => c.kind == CategoryKind.animals)
        .toList();
    final longest = cats.map((c) => c.items.length).fold<int>(0, math.max);
    // Intercala fazenda e safári para a festa ficar misturada.
    _animals = [
      for (var i = 0; i < longest; i++)
        for (final c in cats)
          if (i < c.items.length) c.items[i],
    ];
    _audio.playingTag.addListener(_syncTalking);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_started) return;
    _started = true;
    if (!MediaQuery.of(context).disableAnimations) _clock.repeat();
  }

  ValueNotifier<bool> _talkingFor(String id) =>
      _talking.putIfAbsent(id, () => ValueNotifier<bool>(false));

  void _syncTalking() {
    final tag = _audio.playingTag.value;
    _talking.forEach((id, n) {
      final t = tag != null && tag.startsWith('$id:');
      if (n.value != t) n.value = t;
    });
  }

  @override
  void dispose() {
    _audio.playingTag.removeListener(_syncTalking);
    _audio.stop();
    for (final n in _talking.values) {
      n.dispose();
    }
    _clock.dispose();
    super.dispose();
  }

  Widget _bichoCell(LearningItem item, int index, double side) {
    final rig = item.rig;
    final Widget figure = (rig != null && ArtConfig.renderSvg)
        ? RigAnimal(
            rig: rig,
            size: side,
            clock: _clock,
            phase: (index * 0.137) % 1.0,
            dance: _dancing ? 1 : 0,
            talking: _talkingFor(item.id),
          )
        : ItemArt(item: item, size: side);
    return Semantics(
      button: true,
      label: '${item.pt}. Toque para ouvir o som.',
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => runAudio(context, _audio.playSound(item)),
        child: Column(
          children: [
            Expanded(child: Center(child: RepaintBoundary(child: figure))),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(.9),
                borderRadius: BorderRadius.circular(16),
              ),
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(item.pt,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w900, color: Color(0xFF2B2A4C))),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFB794F6), Color(0xFFFFA8C8), Color(0xFFFFE08A)],
          ),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              Positioned.fill(child: _FloatingNotes(clock: _clock)),
              Column(
                children: [
                  KidTopBar(title: 'Festa dos Bichos', onBack: () => Navigator.of(context).pop()),
                  Expanded(
                    child: LayoutBuilder(builder: (context, c) {
                      final cols = (c.maxWidth ~/ 130).clamp(3, 6).toInt();
                      const gap = 8.0;
                      final cellW = (c.maxWidth - 24 - gap * (cols - 1)) / cols;
                      return GridView.builder(
                        padding: const EdgeInsets.fromLTRB(12, 4, 12, 96),
                        itemCount: _animals.length,
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: cols,
                          mainAxisSpacing: gap,
                          crossAxisSpacing: gap,
                          childAspectRatio: cellW / (cellW * 1.12 + 26),
                        ),
                        itemBuilder: (context, i) => PopIn(
                          index: i % 9,
                          child: _bichoCell(_animals[i], i, cellW),
                        ),
                      );
                    }),
                  ),
                ],
              ),
              Positioned(
                right: 16,
                bottom: 16,
                child: RoundIconButton(
                  icon: _dancing ? Icons.pause_rounded : Icons.music_note_rounded,
                  label: _dancing ? 'Parar a dança' : 'Dançar',
                  background: Colors.white,
                  onPressed: () => setState(() => _dancing = !_dancing),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Notas musicais que sobem devagar atrás dos bichos.
class _FloatingNotes extends StatelessWidget {
  const _FloatingNotes({required this.clock});

  final Animation<double> clock;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: clock,
        builder: (context, _) => LayoutBuilder(builder: (context, c) {
          return Stack(
            children: [
              for (var k = 0; k < 6; k++)
                Positioned(
                  left: c.maxWidth * (.08 + k * .17) + math.sin((clock.value + k * .2) * 2 * math.pi) * 14,
                  top: c.maxHeight * (1.05 - ((clock.value + k / 6) % 1.0) * 1.2),
                  child: Icon(
                    k.isEven ? Icons.music_note_rounded : Icons.favorite_rounded,
                    size: 26 + (k % 3) * 8.0,
                    color: Colors.white.withOpacity(.5),
                  ),
                ),
            ],
          );
        }),
      ),
    );
  }
}
