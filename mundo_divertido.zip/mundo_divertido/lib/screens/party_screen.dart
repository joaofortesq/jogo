import 'dart:math' as math;

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/content_repository.dart';
import '../models/learning_item.dart';
import '../services/audio_service.dart';
import '../services/settings_service.dart';
import '../widgets/art_config.dart';
import '../widgets/audio_controls.dart';
import '../widgets/item_art.dart';
import '../widgets/kid_top_bar.dart';
import '../widgets/pop_in.dart';
import '../widgets/motion_profile.dart';
import '../widgets/rig_animal.dart';

/// Festa dos Bichos: os animais da fazenda e do safári juntos, dançando.
/// Tocar num bicho faz o som dele.
class PartyScreen extends StatefulWidget {
  const PartyScreen({super.key});

  @override
  State<PartyScreen> createState() => _PartyScreenState();
}

class _PartyScreenState extends State<PartyScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late final AnimationController _clock =
      AnimationController(vsync: this, duration: const Duration(seconds: 4));
  late final AudioService _audio;
  late final List<LearningItem> _animals;
  final Map<String, ValueNotifier<bool>> _talking = {};
  bool _dancing = true;
  bool _started = false;

  // Música de fundo da festa, em loop. Player próprio, separado do AudioService,
  // para que tocar o som de um bicho não corte a música.
  static const _musicAsset = 'audio/music/festa.mp3';
  static const _musicVolumeFactor = 0.5; // um pouco mais baixa que os sons dos bichos
  AudioPlayer? _music;

  @override
  void initState() {
    super.initState();
    _audio = context.read<AudioService>();
    final cats = context
        .read<ContentRepository>()
        .categories
        .where((c) => c.kind == CategoryKind.animals)
        .toList();
    final longest = cats.map((c) => c.items.length).fold<int>(0, math.max);
    // Intercala fazenda e safári para a festa ficar misturada.
    _animals = [
      for (var i = 0; i < longest; i++)
        for (final c in cats)
          if (i < c.items.length) c.items[i],
    ];
    _audio.playingTag.addListener(_syncTalking);
    WidgetsBinding.instance.addObserver(this);
    _startMusic();
  }

  Future<void> _startMusic() async {
    final volume = context.read<SettingsService>().volume * _musicVolumeFactor;
    try {
      final player = AudioPlayer();
      _music = player;
      // Mistura com os outros sons em vez de pedir o foco de áudio (senão o
      // som do bicho pausaria a música).
      await player.setAudioContext(AudioContextConfig(
        focus: AudioContextConfigFocus.mixWithOthers,
      ).build());
      await player.setReleaseMode(ReleaseMode.loop);
      await player.setVolume(volume);
      if (!mounted || _music != player) return;
      if (_dancing) await player.play(AssetSource(_musicAsset));
    } catch (e) {
      debugPrint('Música da festa indisponível: $e');
    }
  }

  Future<void> _setMusicPlaying(bool on) async {
    final player = _music;
    if (player == null) return;
    try {
      if (on) {
        if (player.state == PlayerState.paused) {
          await player.resume();
        } else {
          await player.play(AssetSource(_musicAsset));
        }
      } else {
        await player.pause();
      }
    } catch (e) {
      debugPrint('Erro na música da festa: $e');
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      if (_dancing) _setMusicPlaying(true);
    } else if (state == AppLifecycleState.paused || state == AppLifecycleState.inactive) {
      _setMusicPlaying(false);
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_started) return;
    _started = true;
    if (!MediaQuery.of(context).disableAnimations) _clock.repeat();
  }

  ValueNotifier<bool> _talkingFor(String id) =>
      _talking.putIfAbsent(id, () => ValueNotifier<bool>(false));

  void _syncTalking() {
    final tag = _audio.playingTag.value;
    _talking.forEach((id, n) {
      final t = tag != null && tag.startsWith('$id:');
      if (n.value != t) n.value = t;
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    final music = _music;
    _music = null;
    if (music != null) {
      music.stop().catchError((_) {}).whenComplete(() => music.dispose());
    }
    _audio.playingTag.removeListener(_syncTalking);
    _audio.stop();
    for (final n in _talking.values) {
      n.dispose();
    }
    _clock.dispose();
    super.dispose();
  }

  Widget _bichoCell(LearningItem item, int index, double side) {
    final rig = item.rig;
    final Widget figure = (rig != null && ArtConfig.renderSvg)
        ? RigAnimal(
            rig: rig,
            size: side,
            clock: _clock,
            phase: (index * 0.137) % 1.0,
            dance: _dancing ? 1 : 0,
            talking: _talkingFor(item.id),
          )
        : _DancingBicho(
            item: item,
            size: side,
            clock: _clock,
            phase: (index * 0.137) % 1.0,
            dancing: _dancing,
            talking: _talkingFor(item.id),
          );
    return Semantics(
      button: true,
      label: '${item.pt}. Toque para ouvir o som.',
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => runAudio(context, _audio.playSound(item)),
        child: Column(
          children: [
            Expanded(child: Center(child: RepaintBoundary(child: figure))),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(.9),
                borderRadius: BorderRadius.circular(16),
              ),
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(item.pt,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w900, color: Color(0xFF2B2A4C))),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFB794F6), Color(0xFFFFA8C8), Color(0xFFFFE08A)],
          ),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              Positioned.fill(child: _FloatingNotes(clock: _clock)),
              Column(
                children: [
                  KidTopBar(title: 'Festa dos Bichos', onBack: () => Navigator.of(context).pop()),
                  Expanded(
                    child: LayoutBuilder(builder: (context, c) {
                      final cols = (c.maxWidth ~/ 130).clamp(3, 6).toInt();
                      const gap = 8.0;
                      final cellW = (c.maxWidth - 24 - gap * (cols - 1)) / cols;
                      return GridView.builder(
                        padding: const EdgeInsets.fromLTRB(12, 4, 12, 96),
                        itemCount: _animals.length,
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: cols,
                          mainAxisSpacing: gap,
                          crossAxisSpacing: gap,
                          childAspectRatio: cellW / (cellW * 1.12 + 26),
                        ),
                        itemBuilder: (context, i) => PopIn(
                          index: i % 9,
                          child: _bichoCell(_animals[i], i, cellW),
                        ),
                      );
                    }),
                  ),
                ],
              ),
              Positioned(
                right: 16,
                bottom: 16,
                child: RoundIconButton(
                  icon: _dancing ? Icons.pause_rounded : Icons.music_note_rounded,
                  label: _dancing ? 'Parar a dança' : 'Dançar',
                  background: Colors.white,
                  onPressed: () {
                    setState(() => _dancing = !_dancing);
                    _setMusicPlaying(_dancing);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Notas musicais que sobem devagar atrás dos bichos.
class _FloatingNotes extends StatelessWidget {
  const _FloatingNotes({required this.clock});

  final Animation<double> clock;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: clock,
        builder: (context, _) => LayoutBuilder(builder: (context, c) {
          return Stack(
            children: [
              for (var k = 0; k < 6; k++)
                Positioned(
                  left: c.maxWidth * (.08 + k * .17) + math.sin((clock.value + k * .2) * 2 * math.pi) * 14,
                  top: c.maxHeight * (1.05 - ((clock.value + k / 6) % 1.0) * 1.2),
                  child: Icon(
                    k.isEven ? Icons.music_note_rounded : Icons.favorite_rounded,
                    size: 26 + (k % 3) * 8.0,
                    color: Colors.white.withOpacity(.5),
                  ),
                ),
            ],
          );
        }),
      ),
    );
  }
}

/// Rosto do bicho dançando: balança de um lado para o outro, quica no ritmo,
/// abaixa e estica (como quem pisa no chão) e fica mais animado ao fazer o som.
class _DancingBicho extends StatelessWidget {
  const _DancingBicho({
    required this.item,
    required this.size,
    required this.clock,
    required this.phase,
    required this.dancing,
    required this.talking,
  });

  final LearningItem item;
  final double size;
  final Animation<double> clock;
  final double phase;
  final bool dancing;
  final ValueListenable<bool> talking;

  @override
  Widget build(BuildContext context) {
    final kind = motionFor(item.id);
    return AnimatedBuilder(
      animation: Listenable.merge([clock, talking]),
      builder: (context, _) {
        final v = (clock.value + phase) % 1.0;
        final d = dancing ? 1.0 : 0.0;
        final beat = math.sin(v * 2 * math.pi * 3);
        final pose = poseFor(kind, v, size);
        final boost = talking.value ? talkingBoost(v, size) : const MotionPose();
        final blinkPhase = (v + .5) % 1.0;
        final blink = (blinkPhase > .9 && blinkPhase < .96)
            ? math.sin((blinkPhase - .9) / .06 * math.pi)
            : 0.0;
        return Transform.translate(
          offset: Offset(pose.dx * (1 + d), pose.dy + boost.dy - d * beat.abs() * size * .07),
          child: Transform.rotate(
            angle: pose.angle + d * beat * .16,
            alignment: Alignment.bottomCenter,
            child: Transform.scale(
              alignment: Alignment.bottomCenter,
              scaleX: pose.scaleX * boost.scaleX * (1 - d * beat.abs() * .04),
              scaleY: pose.scaleY * boost.scaleY * (1 + d * beat.abs() * .06),
              child: ItemArt(item: item, size: size, blink: blink),
            ),
          ),
        );
      },
    );
  }
}
