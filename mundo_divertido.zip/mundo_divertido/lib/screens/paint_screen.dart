import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/paint_pictures.dart';
import '../games/game_widgets.dart' show ConfettiRain;
import '../models/learning_item.dart';
import '../services/audio_service.dart';
import '../theme/app_theme.dart';
import '../widgets/audio_controls.dart';
import '../widgets/bouncy.dart';
import '../widgets/kid_top_bar.dart';
import '../widgets/paint_blob.dart';

/// Pintar: escolhe uma tinta (a cor fala o nome em português e inglês) e toca
/// nas partes do desenho para pintar. A tinta se espalha a partir do dedo.
/// Quando tudo está pintado, chove confete e aparece o próximo desenho.
class PaintScreen extends StatefulWidget {
  const PaintScreen({super.key, required this.colors, this.initialColor});

  /// As cores da categoria "Cores".
  final List<LearningItem> colors;

  /// id da cor já escolhida ao abrir (ex.: veio da tela do vermelho).
  final String? initialColor;

  @override
  State<PaintScreen> createState() => _PaintScreenState();
}

class _PaintScreenState extends State<PaintScreen>
    with SingleTickerProviderStateMixin {
  late final AudioService _audio = context.read<AudioService>();
  late final AnimationController _spread = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 420));

  final List<PaintPicture> _pictures = paintPictures;
  int _picture = 0;
  late List<Color?> _fills =
      List<Color?>.filled(_pictures[0].regions.length, null);
  late LearningItem _color = widget.colors.firstWhere(
    (c) => c.id == widget.initialColor,
    orElse: () => widget.colors.first,
  );

  // Pintura em andamento (a tinta se espalhando).
  int _animRegion = -1;
  Offset _animOrigin = Offset.zero;
  Color? _animFrom;

  int _celebrations = 0;
  bool _done = false;

  PaintPicture get _pic => _pictures[_picture];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      runAudio(
          context,
          _audio.playMessage('pintar', 'Escolha uma cor e pinte o desenho!',
              'Pick a color and paint the picture!'));
    });
  }

  @override
  void dispose() {
    _spread.dispose();
    unawaited(_audio.stop());
    super.dispose();
  }

  void _pick(LearningItem c) {
    setState(() => _color = c);
    runAudio(context, _audio.playColorName(c));
  }

  void _paintAt(Offset local, double scale) {
    final p = local / scale;
    final i = _pic.hitTest(p);
    if (i < 0) return;
    final reduce = MediaQuery.of(context).disableAnimations;
    setState(() {
      _animFrom = _fills[i];
      _animRegion = i;
      _animOrigin = p;
      _fills[i] = _color.color;
    });
    if (reduce) {
      _spread.value = 1;
    } else {
      _spread.forward(from: 0);
    }
    final complete = _fills.every((f) => f != null);
    if (complete && !_done) {
      setState(() {
        _done = true;
        _celebrations++;
      });
      runAudio(
          context, _audio.playMessage('lindo', 'Que lindo!', 'Beautiful!'));
    } else {
      runAudio(context, _audio.playColorName(_color));
    }
  }

  void _goPicture(int delta) {
    setState(() {
      _picture = (_picture + delta) % _pictures.length;
      if (_picture < 0) _picture += _pictures.length;
      _fills = List<Color?>.filled(_pic.regions.length, null);
      _animRegion = -1;
      _done = false;
    });
    _audio.stop();
  }

  void _clear() {
    setState(() {
      _fills = List<Color?>.filled(_pic.regions.length, null);
      _animRegion = -1;
      _done = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFFFF3D6), Color(0xFFFFE1EC), Color(0xFFDDEBFF)],
          ),
        ),
        child: Stack(
          children: [
            SafeArea(
              child: Column(
                children: [
                  KidTopBar(
                      title: 'Pintar',
                      onBack: () => Navigator.of(context).pop()),
                  _PictureBar(
                    picture: _pic,
                    onPrev: () => _goPicture(-1),
                    onNext: () => _goPicture(1),
                    onClear: _clear,
                    highlightNext: _done,
                  ),
                  Expanded(child: _canvas()),
                  _Palette(
                    colors: widget.colors,
                    selected: _color,
                    onPick: _pick,
                  ),
                ],
              ),
            ),
            if (_celebrations > 0 && _done)
              Positioned.fill(
                  child: IgnorePointer(
                      child: ConfettiRain(key: ValueKey(_celebrations)))),
          ],
        ),
      ),
    );
  }

  Widget _canvas() {
    return LayoutBuilder(builder: (context, c) {
      final side = math.min(c.maxWidth - 32, c.maxHeight - 12);
      final scale = side / 200;
      return Center(
        child: Container(
          width: side,
          height: side,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(32),
            boxShadow: const [
              BoxShadow(
                  color: Color(0x22000000),
                  blurRadius: 14,
                  offset: Offset(0, 6))
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(32),
            child: Semantics(
              label: 'Desenho: ${_pic.pt}. Toque para pintar.',
              child: GestureDetector(
                key: const ValueKey('paint-canvas'),
                behavior: HitTestBehavior.opaque,
                onTapDown: (d) => _paintAt(d.localPosition, scale),
                child: RepaintBoundary(
                  child: AnimatedBuilder(
                    animation: _spread,
                    builder: (context, _) => CustomPaint(
                      size: Size.square(side),
                      painter: _PicturePainter(
                        picture: _pic,
                        fills: _fills,
                        animRegion: _animRegion,
                        animOrigin: _animOrigin,
                        animFrom: _animFrom,
                        progress: Curves.easeOutCubic.transform(_spread.value),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    });
  }
}

class _PicturePainter extends CustomPainter {
  _PicturePainter({
    required this.picture,
    required this.fills,
    required this.animRegion,
    required this.animOrigin,
    required this.animFrom,
    required this.progress,
  });

  final PaintPicture picture;
  final List<Color?> fills;
  final int animRegion;
  final Offset animOrigin;
  final Color? animFrom;
  final double progress;

  static const _blank = Color(0xFFFFFFFF);
  static const _ink = Color(0xFF2B2A4C);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 200);
    final outline = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.6
      ..strokeJoin = StrokeJoin.round
      ..strokeCap = StrokeCap.round
      ..color = _ink;
    for (var i = 0; i < picture.regions.length; i++) {
      final path = picture.regions[i].path;
      final fill = fills[i];
      if (i == animRegion && progress < 1) {
        canvas.drawPath(path, Paint()..color = animFrom ?? _blank);
        canvas.save();
        canvas.clipPath(path);
        final bounds = path.getBounds();
        final far = [
          bounds.topLeft,
          bounds.topRight,
          bounds.bottomLeft,
          bounds.bottomRight
        ].map((p) => (p - animOrigin).distance).reduce(math.max);
        canvas.drawCircle(
            animOrigin, far * progress, Paint()..color = fill ?? _blank);
        canvas.restore();
      } else {
        canvas.drawPath(path, Paint()..color = fill ?? _blank);
      }
      if (fill != null) {
        // brilho suave por cima da tinta
        canvas.save();
        canvas.clipPath(path);
        final b = path.getBounds();
        canvas.drawOval(
          Rect.fromLTWH(b.left + b.width * .12, b.top + b.height * .08,
              b.width * .45, b.height * .3),
          Paint()..color = Colors.white.withValues(alpha: .18),
        );
        canvas.restore();
      }
      canvas.drawPath(path, outline);
    }
    picture.details?.call(canvas, outline);
    canvas.restore();
  }

  @override
  bool shouldRepaint(_PicturePainter old) => true;
}

/// Nome do desenho, setas para trocar e botão de apagar.
class _PictureBar extends StatelessWidget {
  const _PictureBar({
    required this.picture,
    required this.onPrev,
    required this.onNext,
    required this.onClear,
    required this.highlightNext,
  });

  final PaintPicture picture;
  final VoidCallback onPrev;
  final VoidCallback onNext;
  final VoidCallback onClear;
  final bool highlightNext;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      child: Row(
        children: [
          RoundIconButton(
              icon: Icons.chevron_left_rounded,
              label: 'Desenho anterior',
              onPressed: onPrev),
          Expanded(
            child: Column(
              children: [
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(picture.pt,
                      style: const TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.w900,
                          color: AppColors.ink)),
                ),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(picture.en,
                      style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          color: AppColors.grape)),
                ),
              ],
            ),
          ),
          RoundIconButton(
              icon: Icons.cleaning_services_rounded,
              label: 'Apagar',
              onPressed: onClear),
          const SizedBox(width: 8),
          _Pulse(
            on: highlightNext,
            child: RoundIconButton(
              icon: Icons.chevron_right_rounded,
              label: 'Próximo desenho',
              background: highlightNext ? AppColors.grass : Colors.white,
              foreground: highlightNext ? Colors.white : AppColors.ink,
              onPressed: onNext,
            ),
          ),
        ],
      ),
    );
  }
}

class _Pulse extends StatefulWidget {
  const _Pulse({required this.on, required this.child});
  final bool on;
  final Widget child;

  @override
  State<_Pulse> createState() => _PulseState();
}

class _PulseState extends State<_Pulse> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 800));

  @override
  void didUpdateWidget(_Pulse old) {
    super.didUpdateWidget(old);
    _sync();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _sync();
  }

  void _sync() {
    final reduce = MediaQuery.of(context).disableAnimations;
    if (widget.on && !reduce) {
      if (!_c.isAnimating) _c.repeat(reverse: true);
    } else {
      _c.stop();
      _c.value = 0;
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (context, child) => Transform.scale(
          scale: 1 + .12 * Curves.easeInOut.transform(_c.value), child: child),
      child: widget.child,
    );
  }
}

/// Potinhos de tinta: duas fileiras de gotinhas. A escolhida cresce e ganha
/// um anel branco.
class _Palette extends StatelessWidget {
  const _Palette(
      {required this.colors, required this.selected, required this.onPick});

  final List<LearningItem> colors;
  final LearningItem selected;
  final ValueChanged<LearningItem> onPick;

  @override
  Widget build(BuildContext context) {
    final half = (colors.length / 2).ceil();
    final rows = [colors.sublist(0, half), colors.sublist(half)];
    return Container(
      margin: const EdgeInsets.fromLTRB(10, 8, 10, 12),
      padding: const EdgeInsets.fromLTRB(6, 8, 6, 6),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: .85),
        borderRadius: BorderRadius.circular(30),
        boxShadow: const [
          BoxShadow(
              color: Color(0x1F000000), blurRadius: 10, offset: Offset(0, 4))
        ],
      ),
      child: LayoutBuilder(builder: (context, c) {
        final cell = math.min(66.0, c.maxWidth / half);
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            for (final row in rows)
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  for (final color in row)
                    _PaintPot(
                      key: ValueKey('pot-${color.id}'),
                      item: color,
                      size: cell,
                      selected: color.id == selected.id,
                      onTap: () => onPick(color),
                    ),
                ],
              ),
            const SizedBox(height: 2),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              child: Text(
                '${selected.pt} · ${selected.en}',
                key: ValueKey(selected.id),
                style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: AppColors.ink),
              ),
            ),
          ],
        );
      }),
    );
  }
}

class _PaintPot extends StatelessWidget {
  const _PaintPot({
    super.key,
    required this.item,
    required this.size,
    required this.selected,
    required this.onTap,
  });

  final LearningItem item;
  final double size;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      selected: selected,
      label: '${item.pt}, ${item.en}',
      child: Bouncy(
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeOutBack,
            width: size,
            height: size,
            padding: EdgeInsets.all(selected ? 0 : size * .1),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: selected ? const Color(0xFFFFF4C2) : Colors.transparent,
            ),
            child: PaintBlob(
              color: item.color,
              size: size,
              face: selected,
              phase: item.id.hashCode % 100 / 100,
            ),
          ),
        ),
      ),
    );
  }
}
