import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/learning_item.dart';
import '../services/audio_service.dart';
import '../services/settings_service.dart';
import '../theme/app_theme.dart';
import '../widgets/audio_controls.dart';
import '../widgets/glyph_character.dart';
import '../widgets/kid_top_bar.dart';
import '../widgets/page_swipe.dart';
import '../widgets/scene_background.dart';

/// Letras (A a Z) e números (0 a 10): desliza para o lado ou usa as setas.
/// O bloquinho fala o nome em português e inglês; nas letras, as palavras de
/// exemplo pulam quando são faladas; nos números, cada objeto acende na hora
/// em que a contagem chega nele.
class GlyphDetailScreen extends StatefulWidget {
  const GlyphDetailScreen({super.key, required this.category, required this.initialIndex});

  final Category category;
  final int initialIndex;

  @override
  State<GlyphDetailScreen> createState() => _GlyphDetailScreenState();
}

enum _Mode { none, speak, secondary }

/// Idioma de uma pronúncia de letra.
enum _Lang { pt, en }

class _GlyphDetailScreenState extends State<GlyphDetailScreen> {
  late final PageController _pages = PageController(initialPage: widget.initialIndex);
  late final AudioService _audio = context.read<AudioService>();
  late final SettingsService _settings = context.read<SettingsService>();
  late int _index = widget.initialIndex;

  /// Número que acabou de ser falado na contagem (acende os objetos até ele).
  int? _lit;

  /// Palavra de exemplo (letras) que está sendo falada agora.
  String? _activeExample;
  _Mode _mode = _Mode.none;
  int _session = 0;

  static final RegExp _numTag = RegExp(r'^num_(\d+):');
  static final RegExp _objTag = RegExp(r'^obj:(.+):(pt|en)$');

  List<LearningItem> get _items => widget.category.items;
  bool get _isNumbers => widget.category.kind == CategoryKind.numbers;

  @override
  void initState() {
    super.initState();
    _audio.playingTag.addListener(_onTag);
    // Ao abrir uma letra, ela se apresenta: português e depois inglês.
    WidgetsBinding.instance.addPostFrameCallback((_) => _autoSpeak());
  }

  void _autoSpeak() {
    if (!mounted || _isNumbers || !_settings.autoSpeakLetters) return;
    _speak(_items[_index]);
  }

  @override
  void dispose() {
    _audio.playingTag.removeListener(_onTag);
    _session++;
    _pages.dispose();
    super.dispose();
  }

  void _onTag() {
    if (!mounted) return;
    final tag = _audio.playingTag.value;
    if (tag == null) return;
    if (_isNumbers) {
      final m = _numTag.firstMatch(tag);
      if (m != null) setState(() => _lit = int.parse(m.group(1)!));
    } else {
      final m = _objTag.firstMatch(tag);
      if (m != null) setState(() => _activeExample = m.group(1));
    }
  }

  /// Toca um áudio e, quando termina (ou é interrompido), apaga os destaques.
  Future<void> _run(_Mode mode, Future<AudioOutcome> Function() start) async {
    final session = ++_session;
    setState(() {
      _mode = mode;
      _lit = null;
      _activeExample = null;
    });
    await runAudio(context, start());
    if (!mounted || session != _session) return;
    setState(() {
      _mode = _Mode.none;
      _lit = null;
      _activeExample = null;
    });
  }

  void _speak(LearningItem item) => _run(_Mode.speak, () => _audio.playWords(item));

  /// Ouve a letra só em um idioma (os dois nunca tocam ao mesmo tempo).
  void _speakLang(LearningItem item, _Lang lang) => _run(
        _Mode.none,
        () => lang == _Lang.pt ? _audio.playPt(item) : _audio.playEn(item),
      );

  void _secondary(LearningItem item) {
    if (_isNumbers) {
      final n = item.value ?? 0;
      if (n == 0) {
        _run(_Mode.secondary, () => _audio.playWords(item));
        return;
      }
      final numbers = _items;
      _run(_Mode.secondary, () => _audio.playCount(numbers, n));
    } else {
      _run(_Mode.secondary, () => _audio.playExamples(item.examples));
    }
  }

  void _example(ColorExample ex) =>
      _run(_Mode.none, () => _audio.playExample(ex));

  void _go(int delta) {
    final next = _index + delta;
    if (next < 0 || next >= _items.length) return;
    _pages.animateToPage(next,
        duration: const Duration(milliseconds: 320), curve: Curves.easeOutCubic);
  }

  @override
  Widget build(BuildContext context) {
    final cat = widget.category;
    final item = _items[_index];
    return Scaffold(
      body: SceneBackground(
        category: cat,
        child: SafeArea(
          child: Column(
            children: [
              KidTopBar(
                title: cat.titlePt,
                onBack: () => Navigator.of(context).pop(),
                backIcon: Icons.grid_view_rounded,
                backLabel: 'Voltar à lista',
              ),
              Expanded(
                child: PageSwipe(
                  controller: _pages,
                  child: Stack(
                    children: [
                      PageView.builder(
                        controller: _pages,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: _items.length,
                        onPageChanged: (i) {
                          _session++;
                          setState(() {
                            _index = i;
                            _mode = _Mode.none;
                            _lit = null;
                            _activeExample = null;
                          });
                          _audio.stop(); // interrompe o que estava tocando
                          _autoSpeak();
                        },
                        itemBuilder: (context, i) => _GlyphPage(
                          item: _items[i],
                          category: cat,
                          audio: _audio,
                          lit: i == _index ? _lit : null,
                          activeExample: i == _index ? _activeExample : null,
                          onSpeak: () => _speak(_items[i]),
                          onLang: (l) => _speakLang(_items[i], l),
                          onExample: _example,
                        ),
                      ),
                      Positioned(
                        left: 4,
                        top: 0,
                        bottom: 0,
                        child: _Arrow(
                            icon: Icons.chevron_left_rounded,
                            label: 'Anterior',
                            enabled: _index > 0,
                            onTap: () => _go(-1)),
                      ),
                      Positioned(
                        right: 4,
                        top: 0,
                        bottom: 0,
                        child: _Arrow(
                            icon: Icons.chevron_right_rounded,
                            label: 'Próximo',
                            enabled: _index < _items.length - 1,
                            onTap: () => _go(1)),
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                child: ValueListenableBuilder<String?>(
                  valueListenable: _audio.playingTag,
                  builder: (context, tag, _) => GlyphControls(
                    accent: cat.accent,
                    actions: _isNumbers
                        ? [
                            GlyphAction(
                              label: 'Falar',
                              icon: Icons.record_voice_over_rounded,
                              onTap: () => _speak(item),
                              active: _mode == _Mode.speak,
                            ),
                            GlyphAction(
                              label: 'Contar',
                              icon: Icons.exposure_plus_1_rounded,
                              onTap: () => _secondary(item),
                              active: _mode == _Mode.secondary,
                            ),
                          ]
                        : [
                            GlyphAction(
                              label: 'Português',
                              icon: Icons.record_voice_over_rounded,
                              onTap: () => _speakLang(item, _Lang.pt),
                              active: tag == '${item.id}:pt',
                            ),
                            GlyphAction(
                              label: 'English',
                              icon: Icons.language_rounded,
                              onTap: () => _speakLang(item, _Lang.en),
                              active: tag == '${item.id}:en',
                            ),
                            GlyphAction(
                              label: 'Palavras',
                              icon: Icons.menu_book_rounded,
                              onTap: () => _secondary(item),
                              active: _mode == _Mode.secondary,
                            ),
                          ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Arrow extends StatelessWidget {
  const _Arrow({required this.icon, required this.label, required this.enabled, required this.onTap});
  final IconData icon;
  final String label;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Opacity(
        opacity: enabled ? 1 : .25,
        child: RoundIconButton(
          icon: icon,
          label: label,
          background: Colors.white70,
          onPressed: enabled ? onTap : () {},
        ),
      ),
    );
  }
}

class _GlyphPage extends StatelessWidget {
  const _GlyphPage({
    required this.item,
    required this.category,
    required this.audio,
    required this.lit,
    required this.activeExample,
    required this.onSpeak,
    required this.onLang,
    required this.onExample,
  });

  final LearningItem item;
  final Category category;
  final AudioService audio;
  final int? lit;
  final String? activeExample;
  final VoidCallback onSpeak;
  final void Function(_Lang) onLang;
  final void Function(ColorExample) onExample;

  bool get _isNumbers => category.kind == CategoryKind.numbers;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final size = math.min(c.maxWidth * .5, c.maxHeight * .34).clamp(110.0, 260.0).toDouble();
      return Center(
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: SizedBox(
            width: c.maxWidth,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                GlyphCharacter(
                  item: item,
                  reaction: category.reaction,
                  size: size,
                  playingTag: audio.playingTag,
                  onTap: onSpeak,
                ),
                const SizedBox(height: 16),
                if (_isNumbers)
                  _NumberNameTag(item: item, accent: category.textAccent)
                else
                  _LetterNames(
                    item: item,
                    audio: audio,
                    accent: category.textAccent,
                    onLang: onLang,
                  ),
                const SizedBox(height: 14),
                if (_isNumbers)
                  _CountingObjects(item: item, lit: lit, width: math.max(160.0, c.maxWidth - 128))
                else
                  _ExampleTiles(
                    item: item,
                    activeExample: activeExample,
                    onExample: onExample,
                  ),
              ],
            ),
          ),
        ),
      );
    });
  }
}

/// Nome do número nos dois idiomas.
class _NumberNameTag extends StatelessWidget {
  const _NumberNameTag({required this.item, required this.accent});

  final LearningItem item;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.9),
        borderRadius: BorderRadius.circular(28),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(item.pt.toUpperCase(),
              style: const TextStyle(fontSize: 40, fontWeight: FontWeight.w900, color: AppColors.ink)),
          Text(item.en.toUpperCase(),
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: accent)),
        ],
      ),
    );
  }
}

/// Como a letra se chama em cada idioma. Cada linha é um botão: toca só aquele
/// idioma e acende (cresce e muda de cor) enquanto a voz fala.
class _LetterNames extends StatelessWidget {
  const _LetterNames({
    required this.item,
    required this.audio,
    required this.accent,
    required this.onLang,
  });

  final LearningItem item;
  final AudioService audio;
  final Color accent;
  final void Function(_Lang) onLang;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String?>(
      valueListenable: audio.playingTag,
      builder: (context, tag, _) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _LangRow(
            key: ValueKey('lang-pt-${item.id}'),
            flag: '🇧🇷',
            language: 'PT-BR',
            name: item.labelPt.toUpperCase(),
            active: tag == '${item.id}:pt',
            accent: accent,
            semantics: 'Ouvir ${item.labelPt} em português',
            onTap: () => onLang(_Lang.pt),
          ),
          const SizedBox(height: 8),
          _LangRow(
            key: ValueKey('lang-en-${item.id}'),
            flag: '🇺🇸',
            language: 'EN-US',
            name: item.labelEn.toUpperCase(),
            active: tag == '${item.id}:en',
            accent: accent,
            semantics: 'Listen to ${item.labelEn} in English',
            onTap: () => onLang(_Lang.en),
          ),
        ],
      ),
    );
  }
}

class _LangRow extends StatelessWidget {
  const _LangRow({
    super.key,
    required this.flag,
    required this.language,
    required this.name,
    required this.active,
    required this.accent,
    required this.semantics,
    required this.onTap,
  });

  final String flag;
  final String language;
  final String name;
  final bool active;
  final Color accent;
  final String semantics;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final fg = active ? Colors.white : AppColors.ink;
    return AnimatedScale(
      scale: active ? 1.08 : 1,
      duration: const Duration(milliseconds: 220),
      curve: Curves.easeOutBack,
      child: Semantics(
        button: true,
        label: semantics,
        child: Material(
          color: active ? accent : Colors.white.withOpacity(.92),
          elevation: active ? 6 : 2,
          borderRadius: BorderRadius.circular(26),
          child: InkWell(
            borderRadius: BorderRadius.circular(26),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(flag, style: const TextStyle(fontSize: 28)),
                  const SizedBox(width: 8),
                  Text(language,
                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: fg.withOpacity(.75))),
                  const SizedBox(width: 12),
                  Text(name, style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: fg)),
                  const SizedBox(width: 8),
                  Icon(active ? Icons.graphic_eq_rounded : Icons.volume_up_rounded, size: 26, color: fg),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Objetos para contar. Durante a contagem, os já falados ficam acesos e o
/// atual dá um pulinho; os que ainda não foram contados ficam apagados.
class _CountingObjects extends StatelessWidget {
  const _CountingObjects({required this.item, required this.lit, required this.width});

  final LearningItem item;
  final int? lit;
  final double width;

  @override
  Widget build(BuildContext context) {
    final n = item.value ?? 0;
    if (n == 0) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 12),
        child: Text('Nenhum! • None!',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.ink)),
      );
    }
    final fontSize = math.min(54.0, math.max(30.0, width / 5.6)).toDouble();
    return SizedBox(
      width: width,
      child: Wrap(
        alignment: WrapAlignment.center,
        spacing: 6,
        runSpacing: 6,
        children: [
          for (var k = 1; k <= n; k++)
            AnimatedScale(
              key: ValueKey('count-$k'),
              scale: lit == null ? 1.0 : (k == lit ? 1.35 : (k < lit! ? 1.0 : .8)),
              duration: const Duration(milliseconds: 220),
              curve: Curves.easeOutBack,
              child: AnimatedOpacity(
                opacity: lit == null || k <= lit! ? 1.0 : .25,
                duration: const Duration(milliseconds: 200),
                child: Text(item.emoji ?? '⭐', style: TextStyle(fontSize: fontSize)),
              ),
            ),
        ],
      ),
    );
  }
}

/// Palavras que começam com a letra; tocar fala em português e inglês.
class _ExampleTiles extends StatelessWidget {
  const _ExampleTiles({required this.item, required this.activeExample, required this.onExample});

  final LearningItem item;
  final String? activeExample;
  final void Function(ColorExample) onExample;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      alignment: WrapAlignment.center,
      spacing: 14,
      runSpacing: 14,
      children: [
        for (final ex in item.examples)
          AnimatedScale(
            key: ValueKey('example-${ex.id}'),
            scale: activeExample == ex.id ? 1.14 : 1.0,
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeOutBack,
            child: Semantics(
              button: true,
              label: '${ex.pt}. Toque para ouvir.',
              child: Material(
                color: Colors.white,
                elevation: activeExample == ex.id ? 7 : 3,
                borderRadius: BorderRadius.circular(24),
                child: InkWell(
                  borderRadius: BorderRadius.circular(24),
                  onTap: () => onExample(ex),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(ex.icon, style: const TextStyle(fontSize: 52)),
                        const SizedBox(height: 2),
                        Text(ex.pt,
                            style: const TextStyle(
                                fontSize: 17, fontWeight: FontWeight.w800, color: Color(0xFF1E1B3A))),
                        Text(ex.en,
                            style: const TextStyle(
                                fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFF455A64))),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}
