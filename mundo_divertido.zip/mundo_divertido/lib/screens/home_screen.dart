import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/content_repository.dart';
import '../games/games_hub_screen.dart';
import '../services/usage_service.dart';
import '../theme/app_theme.dart';
import '../widgets/bouncy.dart';
import '../widgets/category_card.dart';
import '../widgets/parents_sheet.dart';
import '../widgets/pop_in.dart';
import '../widgets/sky_backdrop.dart';
import '../models/learning_item.dart';
import 'body_screen.dart';
import 'category_screen.dart';
import 'party_screen.dart';
import '../widgets/app_route.dart';

const _title = 'Mundo Divertido';
const _titleColors = [
  Color(0xFFE5486B),
  Color(0xFFFF8A3D),
  Color(0xFFF2B400),
  Color(0xFF3DAA5C),
  Color(0xFF2E9BE0),
  Color(0xFF7C5CFF),
];

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final categories = context.read<ContentRepository>().categories;
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(
            child: Consumer<UsageService>(
                builder: (_, u, __) => SkyBackdrop(progress: u.progress)),
          ),
          SafeArea(
            child: Column(
              children: [
                Align(
                  alignment: Alignment.centerRight,
                  child: _ParentsButton(),
                ),
                Consumer<UsageService>(
                  builder: (_, u, __) {
                    final n = SkyPalette.nightness(u.progress);
                    return Column(
                      children: [
                        Floaty(
                          amplitude: 3,
                          child: Text.rich(
                            TextSpan(children: [
                              for (var i = 0; i < _title.length; i++)
                                TextSpan(
                                  text: _title[i],
                                  style: TextStyle(
                                    color: Color.lerp(
                                        _titleColors[i % _titleColors.length],
                                        Colors.white,
                                        n * .35),
                                  ),
                                ),
                            ]),
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 44,
                              fontWeight: FontWeight.w900,
                              letterSpacing: .5,
                              shadows: [
                                Shadow(
                                    color: Color.lerp(
                                        Colors.white, AppColors.ink, n)!,
                                    offset: const Offset(0, 3)),
                                const Shadow(
                                    color: Color(0x33000000),
                                    blurRadius: 6,
                                    offset: Offset(0, 4)),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'Aprenda brincando!',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w700,
                            color: Color.lerp(
                                AppColors.grape, const Color(0xFFE6DDFF), n),
                          ),
                        ),
                      ],
                    );
                  },
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                    child: _CategoryGrid(categories: categories),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  child: Row(
                    children: [
                      Expanded(
                        child: _BigButton(
                          color: AppColors.berry,
                          icon: Icons.sports_esports_rounded,
                          pt: 'Brincadeiras',
                          en: 'Games',
                          onTap: () => Navigator.of(context).push(
                            AppRoute<void>(
                                builder: (_) => const GamesHubScreen()),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _BigButton(
                          color: const Color(0xFF8E5BC4),
                          icon: Icons.celebration_rounded,
                          pt: 'Festa dos Bichos',
                          en: 'Animal party',
                          onTap: () => Navigator.of(context).push(
                            AppRoute<void>(builder: (_) => const PartyScreen()),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Botão grande da parte de baixo da tela inicial.
/// Cartões das categorias: dois por linha; a que sobra (Corpo) ocupa a
/// linha inteira, mais baixinha e deitada.
class _CategoryGrid extends StatelessWidget {
  const _CategoryGrid({required this.categories});

  final List<Category> categories;

  void _open(BuildContext context, Category c) {
    Navigator.of(context).push(AppRoute<void>(
      builder: (_) => c.kind == CategoryKind.body
          ? BodyScreen(category: c)
          : CategoryScreen(category: c),
    ));
  }

  @override
  Widget build(BuildContext context) {
    const gap = 14.0;
    final rows = <List<Category>>[];
    for (var i = 0; i < categories.length; i += 2) {
      rows.add(categories.sublist(
          i, i + 2 > categories.length ? categories.length : i + 2));
    }
    var n = 0;
    return Column(
      children: [
        for (var r = 0; r < rows.length; r++) ...[
          if (r > 0) const SizedBox(height: gap),
          Expanded(
            flex: rows[r].length == 1 ? 6 : 10,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                for (var k = 0; k < rows[r].length; k++) ...[
                  if (k > 0) const SizedBox(width: gap),
                  Expanded(
                    child: PopIn(
                      index: n++,
                      child: CategoryCard(
                        category: rows[r][k],
                        wide: rows[r].length == 1,
                        onTap: () => _open(context, rows[r][k]),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ],
    );
  }
}

class _BigButton extends StatelessWidget {
  const _BigButton({
    required this.color,
    required this.icon,
    required this.pt,
    required this.en,
    required this.onTap,
  });

  final Color color;
  final IconData icon;
  final String pt;
  final String en;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: pt,
      child: Bouncy(
        child: Material(
          color: color,
          elevation: 5,
          shadowColor: color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(32),
            side: const BorderSide(color: Colors.white, width: 3),
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(32),
            onTap: onTap,
            child: SizedBox(
              height: 76,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(icon, size: 34, color: Colors.white),
                    const SizedBox(width: 8),
                    Flexible(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          FittedBox(
                            fit: BoxFit.scaleDown,
                            child: Text(pt,
                                style: const TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.w900,
                                    color: Colors.white)),
                          ),
                          FittedBox(
                            fit: BoxFit.scaleDown,
                            child: Text(en,
                                style: const TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w700,
                                    color: Colors.white70)),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Botão discreto: só abre com toque longo, para a criança não mexer sem querer.
class _ParentsButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 12, top: 4),
      child: Tooltip(
        message: 'Responsáveis: mantenha pressionado',
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onLongPress: () => _openSettings(context),
          child: SizedBox(
            width: 48,
            height: 48,
            child: Consumer<UsageService>(
              builder: (_, u, __) => Icon(Icons.settings_rounded,
                  color: Color.lerp(Colors.black38, Colors.white60,
                      SkyPalette.nightness(u.progress))),
            ),
          ),
        ),
      ),
    );
  }

  void _openSettings(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (_) => const ParentsSheet(),
    );
  }
}
