import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/content_repository.dart';
import '../games/games_hub_screen.dart';
import '../services/settings_service.dart';
import '../theme/app_theme.dart';
import '../widgets/category_card.dart';
import '../widgets/pop_in.dart';
import 'category_screen.dart';
import 'party_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final categories = context.read<ContentRepository>().categories;
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppColors.mintTop, AppColors.mintBottom],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Align(
                alignment: Alignment.centerRight,
                child: _ParentsButton(),
              ),
              const Text(
                'Mundo Divertido',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 42,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -.5,
                  color: AppColors.ink,
                ),
              ),
              const SizedBox(height: 2),
              const Text(
                'Aprenda brincando!',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: AppColors.grape),
              ),
              Expanded(
                child: LayoutBuilder(builder: (context, c) {
                  const gap = 16.0;
                  const pad = 16.0;
                  final cardW = (c.maxWidth - pad * 2 - gap) / 2;
                  final cardH = (c.maxHeight - pad * 2 - gap) / 2;
                  return GridView.count(
                    physics: const NeverScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(pad),
                    crossAxisCount: 2,
                    mainAxisSpacing: gap,
                    crossAxisSpacing: gap,
                    childAspectRatio: cardW / cardH,
                    children: [
                      for (var i = 0; i < categories.length; i++)
                        PopIn(
                          index: i,
                          child: CategoryCard(
                            category: categories[i],
                            onTap: () => Navigator.of(context).push(
                              MaterialPageRoute<void>(
                                  builder: (_) => CategoryScreen(category: categories[i])),
                            ),
                          ),
                        ),
                    ],
                  );
                }),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: Row(
                  children: [
                    Expanded(
                      child: _BigButton(
                        color: AppColors.berry,
                        icon: Icons.sports_esports_rounded,
                        pt: 'Brincadeiras',
                        en: 'Games',
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute<void>(builder: (_) => const GamesHubScreen()),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _BigButton(
                        color: const Color(0xFF8E5BC4),
                        icon: Icons.celebration_rounded,
                        pt: 'Festa dos Bichos',
                        en: 'Animal party',
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute<void>(builder: (_) => const PartyScreen()),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Botão grande da parte de baixo da tela inicial.
class _BigButton extends StatelessWidget {
  const _BigButton({
    required this.color,
    required this.icon,
    required this.pt,
    required this.en,
    required this.onTap,
  });

  final Color color;
  final IconData icon;
  final String pt;
  final String en;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: pt,
      child: Material(
        color: color,
        elevation: 4,
        borderRadius: BorderRadius.circular(32),
        child: InkWell(
          borderRadius: BorderRadius.circular(32),
          onTap: onTap,
          child: SizedBox(
            height: 76,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, size: 34, color: Colors.white),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(pt,
                              style: const TextStyle(
                                  fontSize: 22, fontWeight: FontWeight.w900, color: Colors.white)),
                        ),
                        FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(en,
                              style: const TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.w700, color: Colors.white70)),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Botão discreto: só abre com toque longo, para a criança não mexer sem querer.
class _ParentsButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 12, top: 4),
      child: Tooltip(
        message: 'Responsáveis: mantenha pressionado',
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onLongPress: () => _openSettings(context),
          child: const SizedBox(
            width: 48,
            height: 48,
            child: Icon(Icons.settings_rounded, color: Colors.black38),
          ),
        ),
      ),
    );
  }

  void _openSettings(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (_) => const _ParentsSheet(),
    );
  }
}

class _ParentsSheet extends StatelessWidget {
  const _ParentsSheet();

  @override
  Widget build(BuildContext context) {
    return Consumer<SettingsService>(
      builder: (context, s, _) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 0, 24, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Área dos responsáveis',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 16),
            const Text('Volume', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            Slider(value: s.volume, onChanged: s.setVolume),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Silenciar sons de animais',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              subtitle: const Text('As pronúncias continuam tocando.'),
              value: s.effectsMuted,
              onChanged: s.setEffectsMuted,
            ),
          ],
        ),
      ),
    );
  }
}
