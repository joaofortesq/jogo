import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/content_repository.dart';
import '../games/games_hub_screen.dart';
import '../services/usage_service.dart';
import '../theme/app_theme.dart';
import '../widgets/category_card.dart';
import '../widgets/parents_sheet.dart';
import '../widgets/pop_in.dart';
import '../widgets/sky_backdrop.dart';
import 'category_screen.dart';
import 'party_screen.dart';
import '../widgets/app_route.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final categories = context.read<ContentRepository>().categories;
    return Scaffold(
      body: Stack(
        children: [
        Positioned.fill(
          child: Consumer<UsageService>(builder: (_, u, __) => SkyBackdrop(progress: u.progress)),
        ),
        SafeArea(
          child: Column(
            children: [
              Align(
                alignment: Alignment.centerRight,
                child: _ParentsButton(),
              ),
              Consumer<UsageService>(
                builder: (_, u, __) {
                  final n = SkyPalette.nightness(u.progress);
                  return Column(
                    children: [
                      Text(
                        'Mundo Divertido',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 42,
                          fontWeight: FontWeight.w900,
                          letterSpacing: -.5,
                          color: Color.lerp(AppColors.ink, Colors.white, n),
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Aprenda brincando!',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w700,
                          color: Color.lerp(AppColors.grape, const Color(0xFFE6DDFF), n),
                        ),
                      ),
                    ],
                  );
                },
              ),
              Expanded(
                child: LayoutBuilder(builder: (context, c) {
                  const gap = 16.0;
                  const pad = 16.0;
                  final cardW = (c.maxWidth - pad * 2 - gap) / 2;
                  final rows = (categories.length / 2).ceil();
                  final cardH = (c.maxHeight - pad * 2 - gap * (rows - 1)) / rows;
                  return GridView.count(
                    physics: const NeverScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(pad),
                    crossAxisCount: 2,
                    mainAxisSpacing: gap,
                    crossAxisSpacing: gap,
                    childAspectRatio: cardW / cardH,
                    children: [
                      for (var i = 0; i < categories.length; i++)
                        PopIn(
                          index: i,
                          child: CategoryCard(
                            category: categories[i],
                            onTap: () => Navigator.of(context).push(
                              AppRoute<void>(
                                  builder: (_) => CategoryScreen(category: categories[i])),
                            ),
                          ),
                        ),
                    ],
                  );
                }),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: Row(
                  children: [
                    Expanded(
                      child: _BigButton(
                        color: AppColors.berry,
                        icon: Icons.sports_esports_rounded,
                        pt: 'Brincadeiras',
                        en: 'Games',
                        onTap: () => Navigator.of(context).push(
                          AppRoute<void>(builder: (_) => const GamesHubScreen()),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _BigButton(
                        color: const Color(0xFF8E5BC4),
                        icon: Icons.celebration_rounded,
                        pt: 'Festa dos Bichos',
                        en: 'Animal party',
                        onTap: () => Navigator.of(context).push(
                          AppRoute<void>(builder: (_) => const PartyScreen()),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        ],
      ),
    );
  }
}

/// Botão grande da parte de baixo da tela inicial.
class _BigButton extends StatelessWidget {
  const _BigButton({
    required this.color,
    required this.icon,
    required this.pt,
    required this.en,
    required this.onTap,
  });

  final Color color;
  final IconData icon;
  final String pt;
  final String en;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: pt,
      child: Material(
        color: color,
        elevation: 4,
        borderRadius: BorderRadius.circular(32),
        child: InkWell(
          borderRadius: BorderRadius.circular(32),
          onTap: onTap,
          child: SizedBox(
            height: 76,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, size: 34, color: Colors.white),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(pt,
                              style: const TextStyle(
                                  fontSize: 22, fontWeight: FontWeight.w900, color: Colors.white)),
                        ),
                        FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(en,
                              style: const TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.w700, color: Colors.white70)),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Botão discreto: só abre com toque longo, para a criança não mexer sem querer.
class _ParentsButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 12, top: 4),
      child: Tooltip(
        message: 'Responsáveis: mantenha pressionado',
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onLongPress: () => _openSettings(context),
          child: SizedBox(
            width: 48,
            height: 48,
            child: Consumer<UsageService>(
              builder: (_, u, __) => Icon(Icons.settings_rounded,
                  color: Color.lerp(Colors.black38, Colors.white60, SkyPalette.nightness(u.progress))),
            ),
          ),
        ),
      ),
    );
  }

  void _openSettings(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (_) => const ParentsSheet(),
    );
  }
}
