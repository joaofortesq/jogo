import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/content_repository.dart';
import '../games/games_hub_screen.dart';
import '../services/settings_service.dart';
import '../theme/app_theme.dart';
import '../widgets/category_card.dart';
import 'category_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final categories = context.read<ContentRepository>().categories;
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppColors.mintTop, AppColors.mintBottom],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Align(
                alignment: Alignment.centerRight,
                child: _ParentsButton(),
              ),
              const Text(
                'Mundo Divertido',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 42,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -.5,
                  color: AppColors.ink,
                ),
              ),
              const SizedBox(height: 2),
              const Text(
                'Aprenda brincando!',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: AppColors.grape),
              ),
              Expanded(
                child: LayoutBuilder(builder: (context, c) {
                  const gap = 16.0;
                  const pad = 16.0;
                  final cardW = (c.maxWidth - pad * 2 - gap) / 2;
                  final cardH = (c.maxHeight - pad * 2 - gap) / 2;
                  return GridView.count(
                    physics: const NeverScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(pad),
                    crossAxisCount: 2,
                    mainAxisSpacing: gap,
                    crossAxisSpacing: gap,
                    childAspectRatio: cardW / cardH,
                    children: [
                      for (final cat in categories)
                        CategoryCard(
                          category: cat,
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute<void>(builder: (_) => CategoryScreen(category: cat)),
                          ),
                        ),
                    ],
                  );
                }),
              ),
              const _GamesButton(),
            ],
          ),
        ),
      ),
    );
  }
}

/// Faixa grande que leva às brincadeiras.
class _GamesButton extends StatelessWidget {
  const _GamesButton();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Semantics(
        button: true,
        label: 'Brincadeiras',
        child: Material(
          color: AppColors.berry,
          elevation: 4,
          borderRadius: BorderRadius.circular(32),
          child: InkWell(
            borderRadius: BorderRadius.circular(32),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(builder: (_) => const GamesHubScreen()),
            ),
            child: const SizedBox(
              height: 76,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.sports_esports_rounded, size: 40, color: Colors.white),
                  SizedBox(width: 12),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Brincadeiras',
                          style: TextStyle(
                              fontSize: 26, fontWeight: FontWeight.w900, color: Colors.white)),
                      Text('Games',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white70)),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Botão discreto: só abre com toque longo, para a criança não mexer sem querer.
class _ParentsButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 12, top: 4),
      child: Tooltip(
        message: 'Responsáveis: mantenha pressionado',
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onLongPress: () => _openSettings(context),
          child: const SizedBox(
            width: 48,
            height: 48,
            child: Icon(Icons.settings_rounded, color: Colors.black38),
          ),
        ),
      ),
    );
  }

  void _openSettings(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (_) => const _ParentsSheet(),
    );
  }
}

class _ParentsSheet extends StatelessWidget {
  const _ParentsSheet();

  @override
  Widget build(BuildContext context) {
    return Consumer<SettingsService>(
      builder: (context, s, _) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 0, 24, 32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Área dos responsáveis',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 16),
            const Text('Volume', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            Slider(value: s.volume, onChanged: s.setVolume),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Silenciar sons de animais',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              subtitle: const Text('As pronúncias continuam tocando.'),
              value: s.effectsMuted,
              onChanged: s.setEffectsMuted,
            ),
          ],
        ),
      ),
    );
  }
}
