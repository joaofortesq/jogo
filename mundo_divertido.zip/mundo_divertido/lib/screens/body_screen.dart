import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../games/body_game_screen.dart';
import '../models/learning_item.dart';
import '../services/audio_service.dart';
import '../theme/app_theme.dart';
import '../widgets/app_route.dart';
import '../widgets/audio_controls.dart';
import '../widgets/body_figure.dart';
import '../widgets/bouncy.dart';
import '../widgets/kid_top_bar.dart';

/// Partes do corpo: toca numa parte da criança e ela acende e fala o nome em
/// português e inglês. "Mostrar tudo" passa por todas as partes; "Onde
/// está?" abre a brincadeira.
class BodyScreen extends StatefulWidget {
  const BodyScreen({super.key, required this.category});

  final Category category;

  @override
  State<BodyScreen> createState() => _BodyScreenState();
}

class _BodyScreenState extends State<BodyScreen> {
  late final AudioService _audio = context.read<AudioService>();
  String? _part;
  bool _touring = false;

  List<LearningItem> get _items => widget.category.items;

  LearningItem? _item(String? id) {
    for (final i in _items) {
      if (i.id == id) return i;
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    _audio.playingTag.addListener(_onTag);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      runAudio(context,
          _audio.playMessage('corpo', 'Toque no corpo!', 'Touch the body!'));
    });
  }

  @override
  void dispose() {
    _audio.playingTag.removeListener(_onTag);
    unawaited(_audio.stop());
    super.dispose();
  }

  /// A parte que está sendo falada acende (também durante "Mostrar tudo").
  void _onTag() {
    final tag = _audio.playingTag.value;
    if (tag == null || !mounted) return;
    final id = tag.split(':').first;
    if (_item(id) != null && id != _part) setState(() => _part = id);
  }

  void _tapPart(String id) {
    final item = _item(id);
    if (item == null) return;
    setState(() {
      _part = id;
      _touring = false;
    });
    runAudio(context, _audio.playWords(item));
  }

  Future<void> _tour() async {
    if (_touring) {
      setState(() => _touring = false);
      await _audio.stop();
      return;
    }
    setState(() => _touring = true);
    await runAudio(context, _audio.playTour(_items));
    if (mounted) setState(() => _touring = false);
  }

  @override
  Widget build(BuildContext context) {
    final cat = widget.category;
    final item = _item(_part);
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [cat.background, const Color(0xFFFFF8F0)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              KidTopBar(
                  title: cat.titlePt,
                  onBack: () => Navigator.of(context).pop()),
              _NameBanner(item: item),
              Expanded(
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 24, vertical: 6),
                  child: BodyFigure(highlight: _part, onPart: _tapPart),
                ),
              ),
              _PartChips(items: _items, selected: _part, onTap: _tapPart),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 6, 16, 14),
                child: Row(
                  children: [
                    Expanded(
                      child: _BigAction(
                        icon: _touring
                            ? Icons.stop_rounded
                            : Icons.play_arrow_rounded,
                        pt: _touring ? 'Parar' : 'Mostrar tudo',
                        en: _touring ? 'Stop' : 'Show all',
                        color: AppColors.grape,
                        onTap: _tour,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _BigAction(
                        icon: Icons.search_rounded,
                        pt: 'Onde está?',
                        en: 'Where is it?',
                        color: cat.accent,
                        onTap: () {
                          _audio.stop();
                          Navigator.of(context).push(AppRoute<void>(
                              builder: (_) => BodyGameScreen(category: cat)));
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NameBanner extends StatelessWidget {
  const _NameBanner({required this.item});
  final LearningItem? item;

  @override
  Widget build(BuildContext context) {
    final i = item;
    return SizedBox(
      height: 84,
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 250),
        transitionBuilder: (c, a) => ScaleTransition(
          scale: Tween<double>(begin: .8, end: 1)
              .animate(CurvedAnimation(parent: a, curve: Curves.easeOutBack)),
          child: FadeTransition(opacity: a, child: c),
        ),
        child: Container(
          key: ValueKey(i?.id),
          margin: const EdgeInsets.symmetric(horizontal: 40),
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 6),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(28),
            border: Border(
                bottom: BorderSide(
                    color: i?.color ?? const Color(0xFFFFC107), width: 7)),
            boxShadow: const [
              BoxShadow(
                  color: Color(0x22000000),
                  blurRadius: 10,
                  offset: Offset(0, 4))
            ],
          ),
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                      i == null ? 'Toque no corpo!' : i.pt.toUpperCase(),
                      style: TextStyle(
                          fontSize: i == null ? 26 : 36,
                          fontWeight: FontWeight.w900,
                          color: AppColors.ink)),
                ),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                      i == null ? 'Touch the body!' : i.en.toUpperCase(),
                      style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                          color: AppColors.grape)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Fileira rolável com o nome de todas as partes (também acende a parte).
class _PartChips extends StatelessWidget {
  const _PartChips(
      {required this.items, required this.selected, required this.onTap});

  final List<LearningItem> items;
  final String? selected;
  final ValueChanged<String> onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 58,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final it = items[i];
          final on = it.id == selected;
          return Bouncy(
            child: Semantics(
              button: true,
              label: '${it.pt}, ${it.en}',
              child: GestureDetector(
                onTap: () => onTap(it.id),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  decoration: BoxDecoration(
                    color: on ? it.color : Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: it.color, width: 3),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(it.pt,
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                              color: on ? Colors.white : AppColors.ink)),
                      Text(it.en,
                          style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              color:
                                  on ? Colors.white : const Color(0xFF6A5ACD))),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _BigAction extends StatelessWidget {
  const _BigAction({
    required this.icon,
    required this.pt,
    required this.en,
    required this.color,
    required this.onTap,
  });

  final IconData icon;
  final String pt;
  final String en;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: pt,
      child: Bouncy(
        child: Material(
          color: color,
          elevation: 4,
          shadowColor: color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(26),
            side: const BorderSide(color: Colors.white, width: 3),
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(26),
            onTap: onTap,
            child: SizedBox(
              height: 70,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(icon, size: 32, color: Colors.white),
                  const SizedBox(width: 6),
                  Flexible(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(pt,
                              style: const TextStyle(
                                  fontSize: 19,
                                  fontWeight: FontWeight.w900,
                                  color: Colors.white)),
                        ),
                        FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(en,
                              style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.white70)),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
