import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/learning_item.dart';
import '../services/audio_service.dart';
import '../widgets/audio_controls.dart';
import '../widgets/kid_top_bar.dart';
import '../widgets/page_swipe.dart';
import '../widgets/learning_card.dart' show onColor;

const _icons = <String, IconData>{
  'favorite': Icons.favorite_rounded,
  'flag': Icons.flag_rounded,
  'water_drop': Icons.water_drop_rounded,
  'waves': Icons.waves_rounded,
  'wb_sunny': Icons.wb_sunny_rounded,
  'star': Icons.star_rounded,
  'eco': Icons.eco_rounded,
  'park': Icons.park_rounded,
  'sports_basketball': Icons.sports_basketball_rounded,
  'local_fire_department': Icons.local_fire_department_rounded,
  'diamond': Icons.diamond_rounded,
  'auto_awesome': Icons.auto_awesome_rounded,
  'cake': Icons.cake_rounded,
  'local_florist': Icons.local_florist_rounded,
  'train': Icons.train_rounded,
  'nightlight_round': Icons.nightlight_round,
  'ac_unit': Icons.ac_unit_rounded,
  'cloud': Icons.cloud_rounded,
  'forest': Icons.forest_rounded,
  'pets': Icons.pets_rounded,
};

/// Módulo de cores: a tela inteira assume a cor escolhida.
class ColorDetailScreen extends StatefulWidget {
  const ColorDetailScreen({super.key, required this.category, required this.initialIndex});

  final Category category;
  final int initialIndex;

  @override
  State<ColorDetailScreen> createState() => _ColorDetailScreenState();
}

class _ColorDetailScreenState extends State<ColorDetailScreen> {
  late final PageController _pages = PageController(initialPage: widget.initialIndex);
  late int _index = widget.initialIndex;

  List<LearningItem> get _items => widget.category.items;

  @override
  void dispose() {
    _pages.dispose();
    super.dispose();
  }

  void _go(int delta) {
    final next = _index + delta;
    if (next < 0 || next >= _items.length) return;
    _pages.animateToPage(next,
        duration: const Duration(milliseconds: 320), curve: Curves.easeOutCubic);
  }

  @override
  Widget build(BuildContext context) {
    final audio = context.read<AudioService>();
    final item = _items[_index];
    final fg = onColor(item.color);
    return AnimatedContainer(
      duration: const Duration(milliseconds: 350),
      color: item.color,
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          child: Column(
            children: [
              KidTopBar(
                onBack: () => Navigator.of(context).pop(),
                backIcon: Icons.grid_view_rounded,
                backLabel: 'Voltar à lista',
                foreground: fg,
              ),
              Expanded(
                child: PageSwipe(
                  controller: _pages,
                  child: Stack(
                  children: [
                    PageView.builder(
                      controller: _pages,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: _items.length,
                      onPageChanged: (i) {
                        setState(() => _index = i);
                        audio.stop();
                      },
                      itemBuilder: (context, i) => _ColorPage(item: _items[i]),
                    ),
                    Positioned(
                      left: 4, top: 0, bottom: 0,
                      child: Center(
                        child: Opacity(
                          opacity: _index > 0 ? 1 : .25,
                          child: RoundIconButton(
                            icon: Icons.chevron_left_rounded,
                            label: 'Anterior',
                            background: Colors.white,
                            onPressed: () => _go(-1),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      right: 4, top: 0, bottom: 0,
                      child: Center(
                        child: Opacity(
                          opacity: _index < _items.length - 1 ? 1 : .25,
                          child: RoundIconButton(
                            icon: Icons.chevron_right_rounded,
                            label: 'Próximo',
                            background: Colors.white,
                            onPressed: () => _go(1),
                          ),
                        ),
                      ),
                    ),
                  ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                child: AudioControls(item: item, accent: Colors.black87),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ColorPage extends StatefulWidget {
  const _ColorPage({required this.item});
  final LearningItem item;

  @override
  State<_ColorPage> createState() => _ColorPageState();
}

class _ColorPageState extends State<_ColorPage> with SingleTickerProviderStateMixin {
  late final AnimationController _pulse =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 600));

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  void _say() {
    _pulse.forward(from: 0);
    runAudio(context, context.read<AudioService>().playAll(widget.item));
  }

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    final fg = onColor(item.color);
    final audio = context.read<AudioService>();
    final tileBg = item.color.computeLuminance() > .85 ? const Color(0xFFB0BEC5) : Colors.white;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 76),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Semantics(
            button: true,
            label: '${item.pt}. Toque para ouvir.',
            child: GestureDetector(
              onTap: _say,
              child: AnimatedBuilder(
                animation: _pulse,
                builder: (context, child) => Transform.scale(
                  scale: 1 + math.sin(_pulse.value * math.pi) * .07,
                  child: child,
                ),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 36),
                  decoration: BoxDecoration(
                    color: item.color,
                    borderRadius: BorderRadius.circular(40),
                    border: Border.all(color: fg, width: 6),
                  ),
                  child: Column(
                    children: [
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text(item.pt.toUpperCase(),
                            style: TextStyle(fontSize: 46, fontWeight: FontWeight.w900, color: fg)),
                      ),
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text(item.en.toUpperCase(),
                            style: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: fg)),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 28),
          Wrap(
            spacing: 14,
            runSpacing: 14,
            alignment: WrapAlignment.center,
            children: [
              for (final ex in item.examples)
                Semantics(
                  button: true,
                  label: '${ex.pt}. Toque para ouvir a cor.',
                  child: Material(
                    color: tileBg,
                    elevation: 3,
                    borderRadius: BorderRadius.circular(24),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(24),
                      // Tocar no objeto fala o nome dele em português e inglês.
                      onTap: () => runAudio(context, audio.playExample(ex)),
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(_icons[ex.icon] ?? Icons.circle, size: 52, color: item.color),
                            const SizedBox(height: 4),
                            Text(ex.pt,
                                style: const TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.w800, color: Color(0xFF1E1B3A))),
                            Text(ex.en,
                                style: const TextStyle(
                                    fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFF455A64))),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}
