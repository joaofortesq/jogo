import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/learning_item.dart';
import '../services/audio_service.dart';
import '../services/settings_service.dart';
import '../theme/app_theme.dart';
import '../widgets/app_route.dart';
import '../widgets/audio_controls.dart';
import '../widgets/bouncy.dart';
import '../widgets/kid_top_bar.dart';
import '../widgets/page_swipe.dart';
import '../widgets/paint_blob.dart';
import 'paint_screen.dart';

/// Fundo suave da cor: mistura a cor com branco (preto e branco ganham um
/// fundo que deixa a gotinha aparecer).
Color colorBackdrop(Color c) {
  final lum = c.computeLuminance();
  if (lum > .85) return const Color(0xFFDDE7EE);
  if (lum < .03) return const Color(0xFF3A3950);
  return Color.lerp(c, Colors.white, .62)!;
}

/// Módulo de cores: cada cor é uma gotinha de tinta com carinha que fala o
/// próprio nome em português e em inglês, com três coisas daquela cor.
class ColorDetailScreen extends StatefulWidget {
  const ColorDetailScreen(
      {super.key, required this.category, required this.initialIndex});

  final Category category;
  final int initialIndex;

  @override
  State<ColorDetailScreen> createState() => _ColorDetailScreenState();
}

class _ColorDetailScreenState extends State<ColorDetailScreen> {
  late final PageController _pages =
      PageController(initialPage: widget.initialIndex);
  late final AudioService _audio = context.read<AudioService>();
  late final SettingsService _settings = context.read<SettingsService>();
  late int _index = widget.initialIndex;

  List<LearningItem> get _items => widget.category.items;

  @override
  void initState() {
    super.initState();
    // Ao abrir, a cor se apresenta: português e logo depois inglês.
    WidgetsBinding.instance.addPostFrameCallback((_) => _autoSpeak());
  }

  void _autoSpeak() {
    if (!mounted || !_settings.autoSpeakLetters) return;
    runAudio(context, _audio.playWords(_items[_index]));
  }

  @override
  void dispose() {
    _pages.dispose();
    super.dispose();
  }

  void _go(int delta) {
    final next = _index + delta;
    if (next < 0 || next >= _items.length) return;
    _pages.animateToPage(next,
        duration: const Duration(milliseconds: 320),
        curve: Curves.easeOutCubic);
  }

  @override
  Widget build(BuildContext context) {
    final item = _items[_index];
    final dark = item.color.computeLuminance() < .03;
    final fg = dark ? Colors.white : AppColors.ink;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 450),
      curve: Curves.easeOutCubic,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            colorBackdrop(item.color),
            Color.lerp(colorBackdrop(item.color), Colors.white, .5)!
          ],
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Stack(
          children: [
            Positioned.fill(child: _Sparkles(color: item.color)),
            SafeArea(
              child: Column(
                children: [
                  KidTopBar(
                    title: widget.category.titlePt,
                    onBack: () => Navigator.of(context).pop(),
                    backIcon: Icons.grid_view_rounded,
                    backLabel: 'Voltar à lista',
                    foreground: fg,
                  ),
                  Expanded(
                    child: PageSwipe(
                      controller: _pages,
                      child: Stack(
                        children: [
                          PageView.builder(
                            controller: _pages,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: _items.length,
                            onPageChanged: (i) {
                              setState(() => _index = i);
                              _audio.stop();
                              _autoSpeak();
                            },
                            itemBuilder: (context, i) =>
                                _ColorPage(item: _items[i]),
                          ),
                          Positioned(
                            left: 4,
                            top: 0,
                            bottom: 0,
                            child: Center(
                              child: Opacity(
                                opacity: _index > 0 ? 1 : .25,
                                child: RoundIconButton(
                                  icon: Icons.chevron_left_rounded,
                                  label: 'Anterior',
                                  onPressed: () => _go(-1),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            right: 4,
                            top: 0,
                            bottom: 0,
                            child: Center(
                              child: Opacity(
                                opacity: _index < _items.length - 1 ? 1 : .25,
                                child: RoundIconButton(
                                  icon: Icons.chevron_right_rounded,
                                  label: 'Próximo',
                                  onPressed: () => _go(1),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                    child: Row(
                      children: [
                        Expanded(
                            child: AudioControls(
                                item: item, accent: AppColors.grape)),
                        const SizedBox(width: 12),
                        Expanded(
                          child: PaintButton(
                            onTap: () =>
                                Navigator.of(context).push(AppRoute<void>(
                              builder: (_) => PaintScreen(
                                  colors: _items, initialColor: item.id),
                            )),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Botão "Pintar" (abre a atividade de pintar).
class PaintButton extends StatelessWidget {
  const PaintButton({super.key, required this.onTap, this.height = 84});

  final VoidCallback onTap;
  final double height;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: 'Pintar',
      child: Bouncy(
        child: Container(
          height: height,
          width: double.infinity,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(26),
            gradient: const LinearGradient(
              colors: [
                Color(0xFFFF6B8B),
                Color(0xFFFFB13C),
                Color(0xFF4CC38A),
                Color(0xFF5AA9FF)
              ],
            ),
            border: Border.all(color: Colors.white, width: 3),
            boxShadow: const [
              BoxShadow(
                  color: Color(0x33000000), blurRadius: 6, offset: Offset(0, 3))
            ],
          ),
          child: Material(
            type: MaterialType.transparency,
            child: InkWell(
              borderRadius: BorderRadius.circular(26),
              onTap: onTap,
              child: const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.brush_rounded, size: 34, color: Colors.white),
                  FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text('Pintar · Paint',
                        style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w900,
                            color: Colors.white)),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ColorPage extends StatefulWidget {
  const _ColorPage({required this.item});
  final LearningItem item;

  @override
  State<_ColorPage> createState() => _ColorPageState();
}

class _ColorPageState extends State<_ColorPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _jump = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 700));

  @override
  void dispose() {
    _jump.dispose();
    super.dispose();
  }

  void _say() {
    _jump.forward(from: 0);
    runAudio(context, context.read<AudioService>().playWords(widget.item));
  }

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    final audio = context.read<AudioService>();
    return LayoutBuilder(builder: (context, c) {
      final blobSize =
          math.min(c.maxWidth - 150, c.maxHeight * .42).clamp(110.0, 320.0);
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: ValueListenableBuilder<String?>(
          valueListenable: audio.playingTag,
          builder: (context, tag, _) {
            final talking = tag == '${item.id}:pt' || tag == '${item.id}:en';
            return Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Semantics(
                  button: true,
                  label: '${item.pt}. Toque para ouvir.',
                  child: GestureDetector(
                    onTap: _say,
                    child: AnimatedBuilder(
                      animation: _jump,
                      builder: (context, child) {
                        final v = _jump.value;
                        // agacha, pula e cai achatadinho
                        final up = math.sin(v * math.pi) * blobSize * .18;
                        final squash = v < .15
                            ? 1 - math.sin(v / .15 * math.pi) * .12
                            : (v > .85
                                ? 1 - math.sin((v - .85) / .15 * math.pi) * .10
                                : 1.0);
                        return Transform.translate(
                          offset: Offset(0, -up),
                          child: Transform.scale(
                            alignment: Alignment.bottomCenter,
                            scaleY: squash,
                            scaleX: 2 - squash,
                            child: child,
                          ),
                        );
                      },
                      child: PaintBlob(
                          color: item.color, size: blobSize, talking: talking),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                _NameCard(item: item, tag: tag, onTap: _say),
                const SizedBox(height: 18),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    for (final ex in item.examples)
                      Flexible(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 6),
                          child: _ExampleTile(
                            example: ex,
                            color: item.color,
                            active: tag == 'obj:${ex.id}:pt' ||
                                tag == 'obj:${ex.id}:en',
                            onTap: () =>
                                runAudio(context, audio.playExample(ex)),
                          ),
                        ),
                      ),
                  ],
                ),
              ],
            );
          },
        ),
      );
    });
  }
}

/// Cartão com o nome: português grande e inglês logo abaixo. O idioma que
/// está sendo falado cresce um pouquinho.
class _NameCard extends StatelessWidget {
  const _NameCard({required this.item, required this.tag, required this.onTap});

  final LearningItem item;
  final String? tag;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ptOn = tag == '${item.id}:pt';
    final enOn = tag == '${item.id}:en';
    final stripe = item.color.computeLuminance() > .85
        ? const Color(0xFFB0BEC5)
        : item.color;
    return Bouncy(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: double.infinity,
          margin: const EdgeInsets.symmetric(horizontal: 64),
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(30),
            border: Border(bottom: BorderSide(color: stripe, width: 8)),
            boxShadow: const [
              BoxShadow(
                  color: Color(0x26000000),
                  blurRadius: 10,
                  offset: Offset(0, 4))
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AnimatedScale(
                scale: ptOn ? 1.12 : 1,
                duration: const Duration(milliseconds: 180),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(item.pt.toUpperCase(),
                      style: const TextStyle(
                          fontSize: 42,
                          fontWeight: FontWeight.w900,
                          color: AppColors.ink)),
                ),
              ),
              AnimatedScale(
                scale: enOn ? 1.15 : 1,
                duration: const Duration(milliseconds: 180),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(item.en.toUpperCase(),
                      style: const TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.w800,
                          color: AppColors.grape)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ExampleTile extends StatelessWidget {
  const _ExampleTile({
    required this.example,
    required this.color,
    required this.active,
    required this.onTap,
  });

  final ColorExample example;
  final Color color;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ring =
        color.computeLuminance() > .85 ? const Color(0xFFB0BEC5) : color;
    return Semantics(
      button: true,
      label: '${example.pt}. Toque para ouvir.',
      child: AnimatedSlide(
        offset: Offset(0, active ? -.08 : 0),
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOutBack,
        child: Bouncy(
          child: Material(
            color: Colors.white,
            elevation: active ? 8 : 3,
            shadowColor: ring,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
              side: BorderSide(color: ring, width: active ? 5 : 3),
            ),
            child: InkWell(
              borderRadius: BorderRadius.circular(24),
              onTap: onTap,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(8, 10, 8, 10),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    FittedBox(
                        child: Text(example.icon,
                            style: const TextStyle(fontSize: 48))),
                    const SizedBox(height: 2),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(example.pt,
                          style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                              color: AppColors.ink)),
                    ),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Text(example.en,
                          style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFF6A5ACD))),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// Bolinhas de tinta flutuando ao fundo, na cor da página.
class _Sparkles extends StatefulWidget {
  const _Sparkles({required this.color});
  final Color color;

  @override
  State<_Sparkles> createState() => _SparklesState();
}

class _SparklesState extends State<_Sparkles>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 12));
  bool _started = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_started) return;
    _started = true;
    if (!MediaQuery.of(context).disableAnimations) _c.repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: RepaintBoundary(
        child: AnimatedBuilder(
          animation: _c,
          builder: (context, _) =>
              CustomPaint(painter: _SparklePainter(widget.color, _c.value)),
        ),
      ),
    );
  }
}

class _SparklePainter extends CustomPainter {
  _SparklePainter(this.color, this.t);
  final Color color;
  final double t;

  @override
  void paint(Canvas canvas, Size size) {
    final white = color.computeLuminance() > .85;
    final paint = Paint()
      ..color =
          (white ? Colors.white : color).withValues(alpha: white ? .8 : .22);
    for (var k = 0; k < 9; k++) {
      final x = size.width * ((k * .113 + .05) % 1.0) +
          math.sin((t * 2 + k * .3) * 2 * math.pi) * 18;
      final y = size.height * (1.08 - ((t + k / 9) % 1.0) * 1.2);
      canvas.drawCircle(Offset(x, y), 10.0 + (k % 4) * 9, paint);
    }
  }

  @override
  bool shouldRepaint(_SparklePainter old) => old.t != t || old.color != color;
}
