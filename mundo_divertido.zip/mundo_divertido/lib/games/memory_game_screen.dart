import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/content_repository.dart';
import '../models/learning_item.dart';
import '../services/audio_service.dart';
import '../theme/app_theme.dart';
import '../widgets/audio_controls.dart';
import '../widgets/item_art.dart';
import 'game_logic.dart';
import 'game_widgets.dart';

/// Jogo da memória: vire duas cartas e ache os pares.
/// Começa com 3 pares e sobe até 6 a cada vitória seguida.
class MemoryGameScreen extends StatefulWidget {
  const MemoryGameScreen({super.key, this.random});

  final Random? random;

  @override
  State<MemoryGameScreen> createState() => _MemoryGameScreenState();
}

class _MemoryGameScreenState extends State<MemoryGameScreen> {
  static const _mismatchDelay = Duration(milliseconds: 1100);

  late final AudioService _audio;
  late final ContentRepository _repo;
  late final Random _rng;

  late Category _category;
  late MemoryGame _game;
  int _level = 0;
  bool _won = false;
  int _session = 0;
  Timer? _timer;

  int get _pairs => min(6, 3 + _level);

  @override
  void initState() {
    super.initState();
    _audio = context.read<AudioService>();
    _repo = context.read<ContentRepository>();
    _rng = widget.random ?? Random();
    _deal();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _session++;
    unawaited(_audio.stop());
    super.dispose();
  }

  void _deal() {
    final cats = _repo.categories.where((c) => c.kind != CategoryKind.colors).toList();
    _category = cats[_rng.nextInt(cats.length)];
    _game = MemoryGame(_category.items, pairs: _pairs, random: _rng);
    _won = false;
    _timer?.cancel();
    _session++;
  }

  void _replay() {
    _level++;
    setState(_deal);
  }

  Future<void> _tap(int index) async {
    if (_won) return;
    final result = _game.flip(index);
    if (result == FlipResult.ignored) return;
    setState(() {});
    final item = _game.cards[index].item;
    final session = _session;
    switch (result) {
      case FlipResult.ignored:
        return;
      case FlipResult.first:
        unawaited(runAudio(context, _audio.playPt(item)));
      case FlipResult.mismatch:
        unawaited(runAudio(context, _audio.playPt(item)));
        _timer?.cancel();
        _timer = Timer(_mismatchDelay, () {
          if (!mounted || session != _session) return;
          setState(_game.resolveMismatch);
        });
      case FlipResult.match:
        await runAudio(context, _audio.playWords(item));
        if (!mounted || session != _session) return;
        if (_game.won) {
          setState(() => _won = true);
          unawaited(_audio.praise());
        }
    }
  }

  int get _matchedPairs => _game.cards.where((c) => c.matched).length ~/ 2;

  @override
  Widget build(BuildContext context) {
    return GameFrame(
      category: _category,
      title: 'Memória',
      winOverlay: _won
          ? WinOverlay(
              onReplay: _replay,
              onExit: () => Navigator.of(context).pop(),
              detail: 'Você achou todos os pares em ${_game.moves} jogadas.',
            )
          : null,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: ProgressStars(total: _pairs, done: _matchedPairs),
          ),
          Expanded(
            child: LayoutBuilder(builder: (context, c) {
              const gap = 12.0;
              final n = _game.cards.length;
              var bestSide = 0.0;
              for (final cols in [2, 3, 4]) {
                final rows = (n / cols).ceil();
                final side = min((c.maxWidth - 32 - gap * (cols - 1)) / cols,
                    (c.maxHeight - 16 - gap * (rows - 1)) / rows);
                if (side > bestSide) bestSide = side;
              }
              final side = max(56.0, min(bestSide, 170.0));
              return Center(
                child: Wrap(
                  alignment: WrapAlignment.center,
                  spacing: gap,
                  runSpacing: gap,
                  children: [
                    for (var i = 0; i < n; i++)
                      SizedBox(
                        width: side,
                        height: side,
                        child: _MemoryTile(
                          key: ValueKey('card-$i'),
                          card: _game.cards[i],
                          accent: _category.textAccent,
                          onTap: () => _tap(i),
                        ),
                      ),
                  ],
                ),
              );
            }),
          ),
        ],
      ),
    );
  }
}

class _MemoryTile extends StatelessWidget {
  const _MemoryTile({super.key, required this.card, required this.accent, required this.onTap});

  final MemoryCard card;
  final Color accent;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final shown = card.faceUp || card.matched;
    return Semantics(
      button: true,
      label: shown ? card.item.pt : 'Carta virada para baixo',
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: TweenAnimationBuilder<double>(
          tween: Tween<double>(end: shown ? 1.0 : 0.0),
          duration: const Duration(milliseconds: 320),
          curve: Curves.easeInOut,
          builder: (context, v, _) {
            final front = v >= .5;
            return Transform(
              alignment: Alignment.center,
              transform: Matrix4.identity()
                ..setEntry(3, 2, 0.001)
                ..rotateY(v * pi),
              child: front
                  ? Transform(
                      alignment: Alignment.center,
                      transform: Matrix4.rotationY(pi),
                      child: _Front(item: card.item, matched: card.matched),
                    )
                  : _Back(color: accent),
            );
          },
        ),
      ),
    );
  }
}

class _Back extends StatelessWidget {
  const _Back({required this.color});

  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white, width: 4),
        boxShadow: const [
          BoxShadow(color: Color(0x33000000), blurRadius: 6, offset: Offset(0, 3)),
        ],
      ),
      child: const Center(
        child: Icon(Icons.star_rounded, size: 44, color: Colors.white70),
      ),
    );
  }
}

class _Front extends StatelessWidget {
  const _Front({required this.item, required this.matched});

  final LearningItem item;
  final bool matched;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: matched ? AppColors.grass : Colors.black12,
          width: matched ? 5 : 3,
        ),
      ),
      child: LayoutBuilder(
        builder: (context, c) =>
            Center(child: ItemArt(item: item, size: c.biggest.shortestSide)),
      ),
    );
  }
}
