import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/learning_item.dart';
import '../theme/app_theme.dart';
import '../widgets/kid_top_bar.dart';
import '../widgets/scene_background.dart';

/// Moldura comum das brincadeiras: cenário, barra superior e tela de vitória.
class GameFrame extends StatelessWidget {
  const GameFrame({
    super.key,
    required this.category,
    required this.title,
    required this.child,
    this.winOverlay,
  });

  final Category category;
  final String title;
  final Widget child;

  /// Quando não nulo, aparece por cima de tudo (fim da brincadeira).
  final Widget? winOverlay;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SceneBackground(
        category: category,
        child: Stack(
          fit: StackFit.expand,
          children: [
            SafeArea(
              child: Column(
                children: [
                  KidTopBar(title: title, onBack: () => Navigator.of(context).pop()),
                  Expanded(child: child),
                ],
              ),
            ),
            if (winOverlay != null) winOverlay!,
          ],
        ),
      ),
    );
  }
}

/// Fileira de estrelas: as já conquistadas ficam cheias.
class ProgressStars extends StatelessWidget {
  const ProgressStars({super.key, required this.total, required this.done});

  final int total;
  final int done;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: '$done de $total',
      child: ExcludeSemantics(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            for (var i = 0; i < total; i++)
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 350),
                transitionBuilder: (c, a) => ScaleTransition(scale: a, child: c),
                child: Icon(
                  i < done ? Icons.star_rounded : Icons.star_outline_rounded,
                  key: ValueKey('$i-${i < done}'),
                  size: 36,
                  color: i < done ? AppColors.sun : Colors.black38,
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/// Botão redondo grande de alto-falante ("ouvir de novo").
class SpeakerButton extends StatelessWidget {
  const SpeakerButton({super.key, required this.onTap, required this.color, this.size = 96});

  final VoidCallback onTap;
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: 'Ouvir de novo',
      child: Material(
        color: color,
        elevation: 5,
        shape: const CircleBorder(side: BorderSide(color: Colors.white, width: 4)),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: SizedBox(
            width: size,
            height: size,
            child: Icon(Icons.volume_up_rounded, size: size * .56, color: Colors.white),
          ),
        ),
      ),
    );
  }
}

/// Balança de lado a lado cada vez que [shakes] aumenta (resposta errada).
class ShakeWidget extends StatefulWidget {
  const ShakeWidget({super.key, required this.shakes, required this.child});

  final int shakes;
  final Widget child;

  @override
  State<ShakeWidget> createState() => _ShakeWidgetState();
}

class _ShakeWidgetState extends State<ShakeWidget> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 420));

  @override
  void didUpdateWidget(ShakeWidget old) {
    super.didUpdateWidget(old);
    if (widget.shakes != old.shakes) _c.forward(from: 0);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      child: widget.child,
      builder: (context, child) {
        final t = _c.value;
        return Transform.translate(
          offset: Offset(math.sin(t * math.pi * 6) * 10 * (1 - t), 0),
          child: child,
        );
      },
    );
  }
}

/// Pulsa de leve, três vezes, quando [active] passa a ser verdadeiro: dica
/// amigável para mostrar a opção certa depois de algumas tentativas.
class HintPulse extends StatefulWidget {
  const HintPulse({super.key, required this.active, required this.child});

  final bool active;
  final Widget child;

  @override
  State<HintPulse> createState() => _HintPulseState();
}

class _HintPulseState extends State<HintPulse> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1500));

  @override
  void didUpdateWidget(HintPulse old) {
    super.didUpdateWidget(old);
    if (widget.active && !old.active) _c.forward(from: 0);
    if (!widget.active && old.active) _c.value = 0;
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      child: widget.child,
      builder: (context, child) => Transform.scale(
        scale: 1 + .07 * math.sin(_c.value * math.pi * 6).abs() * (1 - _c.value * .4),
        child: child,
      ),
    );
  }
}

/// Explosão de estrelinhas (uma vez) para comemorar um acerto.
class StarBurst extends StatefulWidget {
  const StarBurst({super.key});

  @override
  State<StarBurst> createState() => _StarBurstState();
}

class _StarBurstState extends State<StarBurst> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
  bool _started = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_started) return;
    _started = true;
    if (MediaQuery.of(context).disableAnimations) {
      _c.value = 1;
    } else {
      _c.forward();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: RepaintBoundary(
        child: AnimatedBuilder(
          animation: _c,
          builder: (context, _) => CustomPaint(painter: _BurstPainter(_c.value)),
        ),
      ),
    );
  }
}

class _BurstPainter extends CustomPainter {
  _BurstPainter(this.t);

  final double t;

  static const _colors = [
    Color(0xFFFFC93C),
    Color(0xFFFF6B8B),
    Color(0xFF4CC38A),
    Color(0xFF5AA9FF),
  ];

  @override
  void paint(Canvas canvas, Size size) {
    if (t <= 0 || t >= 1) return;
    final c = size.center(Offset.zero);
    final reach = size.shortestSide * (.55 + .35 * Curves.easeOutCubic.transform(t));
    for (var i = 0; i < 10; i++) {
      final a = i * math.pi * 2 / 10;
      final p = c + Offset(math.cos(a), math.sin(a)) * reach;
      final r = (6 + (i % 3) * 2.5) * (1 - t * .6);
      final paint = Paint()..color = _colors[i % _colors.length].withOpacity((1 - t).clamp(0.0, 1.0));
      final path = Path();
      for (var k = 0; k < 8; k++) {
        final rr = k.isEven ? r * 1.6 : r * .7;
        final aa = a + k * math.pi / 4;
        final pt = p + Offset(math.cos(aa), math.sin(aa)) * rr;
        if (k == 0) {
          path.moveTo(pt.dx, pt.dy);
        } else {
          path.lineTo(pt.dx, pt.dy);
        }
      }
      path.close();
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(_BurstPainter old) => old.t != t;
}

/// Tela de parabéns, com confete e as opções de jogar de novo ou voltar.
class WinOverlay extends StatelessWidget {
  const WinOverlay({super.key, required this.onReplay, required this.onExit, this.detail});

  final VoidCallback onReplay;
  final VoidCallback onExit;

  /// Linha extra opcional (ex.: "8 jogadas").
  final String? detail;

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: Stack(
        fit: StackFit.expand,
        children: [
          _WinCard(onReplay: onReplay, onExit: onExit, detail: detail),
          const IgnorePointer(child: _Confetti()),
        ],
      ),
    );
  }
}

/// Chuva de confete (uma passada, sem repetir).
class _Confetti extends StatefulWidget {
  const _Confetti();

  @override
  State<_Confetti> createState() => _ConfettiState();
}

class _ConfettiState extends State<_Confetti> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 3200));
  late final List<_Piece> _pieces;

  @override
  void initState() {
    super.initState();
    final rng = math.Random(7);
    const colors = [
      Color(0xFFFFC93C),
      Color(0xFFFF6B8B),
      Color(0xFF4CC38A),
      Color(0xFF5AA9FF),
      Color(0xFFB07CFF),
    ];
    _pieces = [
      for (var i = 0; i < 44; i++)
        _Piece(
          x: rng.nextDouble(),
          delay: rng.nextDouble() * .35,
          speed: .75 + rng.nextDouble() * .5,
          sway: 10 + rng.nextDouble() * 22,
          phase: rng.nextDouble() * math.pi * 2,
          spin: 2 + rng.nextDouble() * 5,
          size: 8 + rng.nextDouble() * 8,
          color: colors[i % colors.length],
        ),
    ];
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (MediaQuery.of(context).disableAnimations) {
      _c.value = 1;
    } else if (!_c.isAnimating && _c.value == 0) {
      _c.forward();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) => CustomPaint(painter: _ConfettiPainter(_pieces, _c.value)),
      ),
    );
  }
}

class _Piece {
  const _Piece({
    required this.x,
    required this.delay,
    required this.speed,
    required this.sway,
    required this.phase,
    required this.spin,
    required this.size,
    required this.color,
  });

  final double x;
  final double delay;
  final double speed;
  final double sway;
  final double phase;
  final double spin;
  final double size;
  final Color color;
}

class _ConfettiPainter extends CustomPainter {
  _ConfettiPainter(this.pieces, this.t);

  final List<_Piece> pieces;
  final double t;

  @override
  void paint(Canvas canvas, Size size) {
    for (final p in pieces) {
      final local = ((t - p.delay) / (1 - p.delay)).clamp(0.0, 1.0);
      if (local <= 0 || local >= 1) continue;
      final y = -20 + local * p.speed * (size.height + 40);
      final x = p.x * size.width + math.sin(local * math.pi * 4 + p.phase) * p.sway;
      canvas.save();
      canvas.translate(x, y);
      canvas.rotate(local * p.spin * math.pi);
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(center: Offset.zero, width: p.size, height: p.size * .55),
          const Radius.circular(2),
        ),
        Paint()..color = p.color,
      );
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(_ConfettiPainter old) => old.t != t;
}

class _WinCard extends StatelessWidget {
  const _WinCard({required this.onReplay, required this.onExit, this.detail});

  final VoidCallback onReplay;
  final VoidCallback onExit;
  final String? detail;

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: ColoredBox(
        color: Colors.black54,
        child: Center(
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0.6, end: 1),
            duration: const Duration(milliseconds: 500),
            curve: Curves.elasticOut,
            builder: (context, v, child) => Transform.scale(scale: v, child: child),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 28),
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(36),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(Icons.star_rounded, size: 52, color: AppColors.sun),
                      Icon(Icons.star_rounded, size: 72, color: AppColors.sun),
                      Icon(Icons.star_rounded, size: 52, color: AppColors.sun),
                    ],
                  ),
                  const Text('Parabéns!',
                      style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
                  const Text('Congratulations!',
                      style: TextStyle(
                          fontSize: 20, fontWeight: FontWeight.w700, color: AppColors.grape)),
                  if (detail != null) ...[
                    const SizedBox(height: 6),
                    Text(detail!, style: const TextStyle(fontSize: 18)),
                  ],
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: onReplay,
                      style: FilledButton.styleFrom(
                        backgroundColor: AppColors.grass,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        textStyle: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
                      ),
                      icon: const Icon(Icons.replay_rounded, size: 30),
                      label: const Text('Jogar de novo'),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: onExit,
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        textStyle: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                      ),
                      icon: const Icon(Icons.apps_rounded, size: 28),
                      label: const Text('Outras brincadeiras'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
