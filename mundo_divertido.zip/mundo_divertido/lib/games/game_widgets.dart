import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/learning_item.dart';
import '../theme/app_theme.dart';
import '../widgets/kid_top_bar.dart';
import '../widgets/scene_background.dart';

/// Moldura comum das brincadeiras: cenário, barra superior e tela de vitória.
class GameFrame extends StatelessWidget {
  const GameFrame({
    super.key,
    required this.category,
    required this.title,
    required this.child,
    this.winOverlay,
  });

  final Category category;
  final String title;
  final Widget child;

  /// Quando não nulo, aparece por cima de tudo (fim da brincadeira).
  final Widget? winOverlay;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SceneBackground(
        category: category,
        child: Stack(
          fit: StackFit.expand,
          children: [
            SafeArea(
              child: Column(
                children: [
                  KidTopBar(title: title, onBack: () => Navigator.of(context).pop()),
                  Expanded(child: child),
                ],
              ),
            ),
            if (winOverlay != null) winOverlay!,
          ],
        ),
      ),
    );
  }
}

/// Fileira de estrelas: as já conquistadas ficam cheias.
class ProgressStars extends StatelessWidget {
  const ProgressStars({super.key, required this.total, required this.done});

  final int total;
  final int done;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: '$done de $total',
      child: ExcludeSemantics(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            for (var i = 0; i < total; i++)
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 350),
                transitionBuilder: (c, a) => ScaleTransition(scale: a, child: c),
                child: Icon(
                  i < done ? Icons.star_rounded : Icons.star_outline_rounded,
                  key: ValueKey('$i-${i < done}'),
                  size: 36,
                  color: i < done ? AppColors.sun : Colors.black38,
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/// Botão redondo grande de alto-falante ("ouvir de novo").
class SpeakerButton extends StatelessWidget {
  const SpeakerButton({super.key, required this.onTap, required this.color, this.size = 96});

  final VoidCallback onTap;
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: 'Ouvir de novo',
      child: Material(
        color: color,
        elevation: 5,
        shape: const CircleBorder(side: BorderSide(color: Colors.white, width: 4)),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: SizedBox(
            width: size,
            height: size,
            child: Icon(Icons.volume_up_rounded, size: size * .56, color: Colors.white),
          ),
        ),
      ),
    );
  }
}

/// Balança de lado a lado cada vez que [shakes] aumenta (resposta errada).
class ShakeWidget extends StatefulWidget {
  const ShakeWidget({super.key, required this.shakes, required this.child});

  final int shakes;
  final Widget child;

  @override
  State<ShakeWidget> createState() => _ShakeWidgetState();
}

class _ShakeWidgetState extends State<ShakeWidget> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 420));

  @override
  void didUpdateWidget(ShakeWidget old) {
    super.didUpdateWidget(old);
    if (widget.shakes != old.shakes) _c.forward(from: 0);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      child: widget.child,
      builder: (context, child) {
        final t = _c.value;
        return Transform.translate(
          offset: Offset(math.sin(t * math.pi * 6) * 10 * (1 - t), 0),
          child: child,
        );
      },
    );
  }
}

/// Tela de parabéns, com as opções de jogar de novo ou voltar.
class WinOverlay extends StatelessWidget {
  const WinOverlay({super.key, required this.onReplay, required this.onExit, this.detail});

  final VoidCallback onReplay;
  final VoidCallback onExit;

  /// Linha extra opcional (ex.: "8 jogadas").
  final String? detail;

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: ColoredBox(
        color: Colors.black54,
        child: Center(
          child: TweenAnimationBuilder<double>(
            tween: Tween(begin: 0.6, end: 1),
            duration: const Duration(milliseconds: 500),
            curve: Curves.elasticOut,
            builder: (context, v, child) => Transform.scale(scale: v, child: child),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 28),
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(36),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(Icons.star_rounded, size: 52, color: AppColors.sun),
                      Icon(Icons.star_rounded, size: 72, color: AppColors.sun),
                      Icon(Icons.star_rounded, size: 52, color: AppColors.sun),
                    ],
                  ),
                  const Text('Parabéns!',
                      style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
                  const Text('Congratulations!',
                      style: TextStyle(
                          fontSize: 20, fontWeight: FontWeight.w700, color: AppColors.grape)),
                  if (detail != null) ...[
                    const SizedBox(height: 6),
                    Text(detail!, style: const TextStyle(fontSize: 18)),
                  ],
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: onReplay,
                      style: FilledButton.styleFrom(
                        backgroundColor: AppColors.grass,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        textStyle: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
                      ),
                      icon: const Icon(Icons.replay_rounded, size: 30),
                      label: const Text('Jogar de novo'),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: onExit,
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        textStyle: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                      ),
                      icon: const Icon(Icons.apps_rounded, size: 28),
                      label: const Text('Outras brincadeiras'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
