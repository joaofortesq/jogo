import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../theme/app_theme.dart';
import '../widgets/kid_top_bar.dart';
import '../widgets/pop_in.dart';
import '../data/content_repository.dart';
import '../screens/paint_screen.dart';
import '../widgets/bouncy.dart';
import 'body_game_screen.dart';
import 'choice_game_screen.dart';
import 'glyph_game_screen.dart';
import 'memory_game_screen.dart';
import '../widgets/app_route.dart';

/// Menu das brincadeiras.
class GamesHubScreen extends StatelessWidget {
  const GamesHubScreen({super.key});

  void _open(BuildContext context, Widget screen) {
    Navigator.of(context).push(AppRoute<void>(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    final games = <_GameInfo>[
      _GameInfo(
        titlePt: 'Cadê?',
        titleEn: 'Find it!',
        icon: Icons.search_rounded,
        color: AppColors.grass,
        builder: () => const ChoiceGameScreen(kind: ChoiceKind.listen),
      ),
      _GameInfo(
        titlePt: 'Memória',
        titleEn: 'Memory',
        icon: Icons.extension_rounded,
        color: const Color(0xFFE8912D),
        builder: () => const MemoryGameScreen(),
      ),
      _GameInfo(
        titlePt: 'Qual é a cor?',
        titleEn: 'Which color?',
        icon: Icons.palette_rounded,
        color: AppColors.grape,
        builder: () => const ChoiceGameScreen(kind: ChoiceKind.color),
      ),
      _GameInfo(
        titlePt: 'Pintar',
        titleEn: 'Paint',
        icon: Icons.brush_rounded,
        color: const Color(0xFFEC5FA4),
        builder: () => PaintScreen(
            colors: context.read<ContentRepository>().byId('colors').items),
      ),
      _GameInfo(
        titlePt: 'Onde está?',
        titleEn: 'Where is it?',
        icon: Icons.accessibility_new_rounded,
        color: const Color(0xFFFF7A59),
        builder: () => BodyGameScreen(
            category: context.read<ContentRepository>().byId('body')),
      ),
      _GameInfo(
        titlePt: 'Quem faz esse som?',
        titleEn: 'Who makes this sound?',
        icon: Icons.hearing_rounded,
        color: AppColors.berry,
        builder: () => const ChoiceGameScreen(kind: ChoiceKind.sound),
      ),
      _GameInfo(
        titlePt: 'Descubra a letra',
        titleEn: 'Find the letter',
        icon: Icons.sort_by_alpha_rounded,
        color: const Color(0xFFFF8A3D),
        builder: () => const GlyphGameScreen(kind: GlyphGameKind.letters),
      ),
      _GameInfo(
        titlePt: 'Descubra o número',
        titleEn: 'Find the number',
        icon: Icons.looks_one_rounded,
        color: const Color(0xFF2FA8A0),
        builder: () => const GlyphGameScreen(kind: GlyphGameKind.numbers),
      ),
    ];
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppColors.mintTop, AppColors.mintBottom],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              KidTopBar(
                  title: 'Brincadeiras',
                  onBack: () => Navigator.of(context).pop()),
              Expanded(
                child: LayoutBuilder(builder: (context, c) {
                  const gap = 16.0;
                  const pad = 16.0;
                  final w = (c.maxWidth - pad * 2 - gap) / 2;
                  final rows = (games.length / 2).ceil();
                  final h = (c.maxHeight - pad * 2 - gap * (rows - 1)) / rows;
                  return GridView.count(
                    physics: const NeverScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(pad),
                    crossAxisCount: 2,
                    mainAxisSpacing: gap,
                    crossAxisSpacing: gap,
                    childAspectRatio: w / h,
                    children: [
                      for (var i = 0; i < games.length; i++)
                        PopIn(
                          index: i,
                          child: _GameCard(
                              info: games[i],
                              onTap: () => _open(context, games[i].builder())),
                        ),
                    ],
                  );
                }),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _GameInfo {
  const _GameInfo({
    required this.titlePt,
    required this.titleEn,
    required this.icon,
    required this.color,
    required this.builder,
  });

  final String titlePt;
  final String titleEn;
  final IconData icon;
  final Color color;
  final Widget Function() builder;
}

class _GameCard extends StatelessWidget {
  const _GameCard({required this.info, required this.onTap});

  final _GameInfo info;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: info.titlePt,
      child: Bouncy(
        child: Material(
          color: info.color,
          elevation: 5,
          shadowColor: info.color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(32),
            side: const BorderSide(color: Colors.white, width: 3),
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(32),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  Expanded(
                    child: Floaty(
                      phase: info.titlePt.length * .13 % 1.0,
                      child: FittedBox(
                        child: Padding(
                          padding: const EdgeInsets.all(8),
                          child: Icon(info.icon,
                              color: Colors.white,
                              shadows: const [
                                Shadow(
                                    color: Color(0x33000000),
                                    blurRadius: 4,
                                    offset: Offset(0, 2)),
                              ]),
                        ),
                      ),
                    ),
                  ),
                  FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(info.titlePt,
                        style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w900,
                            color: Colors.white)),
                  ),
                  FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(info.titleEn,
                        style: const TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w700,
                            color: Colors.white70)),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
