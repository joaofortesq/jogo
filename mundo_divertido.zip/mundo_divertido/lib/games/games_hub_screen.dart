import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../widgets/kid_top_bar.dart';
import '../widgets/pop_in.dart';
import 'choice_game_screen.dart';
import 'memory_game_screen.dart';

/// Menu das quatro brincadeiras.
class GamesHubScreen extends StatelessWidget {
  const GamesHubScreen({super.key});

  void _open(BuildContext context, Widget screen) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    final games = <_GameInfo>[
      _GameInfo(
        titlePt: 'Cadê?',
        titleEn: 'Find it!',
        icon: Icons.search_rounded,
        color: AppColors.grass,
        builder: () => const ChoiceGameScreen(kind: ChoiceKind.listen),
      ),
      _GameInfo(
        titlePt: 'Memória',
        titleEn: 'Memory',
        icon: Icons.extension_rounded,
        color: const Color(0xFFE8912D),
        builder: () => const MemoryGameScreen(),
      ),
      _GameInfo(
        titlePt: 'Qual é a cor?',
        titleEn: 'Which color?',
        icon: Icons.palette_rounded,
        color: AppColors.grape,
        builder: () => const ChoiceGameScreen(kind: ChoiceKind.color),
      ),
      _GameInfo(
        titlePt: 'Quem faz esse som?',
        titleEn: 'Who makes this sound?',
        icon: Icons.hearing_rounded,
        color: AppColors.berry,
        builder: () => const ChoiceGameScreen(kind: ChoiceKind.sound),
      ),
    ];
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppColors.mintTop, AppColors.mintBottom],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              KidTopBar(title: 'Brincadeiras', onBack: () => Navigator.of(context).pop()),
              Expanded(
                child: LayoutBuilder(builder: (context, c) {
                  const gap = 16.0;
                  const pad = 16.0;
                  final w = (c.maxWidth - pad * 2 - gap) / 2;
                  final h = (c.maxHeight - pad * 2 - gap) / 2;
                  return GridView.count(
                    physics: const NeverScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(pad),
                    crossAxisCount: 2,
                    mainAxisSpacing: gap,
                    crossAxisSpacing: gap,
                    childAspectRatio: w / h,
                    children: [
                      for (var i = 0; i < games.length; i++)
                        PopIn(
                          index: i,
                          child: _GameCard(
                              info: games[i],
                              onTap: () => _open(context, games[i].builder())),
                        ),
                    ],
                  );
                }),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _GameInfo {
  const _GameInfo({
    required this.titlePt,
    required this.titleEn,
    required this.icon,
    required this.color,
    required this.builder,
  });

  final String titlePt;
  final String titleEn;
  final IconData icon;
  final Color color;
  final Widget Function() builder;
}

class _GameCard extends StatelessWidget {
  const _GameCard({required this.info, required this.onTap});

  final _GameInfo info;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: info.titlePt,
      child: Material(
        color: info.color,
        elevation: 4,
        borderRadius: BorderRadius.circular(32),
        child: InkWell(
          borderRadius: BorderRadius.circular(32),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                Expanded(
                  child: FittedBox(
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: Icon(info.icon, color: Colors.white),
                    ),
                  ),
                ),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(info.titlePt,
                      style: const TextStyle(
                          fontSize: 24, fontWeight: FontWeight.w900, color: Colors.white)),
                ),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(info.titleEn,
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.w700, color: Colors.white70)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
