import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/learning_item.dart';
import '../services/audio_service.dart';
import '../theme/app_theme.dart';
import '../widgets/audio_controls.dart';
import '../widgets/body_figure.dart';
import 'game_widgets.dart';

/// Brincadeira "Onde está?": a voz pergunta "Onde está o nariz? Where is the
/// nose?" e a criança toca na parte certa do corpo. Seis rodadas; errar nunca
/// pune, e depois de dois erros a parte certa brilha de leve (dica).
class BodyGameScreen extends StatefulWidget {
  const BodyGameScreen({super.key, required this.category, this.random});

  final Category category;
  final Random? random;

  @override
  State<BodyGameScreen> createState() => _BodyGameScreenState();
}

class _BodyGameScreenState extends State<BodyGameScreen> {
  static const rounds = 6;

  late final AudioService _audio = context.read<AudioService>();
  late final Random _rng = widget.random ?? Random();
  late List<LearningItem> _targets;
  int _index = 0;
  int _misses = 0;
  bool _answered = false;
  bool _won = false;
  int _session = 0;
  int _bursts = 0;

  /// Parte tocada por último (acende certo ou errado).
  String? _touched;

  LearningItem get _target => _targets[_index];

  @override
  void initState() {
    super.initState();
    _deal();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _ask();
    });
  }

  @override
  void dispose() {
    _session++;
    unawaited(_audio.stop());
    super.dispose();
  }

  void _deal() {
    _targets =
        ([...widget.category.items]..shuffle(_rng)).take(rounds).toList();
    _index = 0;
    _misses = 0;
    _answered = false;
    _won = false;
    _touched = null;
    _session++;
  }

  void _ask() => runAudio(context, _audio.playAsk(_target));

  Future<void> _tap(String part) async {
    if (_answered || _won) return;
    if (part != _target.id) {
      setState(() {
        _touched = part;
        _misses++;
      });
      if (_misses >= 2) {
        _ask();
      } else {
        unawaited(_audio.playTryAgain());
      }
      return;
    }
    final session = _session;
    setState(() {
      _answered = true;
      _touched = part;
      _bursts++;
    });
    await runAudio(context, _audio.playCorrect(_target));
    if (!mounted || session != _session) return;
    await Future<void>.delayed(const Duration(milliseconds: 500));
    if (!mounted || session != _session) return;
    if (_index == _targets.length - 1) {
      setState(() => _won = true);
      unawaited(_audio.praise());
      return;
    }
    setState(() {
      _index++;
      _misses = 0;
      _answered = false;
      _touched = null;
    });
    _ask();
  }

  @override
  Widget build(BuildContext context) {
    final t = _target;
    return GameFrame(
      category: widget.category,
      title: 'Onde está?',
      winOverlay: _won
          ? WinOverlay(
              onReplay: () {
                setState(_deal);
                _ask();
              },
              onExit: () => Navigator.of(context).pop(),
            )
          : null,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 2),
            child: ProgressStars(
                total: _targets.length, done: _index + (_answered ? 1 : 0)),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 6, 16, 0),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    children: [
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text(t.askPt ?? t.pt,
                            style: const TextStyle(
                                fontSize: 26,
                                fontWeight: FontWeight.w900,
                                color: AppColors.ink)),
                      ),
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text(t.askEn ?? t.en,
                            style: const TextStyle(
                                fontSize: 19,
                                fontWeight: FontWeight.w800,
                                color: AppColors.grape)),
                      ),
                    ],
                  ),
                ),
                SpeakerButton(
                    onTap: _ask, color: widget.category.accent, size: 64),
              ],
            ),
          ),
          Expanded(
            child: Stack(
              children: [
                Positioned.fill(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(28, 8, 28, 16),
                    child: BodyFigure(
                      highlight: _answered ? t.id : null,
                      hint: !_answered && _misses >= 2 ? t.id : null,
                      onPart: _tap,
                    ),
                  ),
                ),
                if (_bursts > 0 && _answered)
                  Positioned.fill(child: StarBurst(key: ValueKey(_bursts))),
                if (_touched != null && !_answered)
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 8,
                    child: Center(
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: .92),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          _labelOf(_touched!),
                          style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              color: AppColors.ink),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// "Isso é: Mão · Hand" quando a criança toca em outra parte (ajuda a aprender).
  String _labelOf(String id) {
    final i = widget.category.items
        .firstWhere((e) => e.id == id, orElse: () => _target);
    return 'Isso é: ${i.pt} · ${i.en}';
  }
}
