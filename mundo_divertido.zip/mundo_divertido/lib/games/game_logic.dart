import 'dart:math';

import '../models/learning_item.dart';

/// Uma rodada de escolha: ouvir/ver [target] e tocar na opção certa.
class ChoiceRound {
  const ChoiceRound({required this.target, required this.options});

  final LearningItem target;

  /// Inclui [target], em ordem embaralhada.
  final List<LearningItem> options;
}

/// Sorteia [rounds] rodadas com alvos diferentes (se o grupo for grande o
/// bastante) e [optionCount] opções distintas por rodada.
List<ChoiceRound> buildChoiceRounds(
  List<LearningItem> pool, {
  int rounds = 6,
  int optionCount = 3,
  Random? random,
}) {
  assert(pool.length >= optionCount, 'o grupo precisa ter opções suficientes');
  final rng = random ?? Random();
  final targets = [...pool]..shuffle(rng);
  final out = <ChoiceRound>[];
  for (var r = 0; r < rounds; r++) {
    final target = targets[r % targets.length];
    final others = pool.where((i) => i.id != target.id).toList()..shuffle(rng);
    final options = [target, ...others.take(optionCount - 1)]..shuffle(rng);
    out.add(ChoiceRound(target: target, options: options));
  }
  return out;
}

/// Carta do jogo da memória.
class MemoryCard {
  MemoryCard(this.item);

  final LearningItem item;
  bool faceUp = false;
  bool matched = false;
}

enum FlipResult { ignored, first, match, mismatch }

/// Regras do jogo da memória, sem nada de interface (fácil de testar).
class MemoryGame {
  MemoryGame(List<LearningItem> pool, {required int pairs, Random? random})
      : cards = _deal(pool, pairs, random ?? Random());

  final List<MemoryCard> cards;
  int moves = 0;

  int? _first;
  (int, int)? _pending;

  static List<MemoryCard> _deal(List<LearningItem> pool, int pairs, Random rng) {
    assert(pool.length >= pairs);
    final chosen = ([...pool]..shuffle(rng)).take(pairs);
    final cards = [
      for (final i in chosen) ...[MemoryCard(i), MemoryCard(i)],
    ]..shuffle(rng);
    return cards;
  }

  /// Há duas cartas erradas viradas esperando para desvirar.
  bool get locked => _pending != null;
  bool get won => cards.every((c) => c.matched);

  FlipResult flip(int index) {
    if (locked) return FlipResult.ignored;
    final card = cards[index];
    if (card.matched || card.faceUp) return FlipResult.ignored;
    card.faceUp = true;
    final first = _first;
    if (first == null) {
      _first = index;
      return FlipResult.first;
    }
    _first = null;
    moves++;
    if (cards[first].item.id == card.item.id) {
      cards[first].matched = true;
      card.matched = true;
      return FlipResult.match;
    }
    _pending = (first, index);
    return FlipResult.mismatch;
  }

  /// Desvira o par errado depois do tempo de espera.
  void resolveMismatch() {
    final p = _pending;
    if (p == null) return;
    cards[p.$1].faceUp = false;
    cards[p.$2].faceUp = false;
    _pending = null;
  }
}
