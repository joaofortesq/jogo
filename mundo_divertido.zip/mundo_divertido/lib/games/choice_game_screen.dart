import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/content_repository.dart';
import '../models/learning_item.dart';
import '../services/audio_service.dart';
import '../theme/app_theme.dart';
import '../widgets/animated_character.dart';
import '../widgets/audio_controls.dart';
import '../widgets/item_art.dart';
import 'game_logic.dart';
import 'game_widgets.dart';

/// As três brincadeiras de "ouvir/ver e tocar na opção certa".
enum ChoiceKind {
  /// Ouve o nome (português e inglês) e toca na figura certa.
  listen,

  /// Ouve o nome de uma cor e toca na bolinha certa.
  color,

  /// Vê uma sombra e descobre quem é.
  shadow,

  /// Ouve o som de um animal e toca em quem faz esse som.
  sound,
}

class ChoiceGameScreen extends StatefulWidget {
  const ChoiceGameScreen({super.key, required this.kind, this.random});

  final ChoiceKind kind;

  /// Permite testes previsíveis.
  final Random? random;

  @override
  State<ChoiceGameScreen> createState() => _ChoiceGameScreenState();
}

class _ChoiceGameScreenState extends State<ChoiceGameScreen> {
  static const _roundsPerGame = 6;

  late final AudioService _audio;
  late final ContentRepository _repo;
  late final Random _rng = widget.random ?? Random();

  late Category _category;
  late List<ChoiceRound> _rounds;
  int _index = 0;
  bool _ready = true;

  /// Animais cujo som gravado existe (jogo "Quem faz esse som?").
  List<LearningItem> _playable = const [];
  bool _answered = false;
  bool _won = false;
  int _session = 0;
  final Set<String> _wrong = {};
  final Map<String, int> _shakes = {};

  String get _title => switch (widget.kind) {
        ChoiceKind.listen => 'Cadê?',
        ChoiceKind.color => 'Qual é a cor?',
        ChoiceKind.shadow => 'Quem sou eu?',
        ChoiceKind.sound => 'Quem faz esse som?',
      };

  @override
  void initState() {
    super.initState();
    _audio = context.read<AudioService>();
    _repo = context.read<ContentRepository>();
    _deal();
    if (widget.kind == ChoiceKind.sound) {
      _ready = false;
      unawaited(_prepareSound());
    } else {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _startRound();
      });
    }
  }

  List<LearningItem> _animals() => [
        for (final c in _repo.categories)
          if (c.kind == CategoryKind.animals)
            for (final i in c.items)
              if (i.hasAnimalSound) i,
      ];

  /// Descobre quais animais têm som gravado e só então começa o jogo.
  Future<void> _prepareSound() async {
    final animals = _animals();
    final flags = await Future.wait([for (final a in animals) _audio.hasSoundFile(a)]);
    if (!mounted) return;
    _playable = [
      for (var i = 0; i < animals.length; i++)
        if (flags[i]) animals[i],
    ];
    setState(() {
      _deal();
      _ready = true;
    });
    _startRound();
  }

  @override
  void dispose() {
    _session++;
    unawaited(_audio.stop());
    super.dispose();
  }

  void _deal() {
    if (widget.kind == ChoiceKind.sound) {
      final cats = _repo.categories.where((c) => c.kind == CategoryKind.animals).toList();
      _category = cats[_rng.nextInt(cats.length)];
      _rounds = buildChoiceRounds(_animals(),
          rounds: _roundsPerGame, random: _rng, targetPool: _playable);
      _index = 0;
      _answered = false;
      _won = false;
      _wrong.clear();
      _shakes.clear();
      _session++;
      return;
    }
    if (widget.kind == ChoiceKind.color) {
      _category = _repo.byId('colors');
    } else {
      final cats =
          _repo.categories.where((c) => c.kind != CategoryKind.colors).toList();
      _category = cats[_rng.nextInt(cats.length)];
    }
    _rounds = buildChoiceRounds(_category.items, rounds: _roundsPerGame, random: _rng);
    _index = 0;
    _answered = false;
    _won = false;
    _wrong.clear();
    _shakes.clear();
    _session++;
  }

  void _restart() {
    setState(_deal);
    _startRound();
  }

  void _replay() => _startRound(prompt: false);

  /// Fala a pergunta da rodada atual (também usado pelo botão de alto-falante).
  void _startRound({bool prompt = true}) {
    final target = _rounds[_index].target;
    final future = switch (widget.kind) {
      ChoiceKind.shadow => _audio.playSequence(const [
          AudioClip(tag: 'prompt:pt', text: 'Quem sou eu?', lang: 'pt-BR'),
          AudioClip(tag: 'prompt:en', text: 'Who am I?', lang: 'en-US'),
        ]),
      ChoiceKind.sound =>
        prompt && _index == 0 ? _audio.playGuessSound(target) : _audio.playSound(target),
      _ => _audio.playWords(target),
    };
    unawaited(runAudio(context, future));
  }

  Future<void> _choose(LearningItem item) async {
    if (_answered || _won) return;
    final round = _rounds[_index];
    if (item.id != round.target.id) {
      setState(() {
        _wrong.add(item.id);
        _shakes[item.id] = (_shakes[item.id] ?? 0) + 1;
      });
      return;
    }
    final session = _session;
    setState(() => _answered = true);
    await runAudio(context, _audio.playWords(round.target));
    if (!mounted || session != _session) return;
    await Future<void>.delayed(const Duration(milliseconds: 700));
    if (!mounted || session != _session) return;
    if (_index == _rounds.length - 1) {
      setState(() => _won = true);
      unawaited(_audio.praise());
      return;
    }
    setState(() {
      _index++;
      _answered = false;
      _wrong.clear();
      _shakes.clear();
    });
    _startRound();
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) {
      return GameFrame(
        category: _category,
        title: _title,
        child: const Center(child: CircularProgressIndicator()),
      );
    }
    final round = _rounds[_index];
    return GameFrame(
      category: _category,
      title: _title,
      winOverlay: _won
          ? WinOverlay(onReplay: _restart, onExit: () => Navigator.of(context).pop())
          : null,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: ProgressStars(total: _rounds.length, done: _index + (_answered ? 1 : 0)),
          ),
          Expanded(flex: 4, child: _buildPrompt(round)),
          Expanded(flex: 5, child: _buildOptions(round)),
        ],
      ),
    );
  }

  Widget _buildPrompt(ChoiceRound round) {
    final target = round.target;
    final nameTag = AnimatedOpacity(
      duration: const Duration(milliseconds: 250),
      opacity: _answered ? 1 : 0,
      child: _NameTag(item: target),
    );
    if (widget.kind == ChoiceKind.sound) {
      return LayoutBuilder(builder: (context, c) {
        final size = max(80.0, min(c.maxWidth * .6, c.maxHeight - 90));
        return Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 350),
              child: _answered
                  ? AnimatedCharacter(
                      key: ValueKey('win-${target.id}-$_index'),
                      item: target,
                      reaction: _category.reaction,
                      size: size,
                      playingTag: _audio.playingTag,
                    )
                  : SpeakerButton(
                      key: const ValueKey('speaker'),
                      size: 112,
                      color: _category.textAccent,
                      onTap: _replay,
                    ),
            ),
            const SizedBox(height: 6),
            nameTag,
          ],
        );
      });
    }
    if (widget.kind == ChoiceKind.shadow) {
      return LayoutBuilder(builder: (context, c) {
        final size = max(80.0, min(c.maxWidth * .6, c.maxHeight - 100));
        return Stack(
          alignment: Alignment.center,
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 350),
                  child: SizedBox(
                    key: ValueKey('${target.id}-$_answered'),
                    width: size,
                    height: size,
                    child: _answered
                        ? AnimatedCharacter(
                            item: target, reaction: _category.reaction, size: size)
                        : ColorFiltered(
                            colorFilter: const ColorFilter.mode(
                                Color(0xFF3B3560), BlendMode.srcIn),
                            child: ItemArt(item: target, size: size),
                          ),
                  ),
                ),
                const SizedBox(height: 6),
                nameTag,
              ],
            ),
            Positioned(
              right: 16,
              top: 0,
              child: SpeakerButton(
                  size: 64, color: _category.textAccent, onTap: _startRound),
            ),
          ],
        );
      });
    }
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SpeakerButton(size: 112, color: _category.textAccent, onTap: _startRound),
        const SizedBox(height: 14),
        nameTag,
      ],
    );
  }

  Widget _buildOptions(ChoiceRound round) {
    return LayoutBuilder(builder: (context, c) {
      const gap = 14.0;
      final side = max(
          72.0, min((c.maxWidth - 32 - gap) / 2, (c.maxHeight - gap - 8) / 2));
      return Center(
        child: Wrap(
          alignment: WrapAlignment.center,
          spacing: gap,
          runSpacing: gap,
          children: [
            for (final option in round.options)
              SizedBox(
                width: side,
                height: side,
                child: _OptionTile(
                  key: ValueKey('option-${option.id}'),
                  kind: widget.kind,
                  item: option,
                  accent: _category.textAccent,
                  isCorrect: _answered && option.id == round.target.id,
                  dimmed: _answered
                      ? option.id != round.target.id
                      : _wrong.contains(option.id),
                  shakes: _shakes[option.id] ?? 0,
                  onTap: () => _choose(option),
                ),
              ),
          ],
        ),
      );
    });
  }
}

/// Plaquinha clara com o nome nos dois idiomas (legível sobre o cenário).
class _NameTag extends StatelessWidget {
  const _NameTag({required this.item});

  final LearningItem item;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.92),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(item.pt.toUpperCase(),
              style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          Text(item.en.toUpperCase(),
              style: const TextStyle(
                  fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.grape)),
        ],
      ),
    );
  }
}

class _OptionTile extends StatelessWidget {
  const _OptionTile({
    super.key,
    required this.kind,
    required this.item,
    required this.accent,
    required this.isCorrect,
    required this.dimmed,
    required this.shakes,
    required this.onTap,
  });

  final ChoiceKind kind;
  final LearningItem item;
  final Color accent;
  final bool isCorrect;
  final bool dimmed;
  final int shakes;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ShakeWidget(
      shakes: shakes,
      child: AnimatedScale(
        scale: isCorrect ? 1.08 : 1,
        duration: const Duration(milliseconds: 320),
        curve: Curves.easeOutBack,
        child: AnimatedOpacity(
          duration: const Duration(milliseconds: 250),
          opacity: dimmed ? .4 : 1,
          child: Semantics(
            button: true,
            label: kind == ChoiceKind.shadow ? 'Opção' : item.pt,
            child: Material(
              color: Colors.white,
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(28),
                side: BorderSide(
                  color: isCorrect ? AppColors.grass : accent,
                  width: isCorrect ? 6 : 3,
                ),
              ),
              child: InkWell(
                customBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
                onTap: onTap,
                child: Stack(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: LayoutBuilder(builder: (context, c) {
                        final s = c.biggest.shortestSide;
                        if (kind == ChoiceKind.color) {
                          return Center(
                            child: Container(
                              width: s * .86,
                              height: s * .86,
                              decoration: BoxDecoration(
                                color: item.color,
                                shape: BoxShape.circle,
                                border: Border.all(color: Colors.black26, width: 3),
                              ),
                            ),
                          );
                        }
                        return Center(child: ItemArt(item: item, size: s));
                      }),
                    ),
                    if (isCorrect)
                      const Positioned(
                        right: 6,
                        top: 6,
                        child: Icon(Icons.check_circle_rounded,
                            size: 36, color: AppColors.grass),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
