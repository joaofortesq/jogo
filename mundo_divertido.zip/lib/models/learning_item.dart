import 'package:flutter/material.dart';

enum CategoryKind { animals, fruits, colors, letters, numbers }

enum ReactionStyle { wobble, jump, spin }

Color colorFromHex(String hex) {
  final h = hex.replaceAll('#', '');
  return Color(int.parse(h.length == 6 ? 'FF$h' : h, radix: 16));
}

/// Objeto de exemplo de uma cor (ex.: "Coração / Heart" para vermelho).
class ColorExample {
  const ColorExample({
    required this.id,
    required this.pt,
    required this.en,
    required this.icon,
  });

  final String id;
  final String pt;
  final String en;
  final String icon;

  factory ColorExample.fromJson(Map<String, dynamic> json) => ColorExample(
        id: json['id'] as String,
        pt: json['pt'] as String,
        en: json['en'] as String,
        icon: json['icon'] as String,
      );
}

/// Ilustração SVG (sem olhos) e posição dos olhos em um quadro de 200x200.
class ArtSpec {
  const ArtSpec({required this.asset, required this.eyes, required this.eyeRadius});

  final String asset;
  final List<Offset> eyes;
  final double eyeRadius;

  factory ArtSpec.fromJson(Map<String, dynamic> json) => ArtSpec(
        asset: json['asset'] as String,
        eyes: [
          for (final e in json['eyes'] as List<dynamic>)
            Offset((e[0] as num).toDouble(), (e[1] as num).toDouble()),
        ],
        eyeRadius: (json['eyeRadius'] as num).toDouble(),
      );
}

/// Uma camada do bicho de corpo inteiro: SVG 200x200 e o ponto em que ela gira.
class RigLayer {
  const RigLayer({required this.role, required this.asset, required this.pivot});

  /// tail, legL, legR, body, armL, armR ou head.
  final String role;
  final String asset;
  final Offset pivot;

  factory RigLayer.fromJson(Map<String, dynamic> json) => RigLayer(
        role: json['role'] as String,
        asset: json['asset'] as String,
        pivot: Offset((json['pivot'][0] as num).toDouble(), (json['pivot'][1] as num).toDouble()),
      );
}

/// Posição e largura da boca (para abrir enquanto o bicho fala; opcional).
class RigMouth {
  const RigMouth({required this.x, required this.y, required this.width});

  final double x;
  final double y;
  final double width;

  factory RigMouth.fromJson(Map<String, dynamic> json) => RigMouth(
        x: (json['x'] as num).toDouble(),
        y: (json['y'] as num).toDouble(),
        width: (json['w'] as num).toDouble(),
      );
}

/// Bicho de corpo inteiro em pé, em camadas (cauda, pernas, corpo, braços e cabeça).
class RigSpec {
  const RigSpec({
    required this.layers,
    required this.eyes,
    required this.eyeRadius,
    this.flap = false,
    this.mouth,
  });

  final List<RigLayer> layers;
  final List<Offset> eyes;
  final double eyeRadius;
  final RigMouth? mouth;

  /// Braços são asas: batem em vez de balançar.
  final bool flap;

  factory RigSpec.fromJson(Map<String, dynamic> json) => RigSpec(
        layers: [
          for (final l in json['layers'] as List<dynamic>)
            RigLayer.fromJson(l as Map<String, dynamic>),
        ],
        eyes: [
          for (final e in json['eyes'] as List<dynamic>)
            Offset((e[0] as num).toDouble(), (e[1] as num).toDouble()),
        ],
        eyeRadius: (json['eyeRadius'] as num).toDouble(),
        flap: json['armMode'] == 'flap',
        mouth: json['mouth'] == null
            ? null
            : RigMouth.fromJson(json['mouth'] as Map<String, dynamic>),
      );
}

/// Onomatopeia falada do animal (ex.: "Muuuu!"), com tom e velocidade da voz.
class SoundSpec {
  const SoundSpec({required this.text, this.pitch = 1.0, this.rate = 0.5});

  final String text;
  final double pitch;
  final double rate;

  factory SoundSpec.fromJson(Map<String, dynamic> json) => SoundSpec(
        text: json['text'] as String,
        pitch: (json['pitch'] as num? ?? 1.0).toDouble(),
        rate: (json['rate'] as num? ?? 0.5).toDouble(),
      );
}

/// Um elemento educativo: animal, fruta ou cor.
class LearningItem {
  const LearningItem({
    required this.id,
    required this.pt,
    required this.en,
    required this.color,
    this.hasAnimalSound = false,
    this.examples = const [],
    this.art,
    this.rig,
    this.sound,
    this.speakPt,
    this.speakEn,
    this.glyph,
    this.value,
    this.emoji,
  });

  final String id;
  final String pt;
  final String en;
  final Color color;
  final ArtSpec? art;

  /// Corpo inteiro em camadas (só animais).
  final RigSpec? rig;

  /// Onomatopeia falada; usada quando não há arquivo em animal_sounds/.
  final SoundSpec? sound;
  final bool hasAnimalSound;

  /// Em letras, [examples] são palavras que começam com a letra e o campo
  /// `icon` de cada exemplo traz um emoji (nas cores, traz o nome de um ícone).
  final List<ColorExample> examples;

  /// Como a voz deve falar (ex.: a letra "B" é falada "Bê"). Se nulo, usa pt/en.
  final String? speakPt;
  final String? speakEn;

  /// Símbolo grande mostrado no personagem (ex.: "Aa" ou "7"). Letras e números.
  final String? glyph;

  /// Valor do número (0 a 10). Só números.
  final int? value;

  /// Objeto que aparece várias vezes para contar (ex.: 🍎). Só números.
  final String? emoji;

  String get spokenPt => speakPt ?? pt;
  String get spokenEn => speakEn ?? en;

  // Os caminhos de áudio seguem uma convenção baseada no id.
  String get ptAudioPath => 'assets/audio/pt_br/$id.mp3';
  String get enAudioPath => 'assets/audio/en_us/$id.mp3';
  String get soundAudioPath => 'assets/audio/animal_sounds/$id.mp3';

  factory LearningItem.fromJson(Map<String, dynamic> json) => LearningItem(
        id: json['id'] as String,
        pt: json['pt'] as String,
        en: json['en'] as String,
        color: colorFromHex(json['color'] as String),
        hasAnimalSound: json['hasAnimalSound'] as bool? ?? false,
        speakPt: json['speakPt'] as String?,
        speakEn: json['speakEn'] as String?,
        glyph: json['glyph'] as String?,
        value: (json['value'] as num?)?.toInt(),
        emoji: json['emoji'] as String?,
        sound: json['sound'] == null
            ? null
            : SoundSpec.fromJson(json['sound'] as Map<String, dynamic>),
        art: json['art'] == null
            ? null
            : ArtSpec.fromJson(json['art'] as Map<String, dynamic>),
        rig: json['rig'] == null
            ? null
            : RigSpec.fromJson(json['rig'] as Map<String, dynamic>),
        examples: [
          for (final e in (json['examples'] as List<dynamic>? ?? const []))
            ColorExample.fromJson(e as Map<String, dynamic>),
        ],
      );
}

class Category {
  const Category({
    required this.id,
    required this.titlePt,
    required this.titleEn,
    required this.kind,
    required this.reaction,
    required this.accent,
    required this.background,
    required this.items,
    this.scene,
  });

  /// Cenário SVG de fundo (null para cores).
  final String? scene;

  final String id;
  final String titlePt;
  final String titleEn;
  final CategoryKind kind;
  final ReactionStyle reaction;
  final Color accent;
  final Color background;
  final List<LearningItem> items;

  /// Versão escura do destaque, para textos legíveis sobre fundo claro.
  Color get textAccent {
    final hsl = HSLColor.fromColor(accent);
    return hsl.withLightness((hsl.lightness * 0.68).clamp(0.0, 1.0)).toColor();
  }

  factory Category.fromJson(Map<String, dynamic> json) => Category(
        id: json['id'] as String,
        titlePt: json['titlePt'] as String,
        titleEn: json['titleEn'] as String,
        kind: CategoryKind.values.byName(json['kind'] as String),
        reaction: ReactionStyle.values.byName(json['reaction'] as String),
        accent: colorFromHex(json['accent'] as String),
        background: colorFromHex(json['background'] as String),
        scene: json['scene'] as String?,
        items: [
          for (final i in json['items'] as List<dynamic>)
            LearningItem.fromJson(i as Map<String, dynamic>),
        ],
      );
}
