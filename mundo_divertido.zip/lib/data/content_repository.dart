import 'dart:convert';

import 'package:flutter/services.dart';

import '../models/learning_item.dart';

/// Carrega as categorias a partir de assets/data/*.json.
/// Para adicionar uma categoria, crie um JSON e inclua o nome em [files].
class ContentRepository {
  ContentRepository(this.categories);

  final List<Category> categories;

  static const files = ['farm', 'safari', 'fruits', 'colors', 'letters', 'numbers'];

  static Future<ContentRepository> load([AssetBundle? bundle]) async {
    final b = bundle ?? rootBundle;
    final cats = <Category>[];
    for (final f in files) {
      final raw = await b.loadString('assets/data/$f.json');
      cats.add(Category.fromJson(jsonDecode(raw) as Map<String, dynamic>));
    }
    return ContentRepository(cats);
  }

  Category byId(String id) => categories.firstWhere((c) => c.id == id);
}
