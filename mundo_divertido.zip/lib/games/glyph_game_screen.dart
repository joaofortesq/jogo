import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../data/content_repository.dart';
import '../models/learning_item.dart';
import '../services/audio_service.dart';
import '../theme/app_theme.dart';
import '../widgets/audio_controls.dart';
import '../widgets/glyph_character.dart';
import 'game_logic.dart';
import 'game_widgets.dart';

/// Os dois jogos novos: "Descubra a letra" e "Descubra o número".
enum GlyphGameKind { letters, numbers }

/// Seis rodadas, de duas em duas alternando o jeito de perguntar:
///  - Letras: (1) ouvir o nome da letra e tocar nela; (2) ver uma figura,
///    ouvir a palavra e tocar na letra com que ela começa.
///  - Números: (1) ouvir o nome do número e tocar nele; (2) contar os
///    objetos da tela e tocar no número que diz quantos são.
class GlyphGameScreen extends StatefulWidget {
  const GlyphGameScreen({super.key, required this.kind, this.random});

  final GlyphGameKind kind;

  /// Permite testes previsíveis.
  final Random? random;

  @override
  State<GlyphGameScreen> createState() => _GlyphGameScreenState();
}

class _GlyphGameScreenState extends State<GlyphGameScreen> {
  static const _roundsPerGame = 6;

  late final AudioService _audio;
  late final Category _category;
  late final Random _rng = widget.random ?? Random();

  late List<ChoiceRound> _rounds;

  /// Palavra de exemplo de cada rodada (só letras; null = pergunta de ouvir).
  late List<ColorExample?> _examples;
  int _index = 0;
  bool _answered = false;
  bool _won = false;
  int _session = 0;
  final Set<String> _wrong = {};
  final Map<String, int> _shakes = {};

  bool get _isLetters => widget.kind == GlyphGameKind.letters;

  String get _title => _isLetters ? 'Descubra a letra' : 'Descubra o número';

  /// Rodadas ímpares usam a segunda pergunta (figura / contar).
  bool _second(int index) {
    if (!index.isOdd) return false;
    return _isLetters ? _examples[index] != null : true;
  }

  @override
  void initState() {
    super.initState();
    _audio = context.read<AudioService>();
    final repo = context.read<ContentRepository>();
    _category = repo.byId(_isLetters ? 'letters' : 'numbers');
    _deal();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _startRound();
    });
  }

  @override
  void dispose() {
    _session++;
    unawaited(_audio.stop());
    super.dispose();
  }

  List<LearningItem> get _pool =>
      _isLetters ? _category.items : [for (final i in _category.items) if ((i.value ?? 0) >= 1) i];

  void _deal() {
    _rounds = buildChoiceRounds(_pool, rounds: _roundsPerGame, random: _rng);
    _examples = [
      for (final r in _rounds)
        if (_isLetters && r.target.examples.isNotEmpty)
          r.target.examples[_rng.nextInt(r.target.examples.length)]
        else
          null,
    ];
    _index = 0;
    _answered = false;
    _won = false;
    _wrong.clear();
    _shakes.clear();
    _session++;
  }

  void _restart() {
    setState(_deal);
    _startRound();
  }

  /// Fala a pergunta da rodada atual (também usado pelo botão de alto-falante).
  void _startRound() {
    final target = _rounds[_index].target;
    final Future<AudioOutcome> future;
    if (_second(_index)) {
      final ex = _examples[_index];
      future = (_isLetters && ex != null) ? _audio.playStartsWith(ex) : _audio.playHowMany();
    } else {
      future = _audio.playWords(target);
    }
    unawaited(runAudio(context, future));
  }

  Future<void> _choose(LearningItem item) async {
    if (_answered || _won) return;
    final round = _rounds[_index];
    if (item.id != round.target.id) {
      setState(() {
        _wrong.add(item.id);
        _shakes[item.id] = (_shakes[item.id] ?? 0) + 1;
      });
      return;
    }
    final session = _session;
    setState(() => _answered = true);
    await runAudio(context, _audio.playWords(round.target));
    if (!mounted || session != _session) return;
    await Future<void>.delayed(const Duration(milliseconds: 700));
    if (!mounted || session != _session) return;
    if (_index == _rounds.length - 1) {
      setState(() => _won = true);
      unawaited(_audio.praise());
      return;
    }
    setState(() {
      _index++;
      _answered = false;
      _wrong.clear();
      _shakes.clear();
    });
    _startRound();
  }

  @override
  Widget build(BuildContext context) {
    final round = _rounds[_index];
    return GameFrame(
      category: _category,
      title: _title,
      winOverlay: _won
          ? WinOverlay(onReplay: _restart, onExit: () => Navigator.of(context).pop())
          : null,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: ProgressStars(total: _rounds.length, done: _index + (_answered ? 1 : 0)),
          ),
          Expanded(flex: 4, child: _buildPrompt(round)),
          Expanded(flex: 5, child: _buildOptions(round)),
        ],
      ),
    );
  }

  Widget _buildPrompt(ChoiceRound round) {
    final target = round.target;
    final reveal = AnimatedOpacity(
      duration: const Duration(milliseconds: 250),
      opacity: _answered ? 1 : 0,
      child: _RevealTag(item: target, letters: _isLetters),
    );
    final Widget top;
    if (_second(_index)) {
      top = _isLetters ? _buildPicture(_examples[_index]!) : _buildObjects(target);
    } else {
      top = SpeakerButton(size: 112, color: _category.textAccent, onTap: _startRound);
    }
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        top,
        const SizedBox(height: 10),
        reveal,
      ],
    );
  }

  /// Letras: a figura grande, com um alto-falante para ouvir a palavra.
  Widget _buildPicture(ColorExample ex) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          key: ValueKey('picture-${ex.id}'),
          width: 130,
          height: 130,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(.92),
            shape: BoxShape.circle,
            border: Border.all(color: _category.textAccent, width: 4),
          ),
          child: Text(ex.icon, style: const TextStyle(fontSize: 72)),
        ),
        const SizedBox(width: 14),
        SpeakerButton(size: 72, color: _category.textAccent, onTap: _startRound),
      ],
    );
  }

  /// Números: os objetos para contar (dão um pulinho quando a criança acerta).
  Widget _buildObjects(LearningItem target) {
    final n = target.value ?? 1;
    return LayoutBuilder(builder: (context, c) {
      final fontSize = min(48.0, max(28.0, (c.maxWidth - 140) / 5.6)).toDouble();
      return Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Flexible(
            child: Wrap(
              key: ValueKey('objects-${target.id}'),
              alignment: WrapAlignment.center,
              spacing: 4,
              runSpacing: 4,
              children: [
                for (var k = 0; k < n; k++)
                  AnimatedScale(
                    scale: _answered ? 1.25 : 1.0,
                    duration: Duration(milliseconds: 250 + k * 40),
                    curve: Curves.easeOutBack,
                    child: Text(target.emoji ?? '⭐', style: TextStyle(fontSize: fontSize)),
                  ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          SpeakerButton(size: 64, color: _category.textAccent, onTap: _startRound),
        ],
      );
    });
  }

  Widget _buildOptions(ChoiceRound round) {
    return LayoutBuilder(builder: (context, c) {
      const gap = 14.0;
      final side = max(72.0, min((c.maxWidth - 32 - gap) / 2, (c.maxHeight - gap - 8) / 2));
      return Center(
        child: Wrap(
          alignment: WrapAlignment.center,
          spacing: gap,
          runSpacing: gap,
          children: [
            for (final option in round.options)
              SizedBox(
                width: side,
                height: side,
                child: _GlyphOption(
                  key: ValueKey('option-${option.id}'),
                  item: option,
                  accent: _category.textAccent,
                  isCorrect: _answered && option.id == round.target.id,
                  dimmed: _answered ? option.id != round.target.id : _wrong.contains(option.id),
                  shakes: _shakes[option.id] ?? 0,
                  onTap: () => _choose(option),
                ),
              ),
          ],
        ),
      );
    });
  }
}

/// Plaquinha com o nome nos dois idiomas, que aparece depois do acerto.
class _RevealTag extends StatelessWidget {
  const _RevealTag({required this.item, required this.letters});

  final LearningItem item;
  final bool letters;

  @override
  Widget build(BuildContext context) {
    final pt = letters ? item.spokenPt : item.pt;
    final en = letters ? item.spokenEn : item.en;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.92),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(pt.toUpperCase(),
              style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          Text(en.toUpperCase(),
              style: const TextStyle(
                  fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.grape)),
        ],
      ),
    );
  }
}

class _GlyphOption extends StatelessWidget {
  const _GlyphOption({
    super.key,
    required this.item,
    required this.accent,
    required this.isCorrect,
    required this.dimmed,
    required this.shakes,
    required this.onTap,
  });

  final LearningItem item;
  final Color accent;
  final bool isCorrect;
  final bool dimmed;
  final int shakes;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ShakeWidget(
      shakes: shakes,
      child: AnimatedScale(
        scale: isCorrect ? 1.08 : 1,
        duration: const Duration(milliseconds: 320),
        curve: Curves.easeOutBack,
        child: AnimatedOpacity(
          duration: const Duration(milliseconds: 250),
          opacity: dimmed ? .4 : 1,
          child: Semantics(
            button: true,
            label: 'Opção',
            child: Material(
              color: Colors.white,
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(28),
                side: BorderSide(
                  color: isCorrect ? AppColors.grass : accent,
                  width: isCorrect ? 6 : 3,
                ),
              ),
              child: InkWell(
                customBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
                onTap: onTap,
                child: Stack(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(14),
                      child: Center(
                        child: FittedBox(
                          fit: BoxFit.scaleDown,
                          child: Text(
                            item.glyph ?? item.pt,
                            style: TextStyle(
                              fontSize: 80,
                              fontWeight: FontWeight.w900,
                              height: 1.0,
                              color: glyphInk(item.color),
                            ),
                          ),
                        ),
                      ),
                    ),
                    if (isCorrect)
                      const Positioned(
                        right: 6,
                        top: 6,
                        child: Icon(Icons.check_circle_rounded, size: 36, color: AppColors.grass),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
