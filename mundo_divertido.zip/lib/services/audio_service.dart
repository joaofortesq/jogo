import 'dart:async';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';

import '../models/learning_item.dart';
import 'settings_service.dart';

enum AudioOutcome {
  played,

  /// A voz do idioma não está instalada no aparelho.
  voiceMissing,
  interrupted,
  error,
}

/// Um trecho de áudio. Por padrão é falado pela voz do sistema (sem arquivos).
/// Se [assetPath] existir no app, o arquivo gravado tem prioridade.
class AudioClip {
  const AudioClip({
    required this.tag,
    required this.text,
    required this.lang,
    this.assetPath,
    this.pitch = 1.1,
    this.rate = 0.42,
    this.isEffect = false,
  });

  /// Identifica o clipe para a interface mostrar o botão "tocando".
  final String tag;

  /// Texto falado quando não há arquivo.
  final String text;

  /// 'pt-BR' ou 'en-US'.
  final String lang;

  /// Arquivo opcional (assets/audio/...). Se existir, substitui a voz.
  final String? assetPath;
  final double pitch;
  final double rate;

  /// Efeitos (sons de animais) respeitam a opção "silenciar efeitos".
  final bool isEffect;
}

/// Camada fina sobre player e voz, para permitir testes sem plugin nativo.
abstract class AudioBackend {
  /// Completa quando o áudio termina ou é interrompido por [stop].
  Future<void> playAsset(String assetPath, double volume);

  /// Fala [text]. Retorna false se a voz do idioma não está disponível.
  /// Completa quando a fala termina ou é interrompida por [stop].
  Future<bool> speak(
    String text, {
    required String lang,
    required double volume,
    required double pitch,
    required double rate,
  });

  Future<void> stop();
  Future<void> dispose();
}

/// Implementação real: audioplayers para arquivos e voz do Android (flutter_tts).
class DeviceAudioBackend implements AudioBackend {
  DeviceAudioBackend() {
    _sub = _player.onPlayerComplete.listen((_) => _releaseAsset());
  }

  final AudioPlayer _player = AudioPlayer();
  late final StreamSubscription<void> _sub;
  Completer<void>? _assetWaiter;

  FlutterTts? _tts;
  Completer<void>? _speechWaiter;
  final Set<String> _availableLangs = {};

  /// Muda a cada [stop]; chamadas antigas percebem e desistem.
  int _generation = 0;

  @override
  Future<void> playAsset(String assetPath, double volume) async {
    final gen = _generation;
    _releaseAsset();
    final waiter = _assetWaiter = Completer<void>();
    await _player.setVolume(volume);
    if (gen != _generation) return;
    await _player.play(AssetSource(assetPath.replaceFirst('assets/', '')));
    await waiter.future.timeout(const Duration(seconds: 30), onTimeout: () {});
  }

  Future<FlutterTts> _ensureTts() async {
    final existing = _tts;
    if (existing != null) return existing;
    final tts = FlutterTts();
    tts.setCompletionHandler(_releaseSpeech);
    tts.setCancelHandler(_releaseSpeech);
    tts.setErrorHandler((dynamic _) => _releaseSpeech());
    _tts = tts;
    return tts;
  }

  Future<bool> _hasVoice(FlutterTts tts, String lang) async {
    if (_availableLangs.contains(lang)) return true;
    final dynamic r = await tts.isLanguageAvailable(lang);
    final ok = r == true || r == 1;
    if (ok) _availableLangs.add(lang);
    return ok;
  }

  @override
  Future<bool> speak(
    String text, {
    required String lang,
    required double volume,
    required double pitch,
    required double rate,
  }) async {
    final gen = _generation;
    final tts = await _ensureTts();
    if (!await _hasVoice(tts, lang)) return false;
    if (gen != _generation) return true;
    _releaseSpeech();
    await tts.setLanguage(lang);
    await tts.setVolume(volume);
    await tts.setPitch(pitch.clamp(0.5, 2.0).toDouble());
    await tts.setSpeechRate(rate.clamp(0.1, 1.0).toDouble());
    if (gen != _generation) return true;
    final waiter = _speechWaiter = Completer<void>();
    await tts.speak(text);
    await waiter.future.timeout(const Duration(seconds: 20), onTimeout: () {});
    return true;
  }

  @override
  Future<void> stop() async {
    _generation++;
    _releaseAsset();
    _releaseSpeech();
    await _player.stop();
    await _tts?.stop();
  }

  void _releaseAsset() {
    final w = _assetWaiter;
    _assetWaiter = null;
    if (w != null && !w.isCompleted) w.complete();
  }

  void _releaseSpeech() {
    final w = _speechWaiter;
    _speechWaiter = null;
    if (w != null && !w.isCompleted) w.complete();
  }

  @override
  Future<void> dispose() async {
    _generation++;
    _releaseAsset();
    _releaseSpeech();
    await _sub.cancel();
    await _player.dispose();
    await _tts?.stop();
  }
}

/// Um único canal: cada novo pedido interrompe o anterior,
/// então nunca há dois áudios ao mesmo tempo nem repetição acumulada.
class AudioService {
  AudioService({
    required this.settings,
    AudioBackend? backend,
    Future<bool> Function(String path)? assetExists,
    this.clipGap = const Duration(milliseconds: 450),
  })  : _backend = backend ?? DeviceAudioBackend(),
        _assetExists = assetExists ?? _manifestExists;

  final SettingsService settings;
  final AudioBackend _backend;
  final Future<bool> Function(String path) _assetExists;

  /// Pequena pausa entre um trecho e o seguinte (ex.: português e inglês).
  final Duration clipGap;

  /// Tag do clipe em reprodução (ou null).
  final ValueNotifier<String?> playingTag = ValueNotifier<String?>(null);

  int _token = 0;

  static Set<String>? _manifest;
  static Future<bool> _manifestExists(String path) async {
    try {
      _manifest ??=
          (await AssetManifest.loadFromAssetBundle(rootBundle)).listAssets().toSet();
      return _manifest!.contains(path);
    } catch (_) {
      return false;
    }
  }

  Future<AudioOutcome> playSequence(List<AudioClip> clips, {Duration? gap}) async {
    final pause = gap ?? clipGap;
    final token = ++_token;
    playingTag.value = null;
    await _backend.stop();
    var voiceMissing = false;
    var failed = false;
    var playedAny = false;
    for (final clip in clips) {
      if (token != _token) return AudioOutcome.interrupted;
      if (clip.isEffect && settings.effectsMuted) continue;
      if (playedAny && pause > Duration.zero) {
        playingTag.value = null;
        await Future<void>.delayed(pause);
        if (token != _token) return AudioOutcome.interrupted;
      }
      playedAny = true;
      final path = clip.assetPath;
      final useFile = path != null && await _assetExists(path);
      if (token != _token) return AudioOutcome.interrupted;
      playingTag.value = clip.tag;
      try {
        if (useFile) {
          await _backend.playAsset(path!, settings.volume);
        } else {
          final ok = await _backend.speak(
            clip.text,
            lang: clip.lang,
            volume: settings.volume,
            pitch: clip.pitch,
            rate: clip.rate,
          );
          if (!ok) voiceMissing = true;
        }
      } catch (e) {
        debugPrint('Erro de áudio em ${clip.tag}: $e');
        failed = true;
      }
    }
    if (token != _token) return AudioOutcome.interrupted;
    playingTag.value = null;
    if (failed) return AudioOutcome.error;
    if (voiceMissing) return AudioOutcome.voiceMissing;
    return AudioOutcome.played;
  }

  AudioClip _pt(LearningItem i) =>
      AudioClip(tag: '${i.id}:pt', text: i.spokenPt, lang: 'pt-BR', assetPath: i.ptAudioPath);
  AudioClip _en(LearningItem i) =>
      AudioClip(tag: '${i.id}:en', text: i.spokenEn, lang: 'en-US', assetPath: i.enAudioPath);
  AudioClip _sfx(LearningItem i) {
    final s = i.sound;
    return AudioClip(
      tag: '${i.id}:sfx',
      text: s?.text ?? i.pt,
      lang: 'pt-BR',
      assetPath: i.soundAudioPath,
      pitch: s?.pitch ?? 1.0,
      rate: s?.rate ?? 0.5,
      isEffect: true,
    );
  }

  Future<AudioOutcome> playPt(LearningItem i) => playSequence([_pt(i)]);
  Future<AudioOutcome> playEn(LearningItem i) => playSequence([_en(i)]);
  Future<AudioOutcome> playSound(LearningItem i) => playSequence([_sfx(i)]);

  /// Objeto de exemplo de uma cor (ex.: Coração / Heart): português e inglês.
  Future<AudioOutcome> playExample(ColorExample ex) => playSequence([
        AudioClip(
            tag: 'obj:${ex.id}:pt',
            text: ex.pt,
            lang: 'pt-BR',
            assetPath: 'assets/audio/pt_br/obj_${ex.id}.mp3'),
        AudioClip(
            tag: 'obj:${ex.id}:en',
            text: ex.en,
            lang: 'en-US',
            assetPath: 'assets/audio/en_us/obj_${ex.id}.mp3'),
      ]);

  /// Hora de dormir: o bicho faz o som e deseja boa noite (português e inglês).
  Future<AudioOutcome> playBedtime(LearningItem animal) => playSequence([
        _sfx(animal),
        const AudioClip(
            tag: 'msg:pt',
            text: 'Boa noite! Está na hora de dormir. Até amanhã!',
            lang: 'pt-BR',
            assetPath: 'assets/audio/pt_br/msg_boanoite.mp3'),
        const AudioClip(
            tag: 'msg:en',
            text: "Good night! It's time to sleep. See you tomorrow!",
            lang: 'en-US',
            assetPath: 'assets/audio/en_us/msg_boanoite.mp3'),
      ]);

  /// Existe arquivo de som gravado para este animal?
  Future<bool> hasSoundFile(LearningItem i) => _assetExists(i.soundAudioPath);

  /// Pergunta do jogo "Quem faz esse som?" seguida do som do animal.
  Future<AudioOutcome> playGuessSound(LearningItem i) => playSequence([
        const AudioClip(tag: 'prompt:pt', text: 'Quem faz esse som?', lang: 'pt-BR'),
        _sfx(i),
      ]);

  /// Todas as palavras de exemplo de uma letra, cada uma em português e inglês.
  Future<AudioOutcome> playExamples(List<ColorExample> examples) => playSequence([
        for (final ex in examples) ...[
          AudioClip(
              tag: 'obj:${ex.id}:pt',
              text: ex.pt,
              lang: 'pt-BR',
              assetPath: 'assets/audio/pt_br/obj_${ex.id}.mp3'),
          AudioClip(
              tag: 'obj:${ex.id}:en',
              text: ex.en,
              lang: 'en-US',
              assetPath: 'assets/audio/en_us/obj_${ex.id}.mp3'),
        ],
      ]);

  /// Pergunta do jogo de letras: "Com que letra começa?" e a palavra,
  /// em português e depois em inglês.
  Future<AudioOutcome> playStartsWith(ColorExample ex) => playSequence([
        const AudioClip(tag: 'prompt:pt', text: 'Com que letra começa?', lang: 'pt-BR'),
        AudioClip(
            tag: 'obj:${ex.id}:pt',
            text: ex.pt,
            lang: 'pt-BR',
            assetPath: 'assets/audio/pt_br/obj_${ex.id}.mp3'),
        const AudioClip(
            tag: 'prompt:en', text: 'Which letter does it start with?', lang: 'en-US'),
        AudioClip(
            tag: 'obj:${ex.id}:en',
            text: ex.en,
            lang: 'en-US',
            assetPath: 'assets/audio/en_us/obj_${ex.id}.mp3'),
      ]);

  /// Pergunta do jogo de números: "Quantos são?".
  Future<AudioOutcome> playHowMany() => playSequence(const [
        AudioClip(tag: 'prompt:pt', text: 'Quantos são?', lang: 'pt-BR'),
        AudioClip(tag: 'prompt:en', text: 'How many are there?', lang: 'en-US'),
      ]);

  /// Conta de 1 até [n] em português e depois em inglês. Cada número falado
  /// emite a tag `num_k:pt` / `num_k:en`, que a tela usa para acender o objeto.
  Future<AudioOutcome> playCount(List<LearningItem> numbers, int n) {
    final clips = <AudioClip>[];
    for (final lang in const ['pt', 'en']) {
      for (var k = 1; k <= n; k++) {
        final item = numbers.firstWhere((i) => i.value == k);
        clips.add(lang == 'pt' ? _pt(item) : _en(item));
      }
    }
    return playSequence(clips, gap: const Duration(milliseconds: 150));
  }

  /// Botão "Falar": português e, em seguida, inglês.
  Future<AudioOutcome> playWords(LearningItem i) => playSequence([_pt(i), _en(i)]);

  /// Toque no personagem: som (se houver), depois português e inglês.
  Future<AudioOutcome> playAll(LearningItem i) => playSequence([
        if (i.hasAnimalSound) _sfx(i),
        _pt(i),
        _en(i),
      ]);

  /// Frase solta (instruções e elogios das brincadeiras).
  Future<AudioOutcome> say(String text, {String lang = 'pt-BR', String tag = 'say'}) =>
      playSequence([AudioClip(tag: tag, text: text, lang: lang)]);

  /// Elogio em português e inglês.
  Future<AudioOutcome> praise() => playSequence(const [
        AudioClip(tag: 'praise:pt', text: 'Muito bem!', lang: 'pt-BR'),
        AudioClip(tag: 'praise:en', text: 'Great job!', lang: 'en-US'),
      ]);

  Future<void> stop() async {
    _token++;
    playingTag.value = null;
    await _backend.stop();
  }

  Future<void> dispose() async {
    _token++;
    await _backend.dispose();
    playingTag.dispose();
  }
}
